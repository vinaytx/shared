# Goal agents: Outlook + Barracuda workers for Claude Code (Windows)

A goal-based multi-agent setup for Claude Code. An orchestrator turns an outcome
("find every Acme invoice since 2015 and list the attachments") into tasks, sends
them to worker subagents, checks results against success criteria, and iterates.
New workers plug in with one command and the orchestrator discovers them automatically.

```
 you ──/goal──▶ orchestrator (goal skill)
                 │ 1 frame goal + success criteria
                 │ 2 bash tools/run registry   ◀── reads .claude/agents/workers/*.md
                 │ 3 plan → .goals/<id>/plan.json
                 │ 4 dispatch TASK BRIEFs (parallel)
                 ├──▶ outlook-mail       ──▶ bash tools/run outlook ...    ──▶ classic Outlook (COM)
                 ├──▶ barracuda-archive  ──▶ bash tools/run barracuda ...  ──▶ synced archive store / EML export
                 └──▶ <your next worker> ──▶ bash tools/run <tool> ...
                 │ 5 collect goal-worker/1 JSON envelopes → .goals/<id>/results/
                 │ 6 verify criteria, follow handoffs, retry narrower (max 3 iterations)
                 └ 7 report → .goals/<id>/report.md
```

## Layout

| Path | What it is |
|---|---|
| `.claude/skills/goal/SKILL.md` | The orchestration loop. Run as `/goal <outcome>`. |
| `.claude/agents/goal-orchestrator.md` | Same loop as a subagent (preloads the `goal` skill). Also usable as `claude --agent goal-orchestrator`. |
| `.claude/skills/worker-contract/SKILL.md` | Brief format, result envelope, safety rules. Preloaded into every worker. |
| `.claude/agents/workers/outlook-mail.md` | Worker: classic Outlook via COM. |
| `.claude/agents/workers/barracuda-archive.md` | Worker: Barracuda archive (synced Outlook store or EML export). |
| `.claude/goal-framework/WORKER_TEMPLATE.md` | Template for new workers. |
| `tools/run` | Bash launcher; finds Python (prefers `py -3` on Windows) and runs `tools/<tool>_cli.py`. |
| `tools/outlook_cli.py`, `tools/barracuda_cli.py` | Read-only CLIs. Every command prints one JSON envelope. |
| `tools/registry.py`, `tools/new_worker.py` | Worker discovery and scaffolding. |
| `tools/hooks/guard_bash.py` | Worker hook: allows only single `tools/run` commands (no chaining, pipes, redirects). |

## Setup on Windows

1. **Classic Outlook.** COM does not exist in New Outlook. If you see the "New Outlook"
   toggle switched on, turn it off. Keep Outlook running and signed in.
2. **Python 3.8+** from python.org, then: `py -m pip install pywin32`
3. **Copy this folder** into your project root (or use it as the project).
4. **Run Claude Code non-elevated** (same user and elevation as Outlook), from this folder.
   Accept the workspace trust prompt so the worker hooks load.
5. **Check the environment** (from Git Bash or ask Claude to run them):
   ```
   bash tools/run outlook doctor
   bash tools/run barracuda doctor
   bash tools/run registry
   ```
6. **Barracuda, pick a path:**
   - *Synced store (live)*: in Outlook, File > Barracuda Networks > Configure > Archive Stores,
     add your archive store and sync. Your admin must have nightly folder-sync jobs enabled.
     If the store name doesn't contain "archive" or "barracuda", copy
     `tools/config.example.json` to `tools/config.json` and set `archive_store_hints`.
   - *EML export (offline)*: run a search in the archiver web UI, export as EML/zip, and set
     `export_dir` in `tools/config.json` (or `BARRACUDA_EXPORT_DIR`).
7. **32-bit Outlook?** Out-of-process COM usually works across bitness. If it doesn't,
   install 32-bit Python and `export GOAL_PYTHON="/c/Path/To/Python-32/python.exe"`.

## Use

```
/goal Find all emails from acme.com about invoices since 2015 across my mailbox and the
      Barracuda archive. List date, subject and attachment names, de-duplicated.
```

Or ask for a single worker directly: `@"outlook-mail (agent)" list my stores`.

## Add a worker

```
bash tools/run new-worker jira-tickets --tool jira --purpose "Searches Jira tickets by project and status"
```

This creates `.claude/agents/workers/jira-tickets.md` and `tools/jira_cli.py`. Then:

1. Fill in **Capabilities** (the orchestrator plans from these) and the CLI table.
2. Implement the CLI commands. Raise `ToolError("ENV_...", msg, hint=...)` for setup
   problems so the worker reports `blocked` instead of retrying.
3. Keep it read-only. If a worker must act (send, update, delete), gate it on the
   brief's `approved_actions` and only approve actions the user explicitly asked for.
4. `bash tools/run registry` to confirm discovery. No orchestrator changes needed.

Workers don't have to use a Python CLI. One wrapping an MCP server can list the server
in its `mcpServers` frontmatter instead, as long as it honors the worker contract.

## Design notes

- **Why a contract:** every worker takes the same TASK BRIEF and returns the same
  `goal-worker/1` envelope (`status`, `criteria`, `results`, `handoff`...). That is what lets
  the orchestrator verify, chain and iterate without knowing worker internals.
- **Nesting:** subagents may spawn subagents up to three levels below the main conversation
  by default, so `goal-orchestrator` (level 1) can dispatch workers (level 2). Workers have
  no Agent tool, so they cannot fan out further.
- **State on disk:** `.goals/<id>/plan.json` survives compaction and resumes; `.goals/`
  is git-ignored because it contains mail content.
- **Prompt injection:** emails can contain instructions aimed at the agent. Workers treat
  mail as data, have no send/delete commands, and can only run `tools/run`.
- **Barracuda:** no documented message-search API was found for the Message Archiver,
  which is why this goes through the Outlook add-in's synced store or EML exports.
- **Graph alternative:** for New Outlook / Exchange Online without COM, add a `graph-mail`
  worker using MSAL device-code auth and delegated `Mail.Read`. It needs an Entra app
  registration from IT.

## Known limits

- Search is Outlook DASL `LIKE` (substring). Body search on big stores is slow, so add dates.
- With `--limit`, results are collected folder by folder, then sorted, so a truncated result
  set isn't guaranteed to be the globally newest. Narrow the query if `truncated` is true.
- Stubbed messages in the archive store may hold only a preview. The full copy lives on
  the archiver.
- Tested here against a mocked Outlook object model and real EML files, not live Outlook.
  Run the `doctor` commands first on your machine.
