"""registry - list worker agents and their capabilities for the orchestrator.

Scans .claude/agents/workers/**/*.md. A worker is any file there with `name` and
`description` frontmatter. Capabilities come from the bullets under "## Capabilities";
the CLI tool name from the first `bash tools/run <tool>` mention.
"""
from __future__ import annotations

import os
import re
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import ROOT, Result, emit  # noqa: E402

WORKERS = ROOT / ".claude" / "agents" / "workers"


def frontmatter(text: str) -> tuple[dict, str]:
    if not text.startswith("---"):
        return {}, text
    end = text.find("\n---", 3)
    if end == -1:
        return {}, text
    fm, body = text[3:end], text[end + 4:]
    data = {}
    for line in fm.splitlines():
        m = re.match(r"^([A-Za-z][\w-]*):\s*(.*)$", line)  # top-level scalar keys only
        if m:
            data[m.group(1)] = m.group(2).strip().strip("'\"")
    return data, body


def capabilities(body: str) -> list[str]:
    m = re.search(r"^##\s+Capabilities\s*\n(.*?)(?=^##\s|\Z)", body, re.S | re.M)
    if not m:
        return []
    return [re.sub(r"^\s*[-*]\s+", "", l).strip() for l in m.group(1).splitlines() if re.match(r"^\s*[-*]\s+", l)]


def main() -> None:
    res = Result()
    workers = []
    if not WORKERS.exists():
        res.warn(f"{WORKERS} does not exist")
    for path in sorted(WORKERS.rglob("*.md")) if WORKERS.exists() else []:
        fm, body = frontmatter(path.read_text(encoding="utf-8"))
        if not fm.get("name") or not fm.get("description"):
            res.warn(f"{path.relative_to(ROOT).as_posix()}: missing name/description - Claude Code will not load it")
            continue
        tool = re.search(r"tools/run\s+([a-z0-9_-]+)", body)
        cli = tool.group(1) if tool else None
        if cli and not (ROOT / "tools" / f"{cli.replace('-', '_')}_cli.py").exists():
            res.warn(f"{fm['name']}: CLI tools/{cli.replace('-', '_')}_cli.py not found")
        workers.append({
            "name": fm["name"],
            "description": fm["description"],
            "capabilities": capabilities(body),
            "cli": cli,
            "model": fm.get("model"),
            "file": path.relative_to(ROOT).as_posix(),
        })
    names = [w["name"] for w in workers]
    for n in {n for n in names if names.count(n) > 1}:
        res.warn(f"Duplicate worker name '{n}' - Claude Code loads only one of them")
    emit("registry", "list", True, {"count": len(workers), "workers": workers}, res)


if __name__ == "__main__":
    main()
