"""outlook - read-only access to classic Outlook for Windows through COM (pywin32).

    bash tools/run outlook doctor
    bash tools/run outlook stores
    bash tools/run outlook folders --store "Mailbox - Jane"
    bash tools/run outlook search --from acme.com --subject invoice --since 2024-01-01
    bash tools/run outlook get <ENTRY_ID> --store-id <STORE_ID>
    bash tools/run outlook save-attachments <ENTRY_ID> --store-id <ID> --out .goals/x/att
    bash tools/run outlook export <ENTRY_ID> --store-id <ID> --out msg1.msg

Deliberately has no send / move / delete commands.
New Outlook (olk.exe) has no COM interface and is not supported.
"""
from __future__ import annotations

import datetime as dt
import os
import platform
import struct
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (  # noqa: E402
    Result, ToolError, clip, is_windows, make_parser, parse_date, run_cli,
    safe_filename, snippet, unique_path,
)

TOOL = "outlook"
OL_MAIL_ITEM = 0          # OlItemType / DefaultItemType for mail folders
OL_FOLDER_INBOX = 6
OL_MAIL_CLASS = 43        # OlObjectClass.olMail
PR_HEADERS = "http://schemas.microsoft.com/mapi/proptag/0x007D001F"
PR_SMTP = "http://schemas.microsoft.com/mapi/proptag/0x39FE001F"
PR_MSGID = "http://schemas.microsoft.com/mapi/proptag/0x1035001F"
SAVE_FORMATS = {"txt": 0, "html": 5, "msg": 9}  # olTXT, olHTML, olMSGUnicode
ARCHIVE_HINTS_DEFAULT = ["barracuda", "archive search", "message archiver", "archive"]
MAX_LIMIT = 500


# ===================================================================== COM access

_session = None


def session():
    """Return (application, namespace). Raises ToolError with an actionable hint."""
    global _session
    if _session:
        return _session
    if not is_windows() and not os.environ.get("GOAL_FAKE_COM"):
        raise ToolError("ENV_NOT_WINDOWS", "Outlook COM is only available on Windows.",
                        hint="Run Claude Code natively on the Windows PC where classic Outlook is installed.")
    try:
        import pythoncom  # type: ignore
        import win32com.client  # type: ignore
    except ImportError:
        raise ToolError("ENV_NO_PYWIN32", "pywin32 is not installed for this Python.",
                        hint="Run: py -m pip install pywin32   (use the same Python bitness as Outlook)")
    try:
        pythoncom.CoInitialize()
    except Exception:
        pass
    try:
        app = win32com.client.Dispatch("Outlook.Application")
        ns = app.GetNamespace("MAPI")
        _ = ns.Stores.Count  # forces a real round-trip
    except Exception as e:
        hint = ("Start classic Outlook and sign in. Claude Code and Outlook must run as the same Windows user "
                "and at the same elevation (both non-admin is best). New Outlook has no COM; switch to classic "
                "with the toggle in New Outlook's title bar.")
        if new_outlook_running() and not classic_outlook_running():
            raise ToolError("ENV_NEW_OUTLOOK", "Only New Outlook (olk.exe) is running; it has no COM interface.", hint=hint)
        raise ToolError("ENV_OUTLOOK_UNAVAILABLE", f"Could not connect to Outlook: {e}", hint=hint)
    _session = (app, ns)
    return _session


def _tasklist() -> str:
    if not is_windows():
        return ""
    try:
        return subprocess.run(["tasklist", "/FO", "CSV", "/NH"], capture_output=True, text=True, timeout=10).stdout.lower()
    except Exception:
        return ""


def classic_outlook_running() -> bool:
    return '"outlook.exe"' in _tasklist()


def new_outlook_running() -> bool:
    return '"olk.exe"' in _tasklist()


def g(obj, attr, default=None):
    """Safe COM attribute get - Outlook throws on many properties for some item types."""
    try:
        v = getattr(obj, attr)
        return default if v is None else v
    except Exception:
        return default


def to_iso(v):
    if v is None:
        return None
    try:
        # pywintypes datetime is a datetime subclass; Outlook uses 4501-01-01 for "none"
        if hasattr(v, "year") and v.year >= 4500:
            return None
        return dt.datetime(v.year, v.month, v.day, v.hour, v.minute, v.second).isoformat()
    except Exception:
        return str(v)


def sender_email(item) -> str:
    if (g(item, "SenderEmailType", "") or "").upper() == "EX":
        try:
            eu = item.Sender.GetExchangeUser()
            if eu is not None and eu.PrimarySmtpAddress:
                return eu.PrimarySmtpAddress
        except Exception:
            pass
        try:
            return item.PropertyAccessor.GetProperty(PR_SMTP) or ""
        except Exception:
            pass
    return g(item, "SenderEmailAddress", "") or ""


def message_id(item) -> str | None:
    try:
        return item.PropertyAccessor.GetProperty(PR_MSGID) or None
    except Exception:
        return None


# ===================================================================== stores and folders

def archive_hints() -> list[str]:
    from _common import load_config
    cfg = load_config().get("barracuda", {})
    env = os.environ.get("BARRACUDA_STORE_HINTS")
    hints = (env.split(",") if env else None) or cfg.get("archive_store_hints") or ARCHIVE_HINTS_DEFAULT
    return [h.strip().lower() for h in hints if h.strip()]


def store_info(store) -> dict:
    name = g(store, "DisplayName", "")
    path = g(store, "FilePath", "") or ""
    hay = f"{name} {path}".lower()
    return {
        "display_name": name,
        "store_id": g(store, "StoreID", ""),
        "file_path": path or None,
        "is_data_file": bool(g(store, "IsDataFileStore", False)),
        "exchange_store_type": g(store, "ExchangeStoreType", None),
        "looks_like_archive": any(h in hay for h in archive_hints()),
    }


def all_stores():
    _, ns = session()
    return [ns.Stores.Item(i) for i in range(1, ns.Stores.Count + 1)]


def find_stores(pattern: str | None):
    stores = all_stores()
    if not pattern:
        return stores
    p = pattern.lower()
    exact = [s for s in stores if (g(s, "DisplayName", "") or "").lower() == p]
    if exact:
        return exact
    hits = [s for s in stores if p in (g(s, "DisplayName", "") or "").lower()]
    if not hits:
        names = [g(s, "DisplayName", "") for s in stores]
        raise ToolError("STORE_NOT_FOUND", f"No store matches '{pattern}'.", hint=f"Available stores: {names}")
    return hits


def folder_path(folder) -> str:
    fp = g(folder, "FolderPath", "") or ""
    # "\\Mailbox - Jane\\Inbox\\Sub" -> "Inbox/Sub"
    parts = [p for p in fp.split("\\") if p]
    return "/".join(parts[1:]) if len(parts) > 1 else (parts[0] if parts else "")


def resolve_folder(store, path: str):
    root = store.GetRootFolder()
    cur = root
    for part in [p for p in path.replace("\\", "/").split("/") if p]:
        nxt = None
        for i in range(1, cur.Folders.Count + 1):
            f = cur.Folders.Item(i)
            if (g(f, "Name", "") or "").lower() == part.lower():
                nxt = f
                break
        if nxt is None:
            raise ToolError("FOLDER_NOT_FOUND", f"Folder '{path}' not found in store '{g(store, 'DisplayName')}'.",
                            hint="List folders with: bash tools/run outlook folders --store <name>")
        cur = nxt
    return cur


def walk_folders(folder, recurse: bool, depth: int = 0, max_depth: int = 25):
    yield folder, depth
    if not recurse or depth >= max_depth:
        return
    try:
        count = folder.Folders.Count
    except Exception:
        return
    for i in range(1, count + 1):
        try:
            sub = folder.Folders.Item(i)
        except Exception:
            continue
        yield from walk_folders(sub, recurse, depth + 1, max_depth)


def is_mail_folder(folder) -> bool:
    return g(folder, "DefaultItemType", OL_MAIL_ITEM) == OL_MAIL_ITEM


# ===================================================================== search

def _like(prop: str, value: str) -> str:
    v = value.replace("'", "''")
    return f'"{prop}" LIKE \'%{v}%\''


def build_filter(a) -> str | None:
    """DASL filter (@SQL=...) for Items.Restrict. LIKE is a substring match, case-insensitive."""
    c: list[str] = []
    if a.from_:
        c.append("(" + " OR ".join([_like("urn:schemas:httpmail:fromemail", a.from_),
                                     _like("urn:schemas:httpmail:fromname", a.from_),
                                     _like("http://schemas.microsoft.com/mapi/proptag/0x0C1F001F", a.from_)]) + ")")
    if a.to:
        c.append("(" + " OR ".join([_like("urn:schemas:httpmail:displayto", a.to),
                                     _like("urn:schemas:httpmail:displaycc", a.to)]) + ")")
    if a.subject:
        c.append(_like("urn:schemas:httpmail:subject", a.subject))
    if a.body:
        c.append(_like("urn:schemas:httpmail:textdescription", a.body))
    if a.text:
        c.append("(" + " OR ".join([_like("urn:schemas:httpmail:subject", a.text),
                                     _like("urn:schemas:httpmail:textdescription", a.text)]) + ")")
    since, until = parse_date(a.since), parse_date(a.until, end_of_day=True)
    for d, op in ((since, ">="), (until, "<=")):
        if d:
            # DASL compares in UTC; convert from local time
            utc = d.astimezone(dt.timezone.utc).strftime("%Y-%m-%d %H:%M")
            c.append(f'"urn:schemas:httpmail:datereceived" {op} \'{utc}\'')
    if a.has_attachments:
        c.append('"urn:schemas:httpmail:hasattachment" = 1')
    if a.unread:
        c.append('"urn:schemas:httpmail:read" = 0')
    return ("@SQL=" + " AND ".join(c)) if c else None


def summarize(item, folder=None) -> dict:
    atts = g(item, "Attachments", None)
    n_att = g(atts, "Count", 0) if atts is not None else 0
    parent = folder if folder is not None else g(item, "Parent", None)
    return {
        "entry_id": g(item, "EntryID", ""),
        "store_id": g(parent, "StoreID", "") if parent is not None else "",
        "folder": folder_path(parent) if parent is not None else "",
        "received": to_iso(g(item, "ReceivedTime", None)) or to_iso(g(item, "SentOn", None)),
        "from_name": g(item, "SenderName", ""),
        "from_email": sender_email(item),
        "to": g(item, "To", ""),
        "cc": g(item, "CC", ""),
        "subject": g(item, "Subject", ""),
        "attachments": n_att,
        "unread": bool(g(item, "UnRead", False)),
        "size": g(item, "Size", None),
        "snippet": snippet(g(item, "Body", ""), 200),
    }


def search_folders(folders, flt, limit, res: Result):
    out = []
    scanned = 0
    for folder in folders:
        if len(out) >= limit:
            res.truncated = True
            break
        if not is_mail_folder(folder):
            continue
        scanned += 1
        try:
            items = folder.Items
            items.Sort("[ReceivedTime]", True)
            hits = items.Restrict(flt) if flt else items
        except Exception as e:
            res.warn(f"Skipped folder '{folder_path(folder)}': {e}")
            continue
        try:
            item = hits.GetFirst()
        except Exception:
            item = None
        while item is not None:
            if len(out) >= limit:
                res.truncated = True
                break
            if g(item, "Class", OL_MAIL_CLASS) in (OL_MAIL_CLASS, 53, 54, 55, 56, 57):  # mail + meeting msgs
                out.append(summarize(item, folder))
            try:
                item = hits.GetNext()
            except Exception:
                break
    out.sort(key=lambda r: r.get("received") or "", reverse=True)
    return out, scanned


def do_search(a, res: Result, store_filter=None) -> dict:
    limit = max(1, min(a.limit, MAX_LIMIT))
    if a.limit > MAX_LIMIT:
        res.warn(f"limit capped at {MAX_LIMIT}")
    flt = build_filter(a)
    if (a.body or a.text) and not (a.since or a.until):
        res.warn("Body/text search without a date range can be slow on large stores.")

    _, ns = session()
    folders: list = []
    if store_filter is not None:
        stores = store_filter
    elif a.store:
        stores = find_stores(a.store)
    else:
        stores = None

    if stores is None:  # default Inbox (or folder in the default store)
        if a.folder:
            folders = list(f for f, _ in walk_folders(resolve_folder(ns.DefaultStore, a.folder), not a.no_recurse))
        else:
            folders = list(f for f, _ in walk_folders(ns.GetDefaultFolder(OL_FOLDER_INBOX), not a.no_recurse))
        scope = [g(ns.DefaultStore, "DisplayName", "default store")]
    else:
        for s in stores:
            start = resolve_folder(s, a.folder) if a.folder else s.GetRootFolder()
            folders.extend(f for f, _ in walk_folders(start, not a.no_recurse))
        scope = [g(s, "DisplayName", "") for s in stores]

    rows, scanned = search_folders(folders, flt, limit, res)
    return {"scope": scope, "folders_scanned": scanned, "filter": flt, "count": len(rows), "messages": rows}


# ===================================================================== single message

def get_item(entry_id: str, store_id: str | None):
    _, ns = session()
    try:
        return ns.GetItemFromID(entry_id, store_id) if store_id else ns.GetItemFromID(entry_id)
    except Exception as e:
        raise ToolError("ITEM_NOT_FOUND", f"Could not open item: {e}",
                        hint="Pass --store-id from the search result; IDs change when an item is moved.")


def item_detail(item, max_body: int, headers: bool, res: Result) -> dict:
    d = summarize(item)
    body, clipped = clip(g(item, "Body", ""), max_body)
    if clipped:
        res.truncated = True
    d.pop("snippet", None)
    d.update({
        "sent": to_iso(g(item, "SentOn", None)),
        "bcc": g(item, "BCC", ""),
        "internet_message_id": message_id(item),
        "conversation_topic": g(item, "ConversationTopic", ""),
        "categories": g(item, "Categories", ""),
        "importance": g(item, "Importance", None),
        "body": body,
        "attachment_list": attachment_list(item),
    })
    if headers:
        try:
            h, hc = clip(item.PropertyAccessor.GetProperty(PR_HEADERS), 6000)
            d["headers"] = h
        except Exception:
            d["headers"] = None
            res.warn("Transport headers unavailable for this item.")
    return d


def attachment_list(item) -> list[dict]:
    out = []
    atts = g(item, "Attachments", None)
    for i in range(1, (g(atts, "Count", 0) if atts is not None else 0) + 1):
        a = atts.Item(i)
        out.append({"index": i, "filename": g(a, "FileName", "") or g(a, "DisplayName", ""),
                    "size": g(a, "Size", None), "type": g(a, "Type", None)})
    return out


# ===================================================================== commands

def cmd_doctor(a, res: Result) -> dict:
    info = {
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "python_bits": struct.calcsize("P") * 8,
        "python_exe": sys.executable,
        "pywin32": False,
        "is_admin": None,
        "classic_outlook_running": None,
        "new_outlook_running": None,
        "outlook_bitness": None,
        "connected": False,
        "default_store": None,
        "store_count": None,
    }
    if not is_windows() and not os.environ.get("GOAL_FAKE_COM"):
        res.warn("Not running on Windows - Outlook COM is unavailable here.")
        return info
    try:
        import win32com.client  # noqa: F401
        info["pywin32"] = True
    except ImportError:
        res.warn("pywin32 missing: py -m pip install pywin32")
    if is_windows():
        try:
            import ctypes
            info["is_admin"] = bool(ctypes.windll.shell32.IsUserAnAdmin())
            if info["is_admin"]:
                res.warn("This shell is elevated (admin). If Outlook is not elevated, COM calls fail - run Claude Code non-elevated.")
        except Exception:
            pass
        info["classic_outlook_running"] = classic_outlook_running()
        info["new_outlook_running"] = new_outlook_running()
        info["outlook_bitness"] = outlook_bitness()
        if info["outlook_bitness"] and str(info["python_bits"]) not in info["outlook_bitness"]:
            res.warn(f"Python is {info['python_bits']}-bit but Outlook is {info['outlook_bitness']}. "
                     "Usually fine for out-of-process COM, but if calls fail install matching Python and set GOAL_PYTHON.")
        if info["new_outlook_running"] and not info["classic_outlook_running"]:
            res.warn("Only New Outlook is running. Switch to classic Outlook (COM is not supported in New Outlook).")
    if info["pywin32"]:
        try:
            _, ns = session()
            info["connected"] = True
            info["default_store"] = g(ns.DefaultStore, "DisplayName", None)
            info["store_count"] = ns.Stores.Count
        except ToolError as e:
            res.warn(f"{e.code}: {e.message} | {e.hint}")
    return info


def outlook_bitness() -> str | None:
    try:
        import winreg  # type: ignore
    except ImportError:
        return None
    keys = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Office\ClickToRun\Configuration", "Platform"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Office\16.0\Outlook", "Bitness"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Office\16.0\Outlook", "Bitness"),
    ]
    for hive, path, name in keys:
        try:
            with winreg.OpenKey(hive, path) as k:
                v = str(winreg.QueryValueEx(k, name)[0]).lower()
                return "64-bit" if "64" in v else "32-bit" if ("86" in v or "32" in v) else v
        except OSError:
            continue
    return None


def cmd_stores(a, res: Result) -> dict:
    stores = [store_info(s) for s in all_stores()]
    return {"count": len(stores), "stores": stores}


def cmd_folders(a, res: Result) -> dict:
    stores = find_stores(a.store) if a.store else [session()[1].DefaultStore]
    out = []
    for s in stores:
        for f, depth in walk_folders(s.GetRootFolder(), True, max_depth=a.depth):
            if depth == 0:
                continue
            out.append({"store": g(s, "DisplayName", ""), "path": folder_path(f), "depth": depth,
                        "items": g(g(f, "Items", None), "Count", None), "is_mail": is_mail_folder(f)})
            if len(out) >= 1000:
                res.truncated = True
                break
    return {"count": len(out), "folders": out}


def cmd_search(a, res: Result) -> dict:
    return do_search(a, res)


def cmd_get(a, res: Result) -> dict:
    return item_detail(get_item(a.entry_id, a.store_id), a.max_body, a.headers, res)


def cmd_save_attachments(a, res: Result) -> dict:
    item = get_item(a.entry_id, a.store_id)
    return save_attachments(item, a.out, a.index, res)


def save_attachments(item, out_dir: str, index: int | None, res: Result) -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    saved = []
    for att in attachment_list(item):
        if index and att["index"] != index:
            continue
        a = item.Attachments.Item(att["index"])
        if g(a, "Type", 1) == 5:  # olEmbeddeditem: Outlook can still save as .msg
            name = safe_filename(att["filename"] or f"attachment{att['index']}") + ".msg"
        else:
            name = safe_filename(att["filename"], f"attachment{att['index']}")
        path = unique_path(out, name)
        try:
            a.SaveAsFile(str(path.resolve()))
            saved.append({"index": att["index"], "path": str(path), "size": att["size"]})
        except Exception as e:
            res.warn(f"Could not save attachment {att['index']} ({att['filename']}): {e}")
    return {"count": len(saved), "saved": saved}


def cmd_export(a, res: Result) -> dict:
    item = get_item(a.entry_id, a.store_id)
    path = Path(a.out)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        path = unique_path(path.parent, path.name)
    item.SaveAs(str(path.resolve()), SAVE_FORMATS[a.format])
    return {"path": str(path), "format": a.format}


# ===================================================================== argparse

def add_search_args(p, store_option=True):
    if store_option:
        p.add_argument("--store", help="store name (case-insensitive substring)")
        p.add_argument("--folder", help="folder path inside the store, e.g. Inbox/Projects")
    p.add_argument("--from", dest="from_", metavar="X", help="sender name or address contains X")
    p.add_argument("--to", help="To/CC contains X")
    p.add_argument("--subject", help="subject contains X")
    p.add_argument("--body", help="body contains X (slow without dates)")
    p.add_argument("--text", help="subject OR body contains X")
    p.add_argument("--since", help="received on/after YYYY-MM-DD")
    p.add_argument("--until", help="received on/before YYYY-MM-DD")
    p.add_argument("--has-attachments", action="store_true")
    p.add_argument("--unread", action="store_true")
    p.add_argument("--no-recurse", action="store_true", help="do not search subfolders")
    p.add_argument("--limit", type=int, default=50)


def build_parser():
    p, sub = make_parser(TOOL, "Read-only classic Outlook access via COM.")
    sub.add_parser("doctor", help="check environment")
    sub.add_parser("stores", help="list stores")
    f = sub.add_parser("folders", help="folder tree")
    f.add_argument("--store")
    f.add_argument("--depth", type=int, default=4)
    s = sub.add_parser("search", help="search mail")
    add_search_args(s)
    gp = sub.add_parser("get", help="read one message")
    gp.add_argument("entry_id")
    gp.add_argument("--store-id")
    gp.add_argument("--headers", action="store_true")
    gp.add_argument("--max-body", type=int, default=8000)
    sa = sub.add_parser("save-attachments", help="save attachments")
    sa.add_argument("entry_id")
    sa.add_argument("--store-id")
    sa.add_argument("--out", required=True)
    sa.add_argument("--index", type=int)
    ex = sub.add_parser("export", help="save a message to disk")
    ex.add_argument("entry_id")
    ex.add_argument("--store-id")
    ex.add_argument("--out", required=True)
    ex.add_argument("--format", choices=sorted(SAVE_FORMATS), default="msg")
    return p


HANDLERS = {
    "doctor": cmd_doctor, "stores": cmd_stores, "folders": cmd_folders, "search": cmd_search,
    "get": cmd_get, "save-attachments": cmd_save_attachments, "export": cmd_export,
}

if __name__ == "__main__":
    run_cli(TOOL, build_parser(), HANDLERS)
