"""Shared helpers for goal-framework CLIs.

Every CLI prints exactly ONE JSON object to stdout:
    {"schema": "goal-tool/1", "tool": ..., "command": ..., "ok": bool,
     "data": ..., "warnings": [...], "truncated": bool, "error": {...}?}
Exit codes: 0 ok, 2 bad input, 3 environment unavailable, 1 unexpected error.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import re
import sys
import traceback
from pathlib import Path

SCHEMA = "goal-tool/1"
ROOT = Path(__file__).resolve().parent.parent  # project root (parent of tools/)

try:  # make sure non-ASCII mail content never crashes the console
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
except Exception:
    pass


class ToolError(Exception):
    """An expected failure with a stable code and an optional user-facing hint."""

    def __init__(self, code: str, message: str, hint: str | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.hint = hint

    @property
    def exit_code(self) -> int:
        return 3 if self.code.startswith("ENV_") else 2


class Result:
    """Collects warnings / truncation while a command runs."""

    def __init__(self) -> None:
        self.warnings: list[str] = []
        self.truncated = False

    def warn(self, msg: str) -> None:
        if msg not in self.warnings:
            self.warnings.append(msg)


def emit(tool: str, command: str, ok: bool, data=None, result: Result | None = None, error: dict | None = None) -> None:
    out = {
        "schema": SCHEMA,
        "tool": tool,
        "command": command,
        "ok": ok,
        "data": data,
        "warnings": result.warnings if result else [],
        "truncated": result.truncated if result else False,
    }
    if error:
        out["error"] = error
    sys.stdout.write(json.dumps(out, ensure_ascii=False, default=_json_default) + "\n")
    sys.stdout.flush()


def _json_default(o):
    if isinstance(o, (_dt.datetime, _dt.date)):
        return o.isoformat()
    if isinstance(o, Path):
        return str(o)
    return str(o)


def run_cli(tool: str, parser: argparse.ArgumentParser, handlers: dict) -> None:
    """Parse args, dispatch to handlers[command](args, result), emit JSON, exit."""
    command = "?"
    try:
        args = parser.parse_args()
        command = args.command
        result = Result()
        data = handlers[command](args, result)
        emit(tool, command, True, data, result)
        sys.exit(0)
    except ToolError as e:
        err = {"code": e.code, "message": e.message}
        if e.hint:
            err["hint"] = e.hint
        emit(tool, command, False, error=err)
        sys.exit(e.exit_code)
    except SystemExit:
        raise
    except Exception as e:  # unexpected: keep the envelope, include a short trace
        tb = traceback.format_exc().strip().splitlines()[-6:]
        emit(tool, command, False, error={"code": "UNEXPECTED", "message": f"{type(e).__name__}: {e}", "trace": tb})
        sys.exit(1)


class JsonArgParser(argparse.ArgumentParser):
    """argparse that reports usage errors as a JSON envelope instead of plain text."""

    tool_name = "tool"

    def error(self, message):  # noqa: D401
        emit(self.tool_name, "usage", False, error={"code": "BAD_ARGS", "message": message, "hint": self.format_usage().strip()})
        sys.exit(2)


def make_parser(tool: str, description: str) -> tuple[JsonArgParser, argparse._SubParsersAction]:
    JsonArgParser.tool_name = tool
    p = JsonArgParser(prog=f"tools/run {tool}", description=description)
    sub = p.add_subparsers(dest="command", required=True, parser_class=JsonArgParser)
    return p, sub


# ----------------------------------------------------------------- small utilities

def clip(text, n: int) -> tuple[str, bool]:
    """Trim text to n chars; returns (text, was_clipped)."""
    if text is None:
        return "", False
    text = str(text).replace("\r\n", "\n")
    text = re.sub(r"\n{3,}", "\n\n", text)
    if n and len(text) > n:
        return text[:n] + f"\n...[clipped {len(text) - n} chars]", True
    return text, False


def snippet(text, n: int = 200) -> str:
    s = re.sub(r"\s+", " ", str(text or "")).strip()
    return s[:n] + ("..." if len(s) > n else "")


def parse_date(s: str | None, end_of_day: bool = False) -> _dt.datetime | None:
    if not s:
        return None
    try:
        d = _dt.datetime.strptime(s, "%Y-%m-%d")
    except ValueError:
        raise ToolError("BAD_DATE", f"Date '{s}' is not YYYY-MM-DD")
    if end_of_day:
        d = d + _dt.timedelta(days=1) - _dt.timedelta(seconds=1)
    return d


def safe_filename(name: str, default: str = "file") -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(name or "")).strip(" .")
    return (name or default)[:180]


def unique_path(directory: Path, name: str) -> Path:
    p = directory / name
    stem, suf, i = p.stem, p.suffix, 1
    while p.exists():
        p = directory / f"{stem} ({i}){suf}"
        i += 1
    return p


def load_config() -> dict:
    """tools/config.json (optional) - per-machine settings, not committed."""
    p = ROOT / "tools" / "config.json"
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception as e:
            raise ToolError("BAD_CONFIG", f"tools/config.json is not valid JSON: {e}")
    return {}


def is_windows() -> bool:
    return os.name == "nt"
