"""barracuda - read-only access to Barracuda Message Archiver data on a Windows PC.

Two paths (the archiver has no documented message-search API):
  1. Synced archive store: Barracuda Archive Search for Outlook syncs archived mail into a
     store inside classic Outlook. Searched through Outlook COM (reuses outlook_cli).
  2. EML export: search results exported from the archiver web UI as .eml files or .zip.

    bash tools/run barracuda doctor
    bash tools/run barracuda stores
    bash tools/run barracuda search --from acme.com --since 2019-01-01
    bash tools/run barracuda get <ENTRY_ID> --store-id <ID>
    bash tools/run barracuda eml-search --dir "C:/Users/me/Downloads/archive-export" --subject invoice
    bash tools/run barracuda eml-get "export.zip!msgs/0001.eml" --dir "C:/Users/me/Downloads/archive-export"
"""
from __future__ import annotations

import email
import email.policy
import email.utils
import hashlib
import os
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (  # noqa: E402
    Result, ToolError, clip, is_windows, load_config, make_parser, parse_date, run_cli,
    safe_filename, snippet, unique_path,
)
import outlook_cli as ol  # noqa: E402

TOOL = "barracuda"
MAX_EML_SCAN = 50_000
MAX_EML_BYTES = 50 * 1024 * 1024


# ===================================================================== add-in detection

def addin_status() -> dict:
    local = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    base = Path(local) / "Barracuda" / "Message Archiver" / "Outlook Add-In"
    status = {
        "addin_registered": None,
        "addin_keys": [],
        "cache_dir": str(base / "Cache"),
        "cache_dir_exists": (base / "Cache").exists(),
        "stub_store_dir": str(base / "stores"),
        "stub_store_dir_exists": (base / "stores").exists(),
    }
    if is_windows():
        try:
            import winreg  # type: ignore
            found = []
            for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                for path in (r"Software\Microsoft\Office\Outlook\Addins",
                             r"Software\WOW6432Node\Microsoft\Office\Outlook\Addins"):
                    try:
                        with winreg.OpenKey(hive, path) as k:
                            i = 0
                            while True:
                                try:
                                    name = winreg.EnumKey(k, i)
                                except OSError:
                                    break
                                if "barracuda" in name.lower() or "archiver" in name.lower():
                                    found.append(name)
                                i += 1
                    except OSError:
                        continue
            status["addin_keys"] = sorted(set(found))
            status["addin_registered"] = bool(found)
        except ImportError:
            pass
    return status


def archive_stores(pattern: str | None):
    """Stores that look like the Barracuda archive, or those matching --store."""
    if pattern:
        return ol.find_stores(pattern)
    hits = [s for s in ol.all_stores() if ol.store_info(s)["looks_like_archive"]]
    if not hits:
        raise ToolError(
            "ENV_NO_ARCHIVE_STORE",
            "No Outlook store looks like a Barracuda archive store.",
            hint=("Check Outlook > File > Barracuda Networks > Configure > Archive Stores and add/sync a store "
                  "(the admin must run nightly folder-sync jobs). If the store has an unusual name, pass --store "
                  "or set archive_store_hints in tools/config.json. Alternatively export results from the archiver "
                  "web UI as EML and use eml-search."))
    return hits


def export_dir(arg: str | None) -> Path:
    d = arg or os.environ.get("BARRACUDA_EXPORT_DIR") or load_config().get("barracuda", {}).get("export_dir")
    if not d:
        raise ToolError("ENV_NO_EXPORT_DIR", "No EML export directory given.",
                        hint="Pass --dir, set BARRACUDA_EXPORT_DIR, or set barracuda.export_dir in tools/config.json.")
    p = Path(os.path.expandvars(os.path.expanduser(d)))
    if not p.exists():
        raise ToolError("ENV_NO_EXPORT_DIR", f"Export directory does not exist: {p}")
    return p


# ===================================================================== EML handling

def iter_eml(root: Path, res: Result):
    """Yield (id, raw_bytes). id = relative path, or 'zip_rel_path!member' for zip members."""
    n = 0
    for path in sorted(root.rglob("*")):
        if n >= MAX_EML_SCAN:
            res.truncated = True
            res.warn(f"Stopped after scanning {MAX_EML_SCAN} messages.")
            return
        rel = path.relative_to(root).as_posix()
        low = path.name.lower()
        if low.endswith(".eml") and path.is_file():
            if path.stat().st_size > MAX_EML_BYTES:
                res.warn(f"Skipped oversized file {rel}")
                continue
            n += 1
            yield rel, path.read_bytes()
        elif low.endswith(".zip") and path.is_file():
            try:
                with zipfile.ZipFile(path) as z:
                    for info in z.infolist():
                        if not info.filename.lower().endswith(".eml") or info.is_dir():
                            continue
                        if info.file_size > MAX_EML_BYTES:
                            res.warn(f"Skipped oversized member {rel}!{info.filename}")
                            continue
                        n += 1
                        yield f"{rel}!{info.filename}", z.read(info)
                        if n >= MAX_EML_SCAN:
                            break
            except zipfile.BadZipFile:
                res.warn(f"Not a valid zip: {rel}")


def read_eml(root: Path, eml_id: str) -> bytes:
    if "!" in eml_id:
        zrel, member = eml_id.split("!", 1)
        zpath = (root / zrel).resolve()
        _inside(root, zpath)
        try:
            with zipfile.ZipFile(zpath) as z:
                return z.read(member)
        except (KeyError, FileNotFoundError, zipfile.BadZipFile):
            raise ToolError("ITEM_NOT_FOUND", f"Message '{eml_id}' not found.")
    p = (root / eml_id).resolve()
    _inside(root, p)
    if not p.is_file():
        raise ToolError("ITEM_NOT_FOUND", f"Message '{eml_id}' not found.")
    return p.read_bytes()


def _inside(root: Path, p: Path) -> None:
    try:
        p.relative_to(root.resolve())
    except ValueError:
        raise ToolError("BAD_ID", "Message id points outside the export directory.")


def parse(raw: bytes):
    return email.message_from_bytes(raw, policy=email.policy.default)


def body_text(msg) -> str:
    part = msg.get_body(preferencelist=("plain", "html"))
    if part is None:
        return ""
    try:
        text = part.get_content()
    except Exception:
        payload = part.get_payload(decode=True) or b""
        text = payload.decode(part.get_content_charset() or "utf-8", errors="replace")
    if part.get_content_type() == "text/html":
        import html
        import re
        text = re.sub(r"(?is)<(script|style).*?</\1>", " ", text)
        text = re.sub(r"(?s)<br\s*/?>|</p>|</div>|</tr>", "\n", text)
        text = html.unescape(re.sub(r"(?s)<[^>]+>", " ", text))
    return text


def eml_attachments(msg) -> list[dict]:
    out = []
    for i, part in enumerate(msg.iter_attachments(), start=1):
        payload = part.get_payload(decode=True) or b""
        out.append({"index": i, "filename": part.get_filename() or f"attachment{i}",
                    "content_type": part.get_content_type(), "size": len(payload)})
    return out


def eml_date(msg):
    try:
        d = email.utils.parsedate_to_datetime(str(msg.get("Date", "")))
        return d.astimezone().replace(tzinfo=None) if d.tzinfo else d
    except Exception:
        return None


def hdr(msg, name) -> str:
    try:
        return str(msg.get(name, "") or "")
    except Exception:
        return ""


def eml_summary(eml_id: str, msg, raw: bytes) -> dict:
    d = eml_date(msg)
    name, addr = email.utils.parseaddr(hdr(msg, "From"))
    return {
        "id": eml_id,
        "internet_message_id": hdr(msg, "Message-ID") or None,
        "received": d.isoformat() if d else None,
        "from_name": name,
        "from_email": addr,
        "to": hdr(msg, "To"),
        "cc": hdr(msg, "Cc"),
        "subject": hdr(msg, "Subject"),
        "attachments": sum(1 for _ in msg.iter_attachments()),
        "size": len(raw),
        "sha1": hashlib.sha1(raw).hexdigest()[:16],
    }


def matches(msg, a, cache: dict) -> bool:
    def has(field_val: str, needle: str | None) -> bool:
        return needle is None or needle.lower() in field_val.lower()

    if not has(hdr(msg, "From"), a.from_):
        return False
    if a.to and not (has(hdr(msg, "To"), a.to) or has(hdr(msg, "Cc"), a.to)):
        return False
    if not has(hdr(msg, "Subject"), a.subject):
        return False
    since, until = parse_date(a.since), parse_date(a.until, end_of_day=True)
    if since or until:
        d = eml_date(msg)
        if d is None or (since and d < since) or (until and d > until):
            return False
    if a.has_attachments and not any(True for _ in msg.iter_attachments()):
        return False
    if a.body or a.text:
        if "body" not in cache:
            cache["body"] = body_text(msg)
        if a.body and not has(cache["body"], a.body):
            return False
        if a.text and not (has(hdr(msg, "Subject"), a.text) or has(cache["body"], a.text)):
            return False
    return True


# ===================================================================== commands

def cmd_doctor(a, res: Result) -> dict:
    info = {"addin": addin_status(), "outlook": None, "archive_stores": [], "export_dir": None,
            "recommended_path": None}
    try:
        info["outlook"] = ol.cmd_doctor(a, res)
        if info["outlook"].get("connected"):
            info["archive_stores"] = [ol.store_info(s) for s in ol.all_stores() if ol.store_info(s)["looks_like_archive"]]
    except ToolError as e:
        res.warn(f"{e.code}: {e.message}")
    try:
        d = export_dir(None)
        info["export_dir"] = {"path": str(d), "eml_or_zip_files": sum(1 for p in d.rglob("*") if p.suffix.lower() in (".eml", ".zip"))}
    except ToolError:
        pass
    if info["archive_stores"]:
        info["recommended_path"] = "search (synced archive store in Outlook)"
    elif info["export_dir"]:
        info["recommended_path"] = "eml-search (export directory)"
    else:
        info["recommended_path"] = None
        res.warn("No archive store and no export dir. Sync Archive Stores in the Outlook add-in, or export EML from the archiver web UI.")
    if info["addin"]["addin_registered"] is False:
        res.warn("Barracuda Archive Search for Outlook add-in not found in the registry.")
    return info


def cmd_stores(a, res: Result) -> dict:
    stores = [ol.store_info(s) for s in archive_stores(None)]
    return {"count": len(stores), "stores": stores}


def cmd_search(a, res: Result) -> dict:
    a.folder, a.no_recurse, a.unread = None, False, False
    stores = archive_stores(a.store)
    out = ol.do_search(a, res, store_filter=stores)
    for m in out["messages"]:
        m["source"] = "barracuda-synced-store"
    return out


def cmd_get(a, res: Result) -> dict:
    d = ol.item_detail(ol.get_item(a.entry_id, a.store_id), a.max_body, a.headers, res)
    d["source"] = "barracuda-synced-store"
    if d.get("size") and d["size"] < 8192 and d.get("attachments") == 0 and "barracuda" in (d.get("body") or "").lower():
        res.warn("This looks like a stub; the full message may only be on the archiver. Open it in Outlook to retrieve it.")
    return d


def cmd_save_attachments(a, res: Result) -> dict:
    return ol.save_attachments(ol.get_item(a.entry_id, a.store_id), a.out, None, res)


def cmd_eml_search(a, res: Result) -> dict:
    root = export_dir(a.dir)
    limit = max(1, min(a.limit, ol.MAX_LIMIT))
    rows, scanned, bad = [], 0, 0
    for eml_id, raw in iter_eml(root, res):
        scanned += 1
        try:
            msg = parse(raw)
        except Exception:
            bad += 1
            continue
        if matches(msg, a, {}):
            r = eml_summary(eml_id, msg, raw)
            r["snippet"] = snippet(body_text(msg), 200)
            r["source"] = "barracuda-eml-export"
            rows.append(r)
    if bad:
        res.warn(f"{bad} files could not be parsed as email.")
    rows.sort(key=lambda r: r.get("received") or "", reverse=True)
    if len(rows) > limit:
        res.truncated = True
        rows = rows[:limit]
    return {"dir": str(root), "scanned": scanned, "count": len(rows), "messages": rows}


def cmd_eml_get(a, res: Result) -> dict:
    root = export_dir(a.dir)
    raw = read_eml(root, a.id)
    msg = parse(raw)
    d = eml_summary(a.id, msg, raw)
    body, clipped = clip(body_text(msg), a.max_body)
    if clipped:
        res.truncated = True
    d.update({"source": "barracuda-eml-export", "date_header": hdr(msg, "Date"), "bcc": hdr(msg, "Bcc"),
              "reply_to": hdr(msg, "Reply-To"), "body": body, "attachment_list": eml_attachments(msg)})
    if a.headers:
        d["headers"] = [[k, str(v)] for k, v in msg.items()][:200]
    return d


def cmd_eml_save_attachments(a, res: Result) -> dict:
    root = export_dir(a.dir)
    msg = parse(read_eml(root, a.id))
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    saved = []
    for i, part in enumerate(msg.iter_attachments(), start=1):
        name = safe_filename(part.get_filename() or f"attachment{i}")
        path = unique_path(out, name)
        path.write_bytes(part.get_payload(decode=True) or b"")
        saved.append({"index": i, "path": str(path), "size": path.stat().st_size})
    return {"count": len(saved), "saved": saved}


# ===================================================================== argparse

def build_parser():
    p, sub = make_parser(TOOL, "Read-only Barracuda Message Archiver access (synced Outlook store or EML export).")
    sub.add_parser("doctor")
    sub.add_parser("stores")
    s = sub.add_parser("search")
    s.add_argument("--store", help="archive store name (default: auto-detect)")
    ol.add_search_args(s, store_option=False)
    gp = sub.add_parser("get")
    gp.add_argument("entry_id")
    gp.add_argument("--store-id")
    gp.add_argument("--headers", action="store_true")
    gp.add_argument("--max-body", type=int, default=8000)
    sa = sub.add_parser("save-attachments")
    sa.add_argument("entry_id")
    sa.add_argument("--store-id")
    sa.add_argument("--out", required=True)

    es = sub.add_parser("eml-search")
    es.add_argument("--dir")
    for flag, dest in (("--from", "from_"), ("--to", "to"), ("--subject", "subject"), ("--body", "body"),
                       ("--text", "text"), ("--since", "since"), ("--until", "until")):
        es.add_argument(flag, dest=dest)
    es.add_argument("--has-attachments", action="store_true")
    es.add_argument("--limit", type=int, default=50)
    eg = sub.add_parser("eml-get")
    eg.add_argument("id")
    eg.add_argument("--dir")
    eg.add_argument("--headers", action="store_true")
    eg.add_argument("--max-body", type=int, default=8000)
    ea = sub.add_parser("eml-save-attachments")
    ea.add_argument("id")
    ea.add_argument("--dir")
    ea.add_argument("--out", required=True)
    return p


HANDLERS = {
    "doctor": cmd_doctor, "stores": cmd_stores, "search": cmd_search, "get": cmd_get,
    "save-attachments": cmd_save_attachments, "eml-search": cmd_eml_search, "eml-get": cmd_eml_get,
    "eml-save-attachments": cmd_eml_save_attachments,
}

if __name__ == "__main__":
    run_cli(TOOL, build_parser(), HANDLERS)
