"""new-worker - scaffold a worker agent and its CLI from the framework templates.

    bash tools/run new-worker jira-tickets --tool jira --purpose "Searches Jira tickets."

Creates:
  .claude/agents/workers/<name>.md   (from .claude/goal-framework/WORKER_TEMPLATE.md)
  tools/<tool>_cli.py                (from tools/TEMPLATE_cli.py, skipped if it exists)
"""
from __future__ import annotations

import argparse
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import ROOT, Result, ToolError, emit  # noqa: E402


def main() -> None:
    p = argparse.ArgumentParser(prog="tools/run new-worker")
    p.add_argument("name", help="agent name, lowercase-with-dashes, e.g. jira-tickets")
    p.add_argument("--tool", help="CLI name (default: first word of name)")
    p.add_argument("--purpose", default="__ONE_LINE_PURPOSE__", help="one sentence for the description")
    a = p.parse_args()
    res = Result()
    try:
        if not re.fullmatch(r"[a-z][a-z0-9-]{1,62}", a.name):
            raise ToolError("BAD_NAME", "Name must be lowercase letters, digits and dashes (e.g. jira-tickets).")
        tool = a.tool or a.name.split("-")[0]
        if not re.fullmatch(r"[a-z][a-z0-9_-]{1,40}", tool):
            raise ToolError("BAD_NAME", "Tool name must be lowercase letters, digits, dashes or underscores.")
        agent_path = ROOT / ".claude" / "agents" / "workers" / f"{a.name}.md"
        if agent_path.exists():
            raise ToolError("EXISTS", f"{agent_path.relative_to(ROOT).as_posix()} already exists.")
        tmpl = (ROOT / ".claude" / "goal-framework" / "WORKER_TEMPLATE.md").read_text(encoding="utf-8")
        purpose = a.purpose.strip().rstrip(".") + "." if a.purpose != "__ONE_LINE_PURPOSE__" else a.purpose
        agent_path.write_text(tmpl.replace("__NAME__", a.name).replace("__TOOL__", tool)
                              .replace("__ONE_LINE_PURPOSE__", purpose), encoding="utf-8")
        created = [agent_path.relative_to(ROOT).as_posix()]

        cli_path = ROOT / "tools" / f"{tool.replace('-', '_')}_cli.py"
        if cli_path.exists():
            res.warn(f"{cli_path.relative_to(ROOT).as_posix()} exists; left unchanged")
        else:
            src = (ROOT / "tools" / "TEMPLATE_cli.py").read_text(encoding="utf-8")
            cli_path.write_text(src.replace("__TOOL__", tool), encoding="utf-8")
            created.append(cli_path.relative_to(ROOT).as_posix())
        emit("new-worker", "create", True, {
            "created": created,
            "next_steps": [
                "Fill in description, Capabilities and the CLI table in the agent file",
                "Implement the commands in the CLI (keep them read-only unless you add an approval gate)",
                f"Test: bash tools/run {tool} doctor",
                "Check discovery: bash tools/run registry",
            ]}, res)
    except ToolError as e:
        emit("new-worker", "create", False, error={"code": e.code, "message": e.message})
        sys.exit(2)


if __name__ == "__main__":
    main()
