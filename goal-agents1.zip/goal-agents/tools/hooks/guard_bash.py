"""PreToolUse hook for worker agents: allow only single `tools/run ...` commands.

Claude Code passes the tool call as JSON on stdin. Exit 0 = allow, exit 2 = block
(stderr is shown to the agent so it can correct itself).
"""
from __future__ import annotations

import json
import re
import shlex
import sys

ALLOWED = re.compile(r'^(bash\s+)?("?\$CLAUDE_PROJECT_DIR/)?(\./)?tools/run"?\s+[a-z0-9_-]+(\s|$)')
OPERATORS = {";", "&&", "||", "|", "&", ">", ">>", "<", "<<", "|&", ";;", "(", ")"}


def block(msg: str) -> None:
    sys.stderr.write(
        f"Blocked by worker policy: {msg}\n"
        "Workers may only run one domain CLI per call, e.g.: bash tools/run outlook search --from x\n"
        "Use the Read/Write/Glob/Grep tools for files.\n")
    sys.exit(2)


def main() -> None:
    try:
        data = json.load(sys.stdin)
    except Exception:
        block("could not read hook input")
    cmd = str((data.get("tool_input") or {}).get("command", "")).strip()
    if not cmd:
        sys.exit(0)
    if "\n" in cmd or "`" in cmd or "$(" in cmd:
        block("newlines, backticks and $(...) are not allowed")
    try:
        lex = shlex.shlex(cmd, posix=True, punctuation_chars=True)
        lex.whitespace_split = True
        tokens = list(lex)
    except ValueError as e:
        block(f"could not parse command ({e})")
    if any(t in OPERATORS for t in tokens):
        block("command chaining, pipes and redirects are not allowed")
    if not ALLOWED.match(cmd):
        block("only 'bash tools/run <tool> ...' commands are allowed")
    sys.exit(0)


if __name__ == "__main__":
    main()
