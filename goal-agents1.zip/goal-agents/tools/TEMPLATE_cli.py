"""__TOOL__ - <one line: what system this reads>.

    bash tools/run __TOOL__ doctor
    bash tools/run __TOOL__ search --query X --limit 20
    bash tools/run __TOOL__ get <ID>

Contract: print one JSON envelope (handled by run_cli), exit 0/2/3/1.
Raise ToolError("ENV_...", msg, hint=...) when the environment is not ready, so the
worker reports `blocked` instead of retrying. Keep commands read-only.
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import Result, ToolError, make_parser, run_cli  # noqa: E402

TOOL = "__TOOL__"


def cmd_doctor(a, res: Result) -> dict:
    # Check credentials/env vars/connectivity here. Never print secrets.
    return {"ready": False, "notes": "implement me"}


def cmd_search(a, res: Result) -> dict:
    raise ToolError("NOT_IMPLEMENTED", "search is not implemented yet")


def cmd_get(a, res: Result) -> dict:
    raise ToolError("NOT_IMPLEMENTED", "get is not implemented yet")


def build_parser():
    p, sub = make_parser(TOOL, "<describe>")
    sub.add_parser("doctor")
    s = sub.add_parser("search")
    s.add_argument("--query")
    s.add_argument("--limit", type=int, default=50)
    g = sub.add_parser("get")
    g.add_argument("id")
    return p


HANDLERS = {"doctor": cmd_doctor, "search": cmd_search, "get": cmd_get}

if __name__ == "__main__":
    run_cli(TOOL, build_parser(), HANDLERS)
