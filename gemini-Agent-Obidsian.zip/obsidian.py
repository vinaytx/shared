"""Obsidian vault layer.

The knowledge base is already a folder of Markdown with YAML frontmatter, which
is exactly what an Obsidian vault is. This module makes that folder *idiomatic*
Obsidian rather than merely compatible:

  - Every artefact is a .md file. Obsidian reads note properties only from
    Markdown frontmatter, so schema cards written as .yaml are invisible to
    Properties, Bases, and search. That is the one hard reason the card format
    changed.
  - Property names and types are stable, because Bases and Properties key off
    them. A property that is sometimes a string and sometimes a list will break
    a table view silently.
  - Provenance is expressed as wikilinks, so the Obsidian graph *is* the
    lineage graph: a finding links to the schema cards it used and the run that
    produced it, and backlinks tell you which findings depend on a table before
    you change its card.

Agents still write to the filesystem directly. Obsidian is the human read and
curate layer, not a dependency of the pipeline.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Any

import yaml

# Reserved by Obsidian itself; do not repurpose.
OBSIDIAN_RESERVED = {"tags", "aliases", "cssclasses"}

# One vocabulary, used by every agent and every .base dashboard.
NOTE_TYPES = ("schema-card", "doc", "skill", "finding", "run")
STATUSES = ("draft", "validated", "warned", "rejected", "deprecated")

ILLEGAL = re.compile(r'[\\/:"*?<>|#^\[\]]+')


def vault_safe(name: str) -> str:
    """Obsidian forbids some characters in filenames and link targets.

    Fully-qualified table names contain dots, which are legal, but pipes,
    brackets and hashes are not -- and a hash in a link target is parsed as a
    heading reference.
    """
    return ILLEGAL.sub("-", name).strip(" .-\t")[:100].strip(" .-") or "untitled"


def wikilink(target: str, alias: str | None = None) -> str:
    target = vault_safe(target)
    return f"[[{target}|{alias}]]" if alias else f"[[{target}]]"


def _iso_date(value: Any = None) -> str:
    """Bases sorts and filters dates properly only when they parse as dates."""
    if isinstance(value, str) and value:
        return value[:10]
    return datetime.now(timezone.utc).date().isoformat()


def normalise_properties(meta: dict) -> dict:
    """Coerce frontmatter into stable Obsidian property types.

    Type drift is the failure mode that quietly breaks Bases: one note where
    `join_keys` is a bare string and a table column stops aggregating.
    """
    out: dict[str, Any] = {}

    out["type"] = meta.get("type") or "doc"
    out["title"] = str(meta.get("title") or meta.get("id") or "untitled")
    out["status"] = meta.get("status") if meta.get("status") in STATUSES else "draft"

    # numbers stay numbers
    try:
        out["confidence"] = round(float(meta.get("confidence", 0.5)), 2)
    except (TypeError, ValueError):
        out["confidence"] = 0.5

    # dates stay dates
    out["updated"] = _iso_date(meta.get("updated"))
    if meta.get("validated_at"):
        out["validated"] = _iso_date(meta["validated_at"])

    # lists stay lists, even when there is one element
    for key in ("tags", "join_keys", "kpi_columns", "gotchas", "entities",
                "evidence", "related", "sources", "columns"):
        val = meta.get(key)
        if val is None:
            continue
        out[key] = [str(v) for v in val] if isinstance(val, (list, tuple)) else [str(val)]

    out.setdefault("tags", [])
    if "ne-agents" not in out["tags"]:
        out["tags"] = ["ne-agents", *out["tags"]]

    # pass through the scalars agents set, minus anything we already handled
    handled = set(out) | {"validated_at", "kind", "body"}
    for k, v in meta.items():
        if k in handled or k in OBSIDIAN_RESERVED:
            continue
        if isinstance(v, (str, int, float, bool)) or v is None:
            out[k] = v
    return out


def render_note(body: str, meta: dict) -> str:
    """Frontmatter + body, in the order Obsidian expects."""
    props = normalise_properties(meta)
    fm = yaml.safe_dump(props, sort_keys=False, allow_unicode=True, default_flow_style=False)
    return f"---\n{fm}---\n\n{body.strip()}\n"


# --- note bodies ---------------------------------------------------------
def schema_card_body(card: dict) -> str:
    """A schema card a human can read and an agent can quote verbatim."""
    lines = [f"> {card.get('description', 'No description recorded.')}", ""]
    lines += [f"**Grain**: {card.get('grain') or '_not inferred_'}", ""]

    lines.append("## Columns\n")
    lines.append("| Column | Type | Null | Notes |")
    lines.append("|---|---|---|---|")
    for c in card.get("columns", []):
        note = (c.get("comment") or c.get("semantic") or "").replace("|", "\\|")
        lines.append(f"| `{c.get('column_name')}` | {c.get('full_data_type')} "
                     f"| {c.get('is_nullable', '?')} | {note} |")

    if card.get("join_keys"):
        lines += ["", "## Joins", ""]
        lines += [f"- `{k}`" for k in card["join_keys"]]
    if card.get("kpi_columns"):
        lines += ["", "## Measures", ""]
        lines += [f"- `{k}`" for k in card["kpi_columns"]]
    if card.get("gotchas"):
        lines += ["", "## Gotchas", ""]
        lines += [f"- {g}" for g in card["gotchas"]]

    lines += ["", "## Verified SQL", "",
              "_Queries that ran correctly against this table. "
              "Promote the good ones into the Genie agent's example_question_sqls._", ""]
    return "\n".join(lines)


def finding_body(finding: dict, run_id: str, goal: str,
                 schema_links: list[str] | None = None) -> str:
    lines = [f"> {finding.get('statement', '')}", ""]
    lines += [f"**Confidence**: {finding.get('confidence')}",
              f"**Run**: {wikilink(run_id)}",
              f"**Goal**: {goal}", ""]
    if finding.get("evidence"):
        lines += ["## Evidence", ""] + [f"- {e}" for e in finding["evidence"]] + [""]
    if finding.get("next_check"):
        lines += ["## Next check", "", finding["next_check"], ""]
    if schema_links:
        lines += ["## Tables used", ""] + [f"- {wikilink(s)}" for s in schema_links] + [""]
    return "\n".join(lines)


def skill_body(goal: str, steps: list[dict], failure_modes: list[str],
               schema_links: list[str] | None = None) -> str:
    lines = ["## When to use", "", goal, "", "## Procedure", ""]
    for i, s in enumerate(steps, 1):
        lines.append(f"{i}. Ask Genie: {s.get('question')}")
        sql = (s.get("sql") or "").strip()
        if sql:
            lines += ["", "   ```sql", *[f"   {ln}" for ln in sql.splitlines()[:20]],
                      "   ```", ""]
    lines += ["## Known failure modes", ""] + [f"- {f}" for f in failure_modes]
    if schema_links:
        lines += ["", "## Tables used", ""] + [f"- {wikilink(s)}" for s in schema_links]
    return "\n".join(lines)
