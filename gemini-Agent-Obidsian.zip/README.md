# ne-agents

Autonomous, goal-driven agents over **Databricks Genie**, with **Gemini CLI** as
the reasoning engine. Modular by construction: adding an agent is a directory
plus a class, never an edit to an existing agent.

Everything runs today with `--fake` and no credentials. Two environment
variables switch it to your real workspace.

```
python3 -m pytest tests -q
python3 cli.py --fake run "correlate throughput degradation with packet loss" --static
```

---

## 1. Ten-minute start

```bash
pip install -r requirements.txt

# Model: your Gemini Code Assist Standard/Enterprise licence keeps Gemini CLI
# working. Authenticate once, interactively.
npm install -g @google/gemini-cli
gemini            # sign in, then /quit

# Databricks: reuse your existing interactive access
databricks auth login --host https://your-workspace.cloud.databricks.com

cp .env.example .env    # fill in host, space id, warehouse id
source .env

python cli.py doctor
```

`doctor` checks, in order: Gemini CLI on PATH, Gemini CLI actually responding,
`DATABRICKS_HOST`, Databricks auth (and which method resolved), the Genie space,
the SQL warehouse, the knowledge base, and the agent registry. Fix the FAIL
lines before running anything live.

Then:

```bash
python cli.py ask "show hourly throughput by network element for the last 7 days"
python cli.py schema sync -c network -s kpi
python cli.py run "find network elements whose throughput degraded this week"
python cli.py runs --show <run_id>
```

---

## 2. How it fits together

```
                       ┌───────────────────────────┐
   goal ──────────────▶│  Orchestrator (loop.py)   │
                       │  plan → dispatch → budget │
                       └─────┬──────────────┬──────┘
                             │              │
              ┌──────────────▼───┐    ┌─────▼────────────┐
              │ Agents           │    │ Ledger (SQLite)  │
              │  genie_comms     │    │ runs/steps/msgs  │
              │  schema_agent    │    │ + artifacts      │
              │  analysis_agent  │    └──────────────────┘
              │  validator_agent │
              │  curator_agent   │    ┌──────────────────┐
              │  doc_retrieval   │───▶│ Knowledge base   │
              │  doc_curation    │    │ schema/docs/     │
              └────┬────────┬────┘    │ skills + FTS5    │
                   │        │         └──────────────────┘
        ┌──────────▼──┐  ┌──▼──────────────┐
        │ llm/invoke  │  │ connectors/     │
        │ gemini → agy│  │ genie, warehouse│
        └─────────────┘  └─────────────────┘
```

Agents never import each other. They exchange `Envelope`s through the ledger,
and `Orchestrator._wire` holds the entire inter-agent data flow in one readable
function.

---

## 3. Genie: three backends, one contract

`connectors/genie.py` exposes `ask(question, conversation_id) -> GenieAnswer`
with four implementations. Switch with `NE_GENIE_BACKEND`.

| Backend | When | Trade-off |
|---|---|---|
| `rest` **(default)** | Conversation API with a token or OAuth | Structured SQL + rows, parallel-safe, audited in Unity Catalog |
| `mcp` | Databricks managed MCP server, driven through Gemini CLI's own MCP client | No auth code to write; but the Genie Space MCP server invokes Genie as a tool, so **conversation history is not carried** — context must be replayed in the prompt |
| `browser` | chrome-devtools-mcp against the Genie UI | Last resort. One browser = no parallelism, session expiry mid-run, no structured SQL access |
| `fake` | tests and dry runs | Deterministic, zero credentials |

The REST backend implements the documented polling discipline: poll from 2s with
exponential backoff to 30s, terminal states `COMPLETED / FAILED / CANCELLED /
QUERY_RESULT_EXPIRED`, hard stop at 10 minutes.

**On auth.** Interactive OAuth (U2M) is the fastest way to get running and is
what `databricks auth login` gives you. Move to a service principal (OAuth M2M)
before anything runs unattended — a U2M token will expire mid-run and stall a
long goal loop. `DatabricksClient` handles both; only the environment changes.

**If a Genie call 404s**, the path constants are at the top of
`connectors/genie.py` (`P_START`, `P_MESSAGES`, `P_MESSAGE`, `P_ATTACH_RESULT`).
Check them against your workspace's API reference and edit in one place.

---

## 4. The knowledge layer

```
knowledgebase/
  schema/   network_kpi_ne_kpi_hourly.yaml   # structure from information_schema
                                             # + semantics from the model,
                                             # kept in separate fields
  docs/     vendor_alarm_guide.md            # summary, never the full document
  skills/   diagnose_throughput_drop.md      # runbooks, promoted not written
  index.sqlite                               # FTS5
```

Three deliberate choices:

**FTS5 before embeddings.** For a few thousand cards, full-text beats a vector
store on precision and costs nothing to operate. Add Databricks AI Search when
you can point at queries FTS5 is measurably missing — not before.

**Structure and semantics stay separate.** `columns` comes from
`information_schema`; `description`, `grain`, `join_keys`, `gotchas` come from
the model. Six months from now you can still tell which is which.

**Skills are promoted, not written.** `promote_skill` accumulates candidates in
a `skill_candidates` table and only writes a skill file once the same procedure
has succeeded in two independent runs. Without that gate the library fills with
one-off guesses that later runs treat as established practice. Inspect what is
waiting: `KnowledgeStore.skill_candidates()`.

---

## 4b. Obsidian as the human layer

`knowledgebase/` **is** an Obsidian vault. Open Obsidian → *Open folder as
vault* → point it at `knowledgebase/`, enable the **Bases** and **Properties**
core plugins, and open `_dashboards/Schema.base`.

```bash
python scripts/migrate_to_obsidian.py --dry-run   # see what would change
python scripts/migrate_to_obsidian.py
```

**The division of labour matters.** Agents write Markdown files to disk and
retrieve through SQLite FTS5. Obsidian reads, renders and lets you edit. The
pipeline must run headless on a schedule with Obsidian closed, so nothing in
`agents/` or `connectors/` may depend on Obsidian being open. The `obsidian`
MCP server in `.gemini/settings.json` is read-scoped and for interactive Gemini
CLI sessions only.

**Why schema cards are now `.md`, not `.yaml`.** Obsidian reads note properties
only from Markdown frontmatter. A `.yaml` card is invisible to Properties,
Bases and property search — it would sit in the vault as an inert attachment.
The structured data lives in frontmatter; the human-readable column table lives
in the body.

**Property types are a contract.** `_dashboards/*.base` filters on `type`,
`status`, `confidence`, `tags`, `join_keys`, `column_count`. A property that is
a string in one note and a list in another breaks a Bases column with no error
message. `core/obsidian.normalise_properties` is the single enforcement point,
covered by `tests/test_obsidian.py`.

**The graph is the lineage graph.** `curator_agent` parses the SQL Genie
actually ran, resolves the table names to schema-card ids, and writes wikilinks
into every finding and skill. Open a schema card, read its backlinks, and you
see each conclusion that would be invalidated if that table changed — which no
folder hierarchy gives you.

| Folder | Written by | Holds |
|---|---|---|
| `schema/` | `schema_agent` | one note per table |
| `docs/` | `doc_curation` | document summaries; full text stays in `runs/` |
| `findings/` | `curator_agent` | validated conclusions, linked to their tables |
| `skills/` | `curator_agent` | runbooks promoted after succeeding in 2+ runs |
| `_dashboards/` | you | Bases views |
| `_templates/` | you | note templates for hand-written cards |

Human edits are authoritative for everything except `columns` and
`column_count`, which `schema_agent` regenerates from `information_schema` on
every sync. `description`, `grain`, `gotchas` and the **Verified SQL** section
are never overwritten — that is where your own knowledge goes.

---

## 5. Safety rails that are code, not prompts

- **Budget** (`core/budget.py`) caps steps, LLM calls, Genie calls, warehouse
  queries and wall clock. Checked before every step and every backend call;
  `BudgetExceeded` aborts the run cleanly and the ledger records it.
- **Plan validation** rejects a plan naming an unregistered agent or depending
  on a step that does not exist — before a single step runs.
- **Validator** runs deterministic checks first (empty result, row explosion,
  unfiltered scan, implicit join, null-heavy sample). A deterministic fail
  cannot be talked out of by the LLM review.
- **Rows never enter a prompt.** `genie_comms` writes them to
  `runs/<run_id>/` and passes a URI plus a 10-row sample.

---

## 6. Adding an agent

1. `config/agents/<name>/agent.yaml` — name, impl, description, tool allowlist,
   `io_schema`. The description is what the planner reads.
2. `config/agents/<name>/prompt.md` — the system prompt.
3. `agents/<name>.py` — a class subclassing `agents.base.Agent` with
   `run(task, ctx) -> Envelope`.
4. A wiring rule in `Orchestrator._wire`, if it consumes another agent's output.
5. A test.

The registry discovers it on next start; the planner can use it immediately.

---

## 7. The Antigravity migration

Gemini CLI stopped serving individual Google AI Pro/Ultra and free tiers on
18 June 2026. Access via a **Gemini Code Assist Standard or Enterprise licence
is unchanged**, and Gemini CLI remains available with paid Gemini and Gemini
Enterprise Agent Platform API keys — so your setup keeps working. Antigravity
CLI is the strategic successor.

This repo is built so that migration is one file:

```bash
export NE_LLM_CMD=agy      # llm/invoke.py is the only thing that knows
python cli.py doctor
python3 -m pytest tests -q
```

`llm/invoke.py` shells out with `-p <prompt>` and optional `-m <model>`. If
Antigravity's flags differ, change `GeminiCLI._argv` and nothing else moves.
The `.gemini/` subagent definitions port across as-is — Antigravity CLI carries
skills, hooks and subagents forward.

---

## 8. What to build next

The scaffold deliberately stops short of three things:

- **Parallel fan-out.** The loop is sequential. Parallelism belongs in
  `Orchestrator.run` (dispatch independent steps concurrently); the agents need
  no changes, but `genie_comms` will need one conversation per worker.
- **The Genie Tuner.** The highest-value agent you do not yet have. A Genie
  Agent's whole configuration — instructions, `example_question_sqls`,
  `join_specs`, `sql_snippets`, `benchmarks` — is a single `serialized_space`
  JSON string readable and writable through the Management API. Feeding
  validated question/SQL pairs back into it makes Genie itself better for every
  human in the workspace, not just your agents. Watch the validation rules: IDs
  must be 32-char lowercase hex, collections must be pre-sorted by the
  documented sort key, each join spec's `sql` needs exactly two elements with a
  `--rt=FROM_RELATIONSHIP_TYPE_*--` annotation, and only one text instruction
  is allowed per agent.
- **Evals.** `config/agents/*/evals/` is the intended home. Genie's own
  benchmark questions with ground-truth SQL are the natural seed.
