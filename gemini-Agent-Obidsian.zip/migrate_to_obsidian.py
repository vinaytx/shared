#!/usr/bin/env python3
"""Convert an existing knowledgebase/ into an Obsidian vault.

Idempotent: safe to run more than once. Converts legacy .yaml schema cards to
.md notes with typed frontmatter, moves findings out of docs/ into findings/,
adds the `type` property every Bases view filters on, and rebuilds the index.

  python scripts/migrate_to_obsidian.py --dry-run
  python scripts/migrate_to_obsidian.py
"""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import yaml

from core.config import SETTINGS
from core.knowledge import FRONTMATTER, KnowledgeStore


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--root", default=None)
    args = ap.parse_args()

    root = Path(args.root or SETTINGS.knowledge_root)
    kb = KnowledgeStore(root)
    actions: list[str] = []

    for folder in ("schema", "docs", "skills", "findings", "_dashboards", "_templates"):
        (root / folder).mkdir(parents=True, exist_ok=True)

    # 1. legacy .yaml schema cards -> .md notes
    for p in (root / "schema").glob("*.yaml"):
        card = yaml.safe_load(p.read_text()) or {}
        actions.append(f"convert  {p.name} -> {p.stem}.md")
        if not args.dry_run:
            kb.put_schema_card({**card, "table": card.get("table", p.stem)})
            p.unlink()

    # 2. findings currently living in docs/ -> findings/
    for p in (root / "docs").glob("*.md"):
        m = FRONTMATTER.match(p.read_text())
        meta = (yaml.safe_load(m.group(1)) if m else {}) or {}
        tags = meta.get("tags") or []
        if "finding" in tags or p.stem.startswith("finding_"):
            actions.append(f"move     docs/{p.name} -> findings/{p.name}")
            if not args.dry_run:
                shutil.move(str(p), str(root / "findings" / p.name))

    # 3. backfill the `type` property on anything missing it
    type_for = {"schema": "schema-card", "docs": "doc",
                "skills": "skill", "findings": "finding"}
    for kind, note_type in type_for.items():
        for p in (root / kind).glob("*.md"):
            text = p.read_text()
            m = FRONTMATTER.match(text)
            meta = (yaml.safe_load(m.group(1)) if m else {}) or {}
            if meta.get("type") == note_type:
                continue
            actions.append(f"retype   {kind}/{p.name} -> type: {note_type}")
            if not args.dry_run:
                body = m.group(2) if m else text
                title = meta.get("title", p.stem)
                if kind == "schema":
                    kb.put_schema_card({**meta, "table": meta.get("table", title)})
                else:
                    kb.put_doc(kind, p.stem, title, body, {**meta, "type": note_type})

    if not args.dry_run:
        kb.reindex()
        actions.append(f"reindex  {kb.stats()}")

    print("\n".join(actions) or "nothing to do -- already a vault")
    if args.dry_run:
        print("\n(dry run: no files changed)")
    print(f"\nOpen Obsidian -> Open folder as vault -> {root.resolve()}")
    print("Then: Settings > Core plugins > enable Bases and Properties,")
    print("and open _dashboards/Schema.base")


if __name__ == "__main__":
    main()
