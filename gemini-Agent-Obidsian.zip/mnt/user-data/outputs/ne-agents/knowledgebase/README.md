---
type: doc
title: ne-agents knowledge base
tags:
  - ne-agents
---

# ne-agents knowledge base

This folder is both the agents' knowledge store and an **Obsidian vault**.
Open it with `Open folder as vault`.

| Folder | Written by | What it holds |
|---|---|---|
| `schema/` | `schema_agent` | one note per table: columns, grain, join keys, gotchas |
| `docs/` | `doc_curation` | summaries of the internal doc site; full text stays in `runs/` |
| `findings/` | `curator_agent` | validated conclusions, linked to the tables they used |
| `skills/` | `curator_agent` | runbooks promoted after succeeding in 2+ runs |
| `_dashboards/` | you | Bases views — start at [[Schema.base]] |
| `_templates/` | you | note templates for hand-written cards |

## Conventions that must not drift

`type` is one of `schema-card`, `doc`, `finding`, `skill`. Every Bases view
filters on it.

`status` is one of `draft`, `validated`, `warned`, `rejected`, `deprecated`.
Only the validator promotes a note past `draft`.

`confidence` is always a number. `tags`, `join_keys`, `columns`, `evidence`,
`related` are always lists, even with one element. A property that is sometimes
a string and sometimes a list breaks a Bases column silently.

## Editing by hand

Do. The agents treat human edits as authoritative for everything except
`columns` and `column_count`, which `schema_agent` regenerates from
`information_schema` on every sync. Put your own knowledge in `description`,
`grain`, `gotchas` and the **Verified SQL** section — none of those are
overwritten.
