"""Decides what survives the run, and writes it as idiomatic Obsidian notes.

Without a curator the knowledge base grows monotonically and search precision
falls off a cliff. This agent persists only validated findings, links them back
to the schema cards and the run that produced them, and promotes a procedure to
a skill only when the same approach has now worked in more than one run.

The wikilinks are not decoration. They make the Obsidian graph the lineage
graph: open a schema card, read its backlinks, and you see every finding and
skill that would be invalidated if that table changed.
"""
from __future__ import annotations

import re

from core import obsidian
from core.context import Context
from core.envelope import Envelope
from core.knowledge import slug

from .base import Agent

TABLE_REF = re.compile(r"\b([a-z0-9_]+)\.([a-z0-9_]+)\.([a-z0-9_]+)\b", re.I)


class CuratorAgent(Agent):
    def run(self, task: dict, ctx: Context) -> Envelope:
        sid = task.get("step_id") or self.step_id()
        verdict = task.get("verdict") or {}
        findings = task.get("findings") or []
        answers = task.get("answers") or []

        if not verdict.get("safe_to_persist"):
            return self.emit(ctx, "result",
                             {"persisted": 0, "skipped_reason": "validator withheld"},
                             step_id=sid, confidence=0.9)

        schema_ids = self._tables_touched(answers)
        status = "validated" if verdict.get("verdict") == "pass" else "warned"

        persisted = []
        for f in findings:
            fid = slug(f"finding_{f.get('statement', '')[:60]}")
            body = obsidian.finding_body(f, ctx.run_id, ctx.goal, schema_ids)
            ctx.knowledge.put_doc(
                "findings", fid, f.get("statement", "")[:120], body,
                {"tags": ["finding"], "status": status,
                 "confidence": float(f.get("confidence", 0.5)),
                 "related": [obsidian.wikilink(s) for s in schema_ids],
                 "run": ctx.run_id, "source": f"run:{ctx.run_id}"})
            persisted.append(fid)

        promoted = self._maybe_promote_skill(ctx, answers, schema_ids)
        return self.emit(ctx, "result",
                         {"persisted": len(persisted), "ids": persisted,
                          "linked_tables": schema_ids, "skill_promoted": promoted},
                         step_id=sid, confidence=0.8)

    @staticmethod
    def _tables_touched(answers: list[dict]) -> list[str]:
        """Recover the schema-card ids from the SQL Genie actually ran.

        This is why genie_comms keeps the generated SQL: it is the only
        trustworthy record of which tables a finding depends on.
        """
        ids: list[str] = []
        for a in answers:
            for m in TABLE_REF.finditer(a.get("sql") or ""):
                cid = slug("_".join(m.groups()))
                if cid not in ids:
                    ids.append(cid)
        return ids

    def _maybe_promote_skill(self, ctx: Context, answers: list[dict],
                             schema_ids: list[str]) -> str | None:
        """A skill is a procedure that has now worked in at least two runs."""
        if len(answers) < 2:
            return None
        sid = slug("skill_" + (answers[0].get("question") or "")[:50])
        body = obsidian.skill_body(
            goal=ctx.goal,
            steps=[{"question": a.get("question"), "sql": a.get("sql")} for a in answers],
            failure_modes=[
                "Short windows produce spurious correlations; widen to 28 days "
                "before acting on a result.",
                "A single network element is not a pattern.",
            ],
            schema_links=schema_ids)
        entry = ctx.knowledge.promote_skill(
            sid, f"Runbook: {ctx.goal[:80]}", body, evidence=[ctx.run_id])
        return entry.id if entry else None
