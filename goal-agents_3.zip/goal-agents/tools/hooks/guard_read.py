"""PreToolUse(Read|Glob|Grep) hook for the mail-analyst: it may only look inside retrieved
bundles (.goals/<goal>/inputs/). Glob and Grep must name an explicit path there.
Exit 0 = allow, 2 = block.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
import _glog  # noqa: E402


def inside_inputs(root: Path, raw: str) -> bool:
    if not raw:
        return False
    p = Path(raw)
    p = (p if p.is_absolute() else root / p).resolve()
    try:
        rel = p.relative_to((root / ".goals").resolve())
    except ValueError:
        return False
    return len(rel.parts) >= 2 and rel.parts[1] == "inputs"


def main() -> None:
    try:
        data = json.load(sys.stdin)
    except Exception:
        sys.stderr.write("Blocked: unreadable hook input\n")
        sys.exit(2)
    tool = data.get("tool_name", "")
    ti = data.get("tool_input") or {}
    root = Path(os.environ.get("CLAUDE_PROJECT_DIR") or data.get("cwd") or ".").resolve()
    target = ti.get("file_path") if tool == "Read" else ti.get("path")
    ok = inside_inputs(root, target or "")
    if tool == "Glob" and ok and ".." in str(ti.get("pattern", "")):
        ok = False
    _glog.tool("guard.allow" if ok else "guard.block", hook="guard_read", tool=tool, target=target,
               agent=data.get("agent_type"), session=data.get("session_id"))
    if not ok:
        sys.stderr.write(f"Blocked by analyst policy: {tool} may only target .goals/<goal>/inputs/ "
                         f"(got {target!r}). Pass the bundle path explicitly, e.g. path=\".goals/<goal>/inputs/T1\".\n")
        sys.exit(2)
    sys.exit(0)


if __name__ == "__main__":
    main()
