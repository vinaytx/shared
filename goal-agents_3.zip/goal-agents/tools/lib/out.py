"""out - compact output for ad hoc scripts (keeps tokens low).

  rows(items, "received from_email subject natt", n=25, w=60, save=None)
      Print up to n rows as TSV (header first). Cells cut to w chars. Ends with
      "# shown/total". save="name.jsonl" writes ALL rows (all listed fields) to the
      artifacts dir and prints its path.
  say(*parts)           one line of text
  kv(**pairs)           "k=v k=v" on one line
  count(items, field, n=15)   top values of a field with counts
  dedupe(items, key="msgid")  drop items whose key was already seen (None keys kept)
  save(name, data)      write text / list of dicts (JSONL) / bytes to artifacts (overwrites); returns path
  fetch(items, atts=True, limit=100)
      Pull the RELEVANT messages into the inputs bundle for the analysis step:
      one .md per message (headers + full body), attachments, a .txt copy of
      Word/Excel/PowerPoint/text attachments, and manifest.jsonl. De-duplicates by msgid.
      Prints only a short summary. Call it once, on the final, verified result set.

Items can be Msg / EMsg objects (olk, eml) or dicts.
"""
from __future__ import annotations

import collections
import datetime as dt
import json
from pathlib import Path

import _extract
import _glog
from _base import ARTIFACTS, INPUTS, ROOT, safe_name

__all__ = ["rows", "say", "kv", "count", "dedupe", "save", "fetch"]


def _get(item, field):
    if isinstance(item, dict):
        v = item.get(field)
    else:
        v = getattr(item, field, None)
        if callable(v):
            v = None
    if isinstance(v, dt.datetime):
        return v.strftime("%Y-%m-%d %H:%M")
    return v


def _cell(v, w):
    s = "" if v is None else str(v).replace("\t", " ").replace("\r", " ").replace("\n", " ")
    return s if len(s) <= w else s[: w - 1] + "…"


def rows(items, fields="received from_email subject natt", n=25, w=60, save=None):
    items = list(items)
    fl = fields.split() if isinstance(fields, str) else list(fields)
    print("\t".join(fl))
    for it in items[:n]:
        print("\t".join(_cell(_get(it, f), w) for f in fl))
    print(f"# {min(n, len(items))}/{len(items)} rows")
    if save:
        p = globals()["save"](save, [{f: _get(it, f) for f in fl} for it in items])
        print(f"# saved {len(items)} rows -> {p}")
    return items


def say(*parts):
    print(" ".join(str(p) for p in parts))


def kv(**pairs):
    print(" ".join(f"{k}={v}" for k, v in pairs.items()))


def count(items, field, n=15):
    c = collections.Counter(_get(it, field) for it in items)
    for val, k in c.most_common(n):
        print(f"{k}\t{_cell(val, 70)}")
    print(f"# {len(c)} distinct")
    return c


def dedupe(items, key="msgid"):
    seen, out = set(), []
    for it in items:
        k = _get(it, key)
        if k is not None and k in seen:
            continue
        if k is not None:
            seen.add(k)
        out.append(it)
    return out


def save(name, data) -> str:
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    p = ARTIFACTS / Path(str(name)).name  # overwrite: reruns of a script replace their output
    if isinstance(data, (bytes, bytearray)):
        p.write_bytes(data)
    elif isinstance(data, str):
        p.write_text(data, encoding="utf-8")
    else:
        with p.open("w", encoding="utf-8") as f:
            for d in data:
                f.write(json.dumps(d, ensure_ascii=False, default=str) + "\n")
    try:
        return p.resolve().relative_to(ROOT.resolve()).as_posix()
    except ValueError:
        return str(p)


def _rel(p: Path) -> str:
    try:
        return p.resolve().relative_to(ROOT.resolve()).as_posix()
    except ValueError:
        return str(p)


def fetch(items, atts=True, limit=100):
    """Write the relevant messages (+ attachments) into the inputs bundle; returns the manifest path."""
    items = dedupe(list(items), key="msgid")
    total = len(items)
    if total > limit:
        print(f"# fetch: {total} messages, keeping newest {limit} (raise limit= or narrow the query)")
        items = items[:limit]
    INPUTS.mkdir(parents=True, exist_ok=True)
    manifest = INPUTS / "manifest.jsonl"
    done = set()
    if manifest.exists():  # reruns append only new messages
        for line in manifest.read_text(encoding="utf-8").splitlines():
            try:
                done.add(json.loads(line).get("key"))
            except ValueError:
                pass
    n_new = n_att = n_txt = 0
    start = len(done)
    with manifest.open("a", encoding="utf-8") as mf:
        for it in items:
            outlook = hasattr(it, "sid")
            key = getattr(it, "msgid", None) or (("olk:" if outlook else "eml:") + str(getattr(it, "id", "")))
            if key in done:
                continue
            done.add(key)
            n = start + n_new + 1
            when = it.received.strftime("%Y-%m-%d") if getattr(it, "received", None) else "nodate"
            stem = f"{n:03d}_{when}_{safe_name(it.subject or 'no subject')[:60]}"
            source = f"outlook:{it.folder}" if outlook else f"barracuda-eml:{it.id}"
            body = it.body(0)
            md = (f"# {it.subject or '(no subject)'}\n\n"
                  f"- From: {it.from_name} <{it.from_email}>\n- To: {it.to}\n- Cc: {it.cc}\n"
                  f"- Date: {it.received}\n- Source: {source}\n- Message-ID: {getattr(it, 'msgid', None)}\n\n"
                  f"---\n\n{body}\n")
            msg_file = INPUTS / f"{stem}.md"
            msg_file.write_text(md, encoding="utf-8")
            att_list = []
            if atts and it.natt:
                att_dir = INPUTS / f"{stem}_att"
                for path in it.save_atts(dest=att_dir):
                    ap = ROOT / path if not Path(path).is_absolute() else Path(path)
                    rec = {"file": _rel(ap), "bytes": ap.stat().st_size}
                    txt = _extract.text_of(ap.name, ap.read_bytes())
                    if txt:
                        tp = ap.with_name(ap.name + ".txt")
                        tp.write_text(txt, encoding="utf-8")
                        rec["text"] = _rel(tp)
                        n_txt += 1
                    att_list.append(rec)
                    n_att += 1
            rec = {"n": n, "key": key, "source": source, "id": it.id, "sid": getattr(it, "sid", None),
                   "received": it.received, "from": it.from_email, "to": it.to, "subject": it.subject,
                   "file": _rel(msg_file), "body_chars": len(body), "attachments": att_list}
            mf.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
            n_new += 1
    _glog.data("out.fetch", bundle=_rel(INPUTS), requested=total, written=n_new, attachments=n_att,
               extracted=n_txt, manifest=_rel(manifest))
    print(f"# fetched {n_new} new messages ({n_att} attachments, {n_txt} as text) -> {_rel(manifest)}")
    return _rel(manifest)
