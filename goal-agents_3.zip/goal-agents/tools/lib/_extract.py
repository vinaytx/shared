"""_extract - best-effort plain text from attachments, stdlib only (used by out.fetch).

Returns text or None. PDFs and images are left as-is (Claude's Read tool opens them directly).
"""
from __future__ import annotations

import csv
import html
import io
import re
import zipfile
from pathlib import Path

MAX_CHARS = 200_000
TEXT_EXT = {".txt", ".csv", ".tsv", ".md", ".json", ".xml", ".log", ".ics", ".vcf", ".eml", ".htm", ".html"}


def _xml_text(xml: str) -> str:
    xml = re.sub(r"</w:p>|<w:br/>|</a:p>|<w:tab/>", "\n", xml)
    return html.unescape(re.sub(r"<[^>]+>", "", xml))


def docx(data: bytes) -> str:
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        parts = [n for n in z.namelist() if re.match(r"word/(document|header\d*|footer\d*|footnotes|endnotes)\.xml$", n)]
        return "\n".join(_xml_text(z.read(n).decode("utf-8", "replace")) for n in sorted(parts))


def pptx(data: bytes) -> str:
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        slides = sorted((n for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)),
                        key=lambda n: int(re.findall(r"\d+", n)[-1]))
        return "\n\n".join(f"--- slide {i} ---\n" + _xml_text(z.read(n).decode("utf-8", "replace"))
                           for i, n in enumerate(slides, 1))


def xlsx(data: bytes) -> str:
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names = z.namelist()
        shared = []
        if "xl/sharedStrings.xml" in names:
            sx = z.read("xl/sharedStrings.xml").decode("utf-8", "replace")
            shared = [html.unescape(re.sub(r"<[^>]+>", "", si)) for si in re.findall(r"<si>(.*?)</si>", sx, re.S)]
        out = []
        sheets = sorted((n for n in names if re.match(r"xl/worksheets/sheet\d+\.xml$", n)),
                        key=lambda n: int(re.findall(r"\d+", n)[-1]))
        for n in sheets:
            out.append(f"--- {Path(n).stem} ---")
            sx = z.read(n).decode("utf-8", "replace")
            for row in re.findall(r"<row[^>]*>(.*?)</row>", sx, re.S):
                cells = []
                for attrs, body in re.findall(r"<c([^>]*)>(.*?)</c>", row, re.S):
                    v = re.search(r"<v>(.*?)</v>", body, re.S)
                    t = re.search(r"<t[^>]*>(.*?)</t>", body, re.S)
                    if 't="s"' in attrs and v:
                        try:
                            cells.append(shared[int(v.group(1))])
                        except (ValueError, IndexError):
                            cells.append(v.group(1))
                    elif t:
                        cells.append(html.unescape(t.group(1)))
                    elif v:
                        cells.append(html.unescape(v.group(1)))
                    else:
                        cells.append("")
                out.append("\t".join(cells))
        return "\n".join(out)


def text_of(name: str, data: bytes) -> str | None:
    ext = Path(name or "").suffix.lower()
    try:
        if ext == ".docx":
            t = docx(data)
        elif ext == ".xlsx":
            t = xlsx(data)
        elif ext == ".pptx":
            t = pptx(data)
        elif ext in TEXT_EXT:
            t = data.decode("utf-8", "replace")
            if ext in (".htm", ".html"):
                t = html.unescape(re.sub(r"(?s)<[^>]+>", " ", re.sub(r"(?is)<(script|style).*?</\1>", " ", t)))
        else:
            return None
    except Exception:
        return None
    t = re.sub(r"\n{3,}", "\n\n", t).strip()
    return t[:MAX_CHARS] if t else None
