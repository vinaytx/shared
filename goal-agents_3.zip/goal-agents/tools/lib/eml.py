"""eml - read-only helpers for Barracuda Message Archiver EML exports (.eml files and .zip).

  scan(dir=None)                   -> iterator of EMsg over every .eml (recursing, inside zips too)
  search(dir=None, frm=None, to=None, subject=None, body=None, text=None,
         since=None, until=None, attach=None, limit=200) -> [EMsg], newest first
  get(id, dir=None)                -> EMsg  (id from a previous result)

  dir defaults to BARRACUDA_EXPORT_DIR or barracuda.export_dir in tools/config.json.
  Text filters are case-insensitive substrings; a list means ANY of the terms.
  EMsg fields : id received from_name from_email to cc subject natt size msgid
  EMsg methods: body(n=2000) headers(n=4000) atts() save_atts(sub="")

Logged to logs/data/: every message scanned (id, path, sha256, headers summary), every search
(params + full result list), and full text of every body/headers read. Set
logging.log_scanned_bodies=true in tools/config.json to also log bodies read while filtering.
"""
from __future__ import annotations

import datetime as dt
import email
import email.policy
import email.utils
import hashlib
import html as _html
import os
import re
import zipfile
from pathlib import Path

import _glog
from _base import ARTIFACTS, rel, EnvError, QueryError, clip, config, day, one_line, safe_name, unique

__all__ = ["scan", "search", "get", "EMsg", "export_dir"]
_MAX_BYTES = 50 * 1024 * 1024


def export_dir(d=None) -> Path:
    d = d or os.environ.get("BARRACUDA_EXPORT_DIR") or config().get("barracuda", {}).get("export_dir")
    if not d:
        raise EnvError("ENV_NO_EXPORT_DIR", "no EML export dir",
                       "export results from the archiver web UI as EML and set BARRACUDA_EXPORT_DIR or tools/config.json")
    p = Path(os.path.expandvars(os.path.expanduser(str(d))))
    if not p.is_dir():
        raise EnvError("ENV_NO_EXPORT_DIR", f"export dir not found: {p}")
    return p


class EMsg:
    __slots__ = ("id", "msg", "received", "from_name", "from_email", "to", "cc", "subject", "natt", "size", "msgid",
                 "sha256")

    def __init__(self, id, raw: bytes):
        m = email.message_from_bytes(raw, policy=email.policy.default)
        self.id, self.msg, self.size = id, m, len(raw)
        self.sha256 = hashlib.sha256(raw).hexdigest()
        self.from_name, self.from_email = email.utils.parseaddr(_h(m, "From"))
        self.to, self.cc, self.subject = _h(m, "To"), _h(m, "Cc"), _h(m, "Subject")
        self.msgid = _h(m, "Message-ID") or None
        try:
            d = email.utils.parsedate_to_datetime(_h(m, "Date"))
            self.received = d.astimezone().replace(tzinfo=None) if d.tzinfo else d
        except Exception:
            self.received = None
        try:
            self.natt = sum(1 for _ in m.iter_attachments())
        except Exception:
            self.natt = 0

    def summary(self) -> dict:
        return {"id": self.id, "received": self.received, "from_name": self.from_name, "from_email": self.from_email,
                "to": self.to, "cc": self.cc, "subject": self.subject, "natt": self.natt, "size": self.size,
                "msgid": self.msgid, "sha256": self.sha256}

    def body(self, n=2000):
        full = _text(self.msg)
        _glog.data("eml.body", id=self.id, subject=self.subject, chars=len(full), body=full)
        return clip(full, n)

    def headers(self, n=4000):
        h = "\n".join(f"{k}: {v}" for k, v in self.msg.items())
        _glog.data("eml.headers", id=self.id, headers=h)
        return clip(h, n)

    def atts(self):
        res = [{"i": i, "name": p.get_filename() or f"att{i}", "type": p.get_content_type(),
                "size": len(p.get_payload(decode=True) or b"")} for i, p in enumerate(self.msg.iter_attachments(), 1)]
        _glog.data("eml.atts", id=self.id, attachments=res)
        return res

    def save_atts(self, sub="", dest=None):
        base = dest if dest is not None else ARTIFACTS
        d = base / safe_name(sub) if sub else base
        paths = []
        for i, p in enumerate(self.msg.iter_attachments(), 1):
            f = unique(d, safe_name(p.get_filename(), f"att{i}"))
            payload = p.get_payload(decode=True) or b""
            f.write_bytes(payload)
            _glog.data("eml.save_att", id=self.id, index=i, name=p.get_filename(), path=rel(f), bytes=len(payload),
                       sha256=hashlib.sha256(payload).hexdigest())
            paths.append(rel(f))
        return paths

    def __repr__(self):
        r = self.received.strftime("%Y-%m-%d") if self.received else "?"
        return f"<EMsg {r} {self.from_email} {one_line(self.subject, 60)!r}>"


def _h(m, k) -> str:
    try:
        return str(m.get(k, "") or "")
    except Exception:
        return ""


def _text(m) -> str:
    part = m.get_body(preferencelist=("plain", "html"))
    if part is None:
        return ""
    try:
        t = part.get_content()
    except Exception:
        t = (part.get_payload(decode=True) or b"").decode(part.get_content_charset() or "utf-8", "replace")
    if part.get_content_type() == "text/html":
        t = re.sub(r"(?is)<(script|style).*?</\1>", " ", t)
        t = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</tr>", "\n", t)
        t = _html.unescape(re.sub(r"(?s)<[^>]+>", " ", t))
    return t


def scan(dir=None):
    root = export_dir(dir)
    n = 0
    for m in _scan(root):
        n += 1
        _glog.data("eml.scanned", dir=str(root), **m.summary())
        yield m
    _glog.data("eml.scan_done", dir=str(root), count=n)


def _scan(root: Path):
    for p in sorted(root.rglob("*")):
        low = p.name.lower()
        if not p.is_file():
            continue
        rel = p.relative_to(root).as_posix()
        if low.endswith(".eml") and p.stat().st_size <= _MAX_BYTES:
            yield EMsg(rel, p.read_bytes())
        elif low.endswith(".zip"):
            try:
                with zipfile.ZipFile(p) as z:
                    for i in z.infolist():
                        if i.filename.lower().endswith(".eml") and not i.is_dir() and i.file_size <= _MAX_BYTES:
                            yield EMsg(f"{rel}!{i.filename}", z.read(i))
            except zipfile.BadZipFile:
                continue


def _has(v, needle):
    """needle: None (match), a string, or a list of strings (match ANY)."""
    if needle is None or needle == "" or needle == []:
        return True
    terms = needle if isinstance(needle, (list, tuple, set)) else [needle]
    hay = str(v or "").lower()
    return any(str(t).lower() in hay for t in terms if str(t).strip())


def search(dir=None, frm=None, to=None, subject=None, body=None, text=None, since=None, until=None, attach=None, limit=200):
    s, u = day(since), day(until, end=True)
    out = []
    for m in scan(dir):
        if not (_has(f"{m.from_name} {m.from_email}", frm) and _has(f"{m.to} {m.cc}", to) and _has(m.subject, subject)):
            continue
        if (s or u) and (m.received is None or (s and m.received < s) or (u and m.received > u)):
            continue
        if attach is not None and bool(m.natt) != bool(attach):
            continue
        if body or text:
            b = _text(m.msg)
            if _glog.setting("log_scanned_bodies", False):
                _glog.data("eml.body_scanned", id=m.id, body=b)
            if body and not _has(b, body):
                continue
            if text and not (_has(m.subject, text) or _has(b, text)):
                continue
        out.append(m)
    out.sort(key=lambda m: m.received or dt.datetime.min, reverse=True)
    _glog.data("eml.search", params={"dir": str(dir) if dir else None, "frm": frm, "to": to, "subject": subject,
                                     "body": body, "text": text, "since": since, "until": until, "attach": attach,
                                     "limit": limit},
               matched=len(out), returned=min(len(out), limit), results=[m.summary() for m in out[:limit]])
    return out[:limit]


def get(id, dir=None):
    root = export_dir(dir).resolve()
    if "!" in id:
        zrel, member = id.split("!", 1)
        zp = (root / zrel).resolve()
        _inside(root, zp)
        try:
            with zipfile.ZipFile(zp) as z:
                m = EMsg(id, z.read(member))
        except (KeyError, FileNotFoundError, zipfile.BadZipFile):
            _glog.data("eml.get", id=id, ok=False)
            raise QueryError(f"message '{id}' not found")
        _glog.data("eml.get", ok=True, **m.summary())
        return m
    p = (root / id).resolve()
    _inside(root, p)
    if not p.is_file():
        _glog.data("eml.get", id=id, ok=False)
        raise QueryError(f"message '{id}' not found")
    m = EMsg(id, p.read_bytes())
    _glog.data("eml.get", ok=True, **m.summary())
    return m


def _inside(root: Path, p: Path):
    try:
        p.relative_to(root)
    except ValueError:
        raise QueryError("id points outside the export dir")
