# Goal agents v4: LLM-generated retrieval scripts + analysis for Outlook and Barracuda (Claude Code, Windows)

The LLM turns each request into a query script, runs it against the mailbox or archive,
refines it until the hits are relevant, and pulls the matching emails and attachments into an
**inputs bundle**. A separate analyst step then reads only that bundle to answer the question.
Generated scripts are deleted when the goal is done.

```
/goal "What did Acme say about the late invoices this year?"
 orchestrator: frame need + retrieval spec (people, term variants, concrete dates, sources)
   ├─▶ outlook-mail       ┐  1 PLAN docstring: request -> filters (OR-lists of term variants)
   ├─▶ barracuda-archive  ┘  2 probe: counts, top senders, 15-row sample (no bodies)
   │                         3 refine: widen/narrow, max 3 more runs
   │                         4 out.fetch(relevant) -> .goals/<id>/inputs/<task>/
   │                              NNN_<date>_<subject>.md (headers + full body)
   │                              NNN_..._att/ files + .txt copies (docx/xlsx/pptx/text)
   │                              manifest.jsonl
   │                         5 cleanup --task (scripts gone, bundle kept)
   ├─▶ mail-analyst          reads manifest -> greps -> reads only what it needs -> cited answer
   └─ report -> cleanup <id> (offer --purge for bundles)
```

## Retrieve, then analyze

- **Retrieval workers** (`outlook-mail`, `barracuda-archive`) never answer content questions.
  They find and fetch. Each script starts with a PLAN block that makes the interpretation explicit:
  who, which term variants, which fields, concrete dates and a relevance test. They probe first
  and print only counts and a sample, then fetch the verified set.
- **Search terms as lists:** any text filter accepts a list meaning ANY term
  (`text=["invoice", "inv#", "overdue"]`); separate filters are ANDed. In Outlook this compiles
  to a single DASL query; in EML exports it's evaluated in Python.
- **mail-analyst** has only Read/Glob/Grep, and a hook (`guard_read`) limits it to
  `.goals/<goal>/inputs/`. It reads the manifest, greps the bundle, opens only the messages
  and attachments it needs, and cites every finding as `[n]` / `[n:attachment]`. If something is
  missing, it hands a retrieval request back to the orchestrator.
- If the user only wants a list or the files, the analyst step is skipped.

## Where the token savings come from

| Lever | How |
|---|---|
| Tiny scripts | Helper libs (`olk`, `eml`, `out`) do the heavy lifting, so a typical query is 3-6 lines. |
| Compact output | `out.rows()` prints TSV capped at 25 rows and 60-char cells; the runner cuts stdout at 3000 chars and keeps the rest in a file. |
| Data stays on disk | Full result sets go to `artifacts/*.jsonl`; only summaries enter the conversation. |
| Isolated context | Raw query output lives in the worker's context. The orchestrator only sees a short envelope. |
| Fast path | Single-source goals skip the plan file and results bookkeeping. |
| Lean prompts | Short worker contract and cheat sheets; workers run with `effort: low`, and the orchestrator doesn't call the registry (it already sees agent descriptions). |
| Compact tool output | doctor, cleanup and runner print `key=value` text, not JSON envelopes. |

## Layout

| Path | Purpose |
|---|---|
| `.claude/skills/goal/SKILL.md` | Orchestration loop (`/goal <outcome>`), with fast path and cleanup step. |
| `.claude/agents/goal-orchestrator.md` | Same loop as a subagent, or `claude --agent goal-orchestrator`. |
| `.claude/skills/worker-contract/SKILL.md` | Script-writing loop, output rules, envelope. Preloaded into every worker. |
| `.claude/agents/workers/*.md` | Workers, each with a cheat sheet of its helper libs. |
| `tools/lib/olk.py` | Classic Outlook (COM) helpers: stores, folders, search, get, Msg. |
| `tools/lib/eml.py` | Barracuda EML/zip export helpers: scan, search, get, EMsg. |
| `tools/lib/out.py` | Compact printing and saving: rows, count, kv, say, dedupe, save, **fetch** (inputs bundle). |
| `tools/lib/_extract.py` | Plain-text copies of docx/xlsx/pptx/text attachments (stdlib). |
| `.claude/agents/workers/mail-analyst.md`, `tools/hooks/guard_read.py` | Analysis worker and its read-only bundle guard. |
| `tools/adhoc.py` | Runner: location check, static checker, timeout, output cap. |
| `tools/cleanup.py` | Deletes scratch (per task, per goal, stale) or purges a goal. |
| `tools/doctor.py` | Environment check for Outlook and Barracuda. |
| `tools/lib/_glog.py`, `tools/hooks/log_event.py`, `tools/logs.py`, `tools/otel_collector.py` | Logging layer, conversation hook, log viewer/export, optional OTLP receiver. |
| `tools/hooks/guard_bash.py`, `guard_write.py` | Worker hooks: Bash limited to `tools/run adhoc/doctor/cleanup`; writes limited to `.py` in scratch. |

## Guardrails on generated code

Before any generated script runs, `tools/adhoc.py` rejects it if it:
- imports anything except the helper libs and a safe stdlib list (no `os`, `sys`,
  `subprocess`, `pathlib`, network modules);
- uses `open`, `eval`, `exec`, `getattr`/`setattr`, `__import__`, or dunder attributes;
- assigns to attributes (which would change mail properties);
- calls COM methods that change, send or display mail (`Send`, `Delete`, `Move`,
  `Save`, `SaveAs`, `Forward`, `Reply`...) or Path-style file mutators.

Scripts run only from `.goals/<id>/scratch/`, with a timeout. Rejections list line
numbers so the worker can fix and rerun. This is a strong guardrail against mistakes and
prompt-injected instructions, not a security sandbox.

## Setup (Windows)

1. Use **classic Outlook**, keep it running. New Outlook has no COM.
2. Install Python 3.8+ from python.org, then `py -m pip install pywin32`.
3. Copy this folder into your project. Run Claude Code **non-elevated** from it and accept
   the trust prompt so the hooks load.
4. Run `bash tools/run doctor`. It reports what's missing.
5. Barracuda: sync Archive Stores in the Outlook add-in (admin enables folder-sync jobs),
   or export results from the archiver web UI as EML and set `export_dir` in `tools/config.json`
   (copy from `config.example.json`) or `BARRACUDA_EXPORT_DIR`.
6. 32-bit Outlook and COM errors: install 32-bit Python and set `GOAL_PYTHON`.

## Logging

Everything the system does is logged as JSON lines under `logs/` (git-ignored; it holds full
mail content and conversation history). Logging runs in the background and never blocks or
breaks a query. Agents are denied direct Read/Write access to `logs/` so logs stay out of the
model's context and can't be edited by it.

| What | How it's captured | Where |
|---|---|---|
| User requests | `UserPromptSubmit` hook | `logs/hooks/<date>/<session>.jsonl` (`kind=user_request`) |
| Tool calls (incl. prompts sent to subagents) | `PreToolUse` hook, all tools, main + subagents | same file (`kind=tool_call`, `agent_type`) |
| Tool returns / failures | `PostToolUse`, `PostToolUseFailure`, `PermissionDenied` hooks | same file (`tool_return`, `tool_error`) |
| Subagent responses | `SubagentStart/Stop` hooks (`last_assistant_message`) | same file (`subagent_response`) |
| Responses to the user | `Stop` hook (`last_assistant_message`) | same file (`response_to_user`) |
| Every LLM response (text, tool use, thinking when present, token usage) | transcripts mirrored incrementally on Stop / SubagentStop / PreCompact / SessionEnd | `logs/transcripts/<session>/main.jsonl`, `agent-*.jsonl` |
| Every LLM API request and response (raw JSON), tokens, cost, latency | optional: OpenTelemetry → local collector (`logs enable-api`) | `logs/api/`, `logs/otel/<date>.jsonl` |
| All mail data read | `olk` / `eml` helpers log every connect, store/folder list, search (params, filter, full result list), body, headers, attachment list, saved file (sha256), export | `logs/data/<date>/<goal>__<run>.jsonl` |
| Generated scripts | runner logs source, lint result, full stdout/stderr, and exactly what the model was shown | `logs/tools/<date>.jsonl` (`adhoc.*`) |
| Guard decisions, cleanup, doctor | hooks and tools | `logs/tools/<date>.jsonl` |
| Logging failures | the logger itself | `logs/errors/<date>.jsonl` |

Correlation: every script run gets an id (`run=xxxxxxxx` in its output). The same id tags its
`adhoc.*` records and names its data file, and appears in the logged tool return, so a
conversation turn can be traced to the exact mail data it read.

### Viewing

```
bash tools/run logs status                    # sizes per channel, api logging on/off
bash tools/run logs sessions                  # recent sessions + first request
bash tools/run logs timeline [--session ID]   # one line per event, merged across all channels
bash tools/run logs export [--session ID] [--full] [--out file.md]   # Markdown audit report
```

### Full LLM API capture (optional)

Hooks and transcripts already record every model response. To also record the raw API requests
(the full prompt Claude Code sends each time, including system prompt and history), token
counts and cost per call:

```
bash tools/run logs enable-api     # writes OpenTelemetry settings to .claude/settings.local.json
# restart Claude Code; the local collector (127.0.0.1:4318) starts automatically at session start
bash tools/run logs disable-api
```

Raw bodies contain the whole conversation on every call, so this mode uses a lot of disk.

### Settings (`tools/config.json` → `logging`)

| Key | Default | Meaning |
|---|---|---|
| `enabled` | `true` | master switch (also env `GOAL_LOG=0`) |
| `dir` | `logs` | log folder (also env `GOAL_LOG_DIR`) |
| `retention_days` | `30` | files older than this are pruned at session start |
| `redact_secrets` | `true` | mask passwords/tokens/API keys in conversation and tool logs (mail data is logged as-is) |
| `log_html_body` | `false` | also log the HTML body of Outlook messages |
| `log_scanned_bodies` | `false` | log bodies of every EML read while filtering (not just ones a script asks for) |

**Privacy:** logs are a complete copy of the mail data the agents touched. Keep `logs/` on an
encrypted disk, restrict access, and set `retention_days` to match your policy.

## Adding a worker

```
bash tools/run new-worker jira-tickets --lib jira --purpose "Searches Jira tickets by project and status"
```
1. Implement `tools/lib/jira.py`: a small read-only API with a docstring cheat sheet.
   Raise `EnvError` for setup problems (worker reports `blocked`) and `QueryError` for bad input.
2. Copy the cheat sheet and capabilities into `.claude/agents/workers/jira-tickets.md`.
3. `bash tools/run registry` to check it. The orchestrator picks it up from the description.

The runner automatically allows importing any module in `tools/lib/` (except `_*` and `TEMPLATE`).

## Cleanup reference

```
bash tools/run cleanup <goal_id> --task T1   # one task's scripts (workers do this)
bash tools/run cleanup <goal_id>             # all scripts for a goal; bundles + artifacts kept
bash tools/run cleanup <goal_id> --purge     # everything incl. inputs bundles and artifacts
bash tools/run cleanup --stale --hours 12    # crash leftovers (runs at session start)
bash tools/run cleanup --list
```

## Known limits

- Search uses Outlook DASL `LIKE` (substring). Body search is slow, so always add dates.
- `limit` stops collecting once reached, folder by folder, so narrow the query for "newest N".
- Archived stubs may hold only a preview; the full copy lives on the archiver.
- Tested against a mocked Outlook object model and real EML files, not live Outlook.
  Run `bash tools/run doctor` first.
