"""_glog - the framework's logging layer. Structured JSONL, append-only, multi-process safe.

Every record is one JSON line:
  {"ts": "2026-10-21T22:16:05.123-05:00", "ch": "<channel>", "ev": "<event>", ...context, ...fields}

Channels and files (under logs/, override with GOAL_LOG_DIR or logging.dir in tools/config.json):
  hooks   logs/hooks/<date>/<session>.jsonl        user prompts, tool calls/returns, subagents, responses
  data    logs/data/<date>/<goal>__<run>.jsonl     everything read from Outlook / Barracuda
  tools   logs/tools/<date>.jsonl                  adhoc runs (script source, stdout, stderr), cleanup, doctor, guards
  otel    logs/otel/<date>.jsonl                   OpenTelemetry events (optional collector)
  errors  logs/errors/<date>.jsonl                 failures inside the logging layer itself
Transcripts are mirrored to logs/transcripts/<session>/ and raw API bodies to logs/api/.

Logging never raises: a failure is recorded under errors/ and the caller continues.
Set GOAL_LOG=0 to disable. Python's std `logging` can also feed this via get_logger().
"""
from __future__ import annotations

import datetime as dt
import json
import logging
import os
import re
import sys
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
_CFG_CACHE: dict | None = None
_SECRET_KEYS = re.compile(r"(?i)(pass(word|wd)?|secret|token|api[_-]?key|authorization|cookie|credential)")
_SECRET_INLINE = [
    re.compile(r"(?i)\b(bearer)\s+[A-Za-z0-9._~+/=-]{12,}"),
    re.compile(r"(?i)\b(password|passwd|pwd|secret|token|api[_-]?key)\s*[=:]\s*([^\s'\";&]+)"),
    re.compile(r"\b(sk-ant-[A-Za-z0-9_-]{10,}|sk-[A-Za-z0-9]{20,}|ghp_[A-Za-z0-9]{20,}|xox[abp]-[A-Za-z0-9-]{10,})"),
]


# ----------------------------------------------------------------- config

def _cfg() -> dict:
    global _CFG_CACHE
    if _CFG_CACHE is None:
        try:
            p = ROOT / "tools" / "config.json"
            _CFG_CACHE = json.loads(p.read_text(encoding="utf-8")).get("logging", {}) if p.exists() else {}
        except Exception:
            _CFG_CACHE = {}
    return _CFG_CACHE


def enabled() -> bool:
    return os.environ.get("GOAL_LOG", str(_cfg().get("enabled", "1"))).lower() not in ("0", "false", "no", "off")


def log_dir() -> Path:
    d = os.environ.get("GOAL_LOG_DIR") or _cfg().get("dir")
    p = Path(os.path.expandvars(os.path.expanduser(d))) if d else ROOT / "logs"
    return p if p.is_absolute() else ROOT / p


def setting(key: str, default=None):
    return _cfg().get(key, default)


# ----------------------------------------------------------------- helpers

def now() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="milliseconds")


def today() -> str:
    return dt.date.today().isoformat()


def safe(s, default="unknown") -> str:
    s = re.sub(r"[^A-Za-z0-9._-]", "_", str(s or ""))[:120]
    return s or default


def redact(obj):
    """Mask likely secrets in keys and inline strings. Applied to conversation/tool logs, not mail data."""
    if isinstance(obj, dict):
        return {k: ("***" if _SECRET_KEYS.search(str(k)) and isinstance(v, (str, int)) and v else redact(v))
                for k, v in obj.items()}
    if isinstance(obj, list):
        return [redact(v) for v in obj]
    if isinstance(obj, str):
        s = obj
        s = _SECRET_INLINE[0].sub(lambda m: f"{m.group(1)} ***", s)
        s = _SECRET_INLINE[1].sub(lambda m: f"{m.group(1)}=***", s)
        s = _SECRET_INLINE[2].sub("***", s)
        return s
    return obj


def _default(o):
    if isinstance(o, (dt.datetime, dt.date)):
        return o.isoformat()
    if isinstance(o, (bytes, bytearray)):
        return f"<{len(o)} bytes>"
    return str(o)


# ----------------------------------------------------------------- locked append

def _lock(f):
    if os.name == "nt":
        import msvcrt
        f.seek(0)
        for _ in range(200):  # ~10s
            try:
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
                return
            except OSError:
                time.sleep(0.05)
        raise TimeoutError("log lock timeout")
    import fcntl
    fcntl.flock(f.fileno(), fcntl.LOCK_EX)


def _unlock(f):
    try:
        if os.name == "nt":
            import msvcrt
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
    except Exception:
        pass


def append(path: Path, line: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8", newline="\n") as f:
        _lock(f)
        try:
            f.write(line if line.endswith("\n") else line + "\n")
            f.flush()
        finally:
            _unlock(f)


def _record_error(where: str, exc: BaseException) -> None:
    try:
        rec = {"ts": now(), "ch": "errors", "ev": "log_failure", "where": where,
               "error": f"{type(exc).__name__}: {exc}", "trace": traceback.format_exc()[-1500:]}
        append(log_dir() / "errors" / f"{today()}.jsonl", json.dumps(rec, default=_default))
    except Exception:
        pass


# ----------------------------------------------------------------- public API

def event(ch: str, ev: str, file: Path | None = None, **fields) -> None:
    """Append one record. `file` overrides the channel's default file."""
    if not enabled():
        return
    try:
        rec = {"ts": now(), "ch": ch, "ev": ev}
        rec.update(fields)
        path = file or log_dir() / ch / f"{today()}.jsonl"
        append(path, json.dumps(rec, ensure_ascii=False, default=_default))
    except Exception as e:
        _record_error(f"{ch}.{ev}", e)


def run_context() -> dict:
    """Goal/task/run/script for the current adhoc run (set by tools/adhoc.py)."""
    ctx = {}
    for k, env in (("goal", "GOAL_ID"), ("task", "GOAL_TASK"), ("run", "GOAL_RUN_ID"), ("script", "GOAL_SCRIPT")):
        v = os.environ.get(env)
        if v:
            ctx[k] = v
    return ctx


def data(ev: str, **fields) -> None:
    """Log mail data read from Outlook/Barracuda. One file per adhoc run."""
    ctx = run_context()
    f = log_dir() / "data" / today() / f"{safe(ctx.get('goal'), 'adhoc')}__{safe(ctx.get('run'), str(os.getpid()))}.jsonl"
    event("data", ev, file=f, **ctx, **fields)


def tool(ev: str, **fields) -> None:
    event("tools", ev, **run_context(), **redact(fields))


class _Handler(logging.Handler):
    def __init__(self, ch: str):
        super().__init__()
        self.ch = ch

    def emit(self, r: logging.LogRecord) -> None:
        extra = {k: v for k, v in r.__dict__.items() if k not in logging.LogRecord("", 0, "", 0, "", (), None).__dict__
                 and k not in ("message", "asctime")}
        event(self.ch, "log", level=r.levelname, logger=r.name, msg=r.getMessage(), **run_context(), **extra)


def get_logger(name: str, ch: str = "tools", level=logging.INFO) -> logging.Logger:
    """Standard-library logger that writes into the JSONL channel. logger.info("x", extra={"k": v})."""
    lg = logging.getLogger(f"goal.{name}")
    if not any(isinstance(h, _Handler) for h in lg.handlers):
        lg.addHandler(_Handler(ch))
        lg.setLevel(level)
        lg.propagate = False
    return lg
