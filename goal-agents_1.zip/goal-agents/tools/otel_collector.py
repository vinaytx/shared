"""otel_collector - tiny local OTLP/HTTP (JSON) receiver that writes Claude Code telemetry to logs/otel/.

Claude Code's telemetry adds what hooks can't see: every model API call (model, input/output/cache
tokens, cost, latency, request id), API errors, and - with OTEL_LOG_RAW_API_BODIES=file:<dir> -
the complete request and response JSON for every LLM call (written by Claude Code to logs/api/).

    bash tools/run logs collector            # foreground (Ctrl+C to stop)
    bash tools/run logs collector --ensure   # start in background if not already running

Enable it for this project with `bash tools/run logs enable-api` and restart Claude Code.
Listens on 127.0.0.1 only.
"""
from __future__ import annotations

import argparse
import gzip
import json
import os
import socket
import subprocess
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))
import _glog  # noqa: E402

DEFAULT_PORT = 4318


def anyvalue(v: dict):
    if not isinstance(v, dict):
        return v
    for k in ("stringValue", "boolValue", "doubleValue"):
        if k in v:
            return v[k]
    if "intValue" in v:
        try:
            return int(v["intValue"])
        except (TypeError, ValueError):
            return v["intValue"]
    if "arrayValue" in v:
        return [anyvalue(x) for x in v["arrayValue"].get("values", [])]
    if "kvlistValue" in v:
        return {x["key"]: anyvalue(x.get("value", {})) for x in v["kvlistValue"].get("values", [])}
    return v


def attrs(lst) -> dict:
    return {a.get("key"): anyvalue(a.get("value", {})) for a in (lst or [])}


def handle_logs(doc: dict) -> int:
    n = 0
    for rl in doc.get("resourceLogs", []):
        res = attrs((rl.get("resource") or {}).get("attributes"))
        for sl in rl.get("scopeLogs", []):
            for r in sl.get("logRecords", []):
                a = attrs(r.get("attributes"))
                name = a.get("event.name") or anyvalue(r.get("body", {})) or "log"
                _glog.event("otel", str(name).replace("claude_code.", ""), attributes=a,
                            session=a.get("session.id") or res.get("session.id"),
                            time_unix_nano=r.get("timeUnixNano"), resource=res)
                n += 1
    return n


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):  # silence default stderr access log
        pass

    def do_POST(self):
        try:
            body = self.rfile.read(int(self.headers.get("Content-Length", 0)))
            if self.headers.get("Content-Encoding", "").lower() == "gzip":
                body = gzip.decompress(body)
            ctype = self.headers.get("Content-Type", "")
            if "json" not in ctype:
                _glog.event("otel", "unsupported_content_type", content_type=ctype, path=self.path, bytes=len(body))
                self._reply(415, {"error": "use OTEL_EXPORTER_OTLP_PROTOCOL=http/json"})
                return
            doc = json.loads(body or b"{}")
            if self.path.endswith("/v1/logs"):
                handle_logs(doc)
            elif self.path.endswith("/v1/metrics"):
                _glog.event("otel", "metrics", file=_glog.log_dir() / "otel" / f"{_glog.today()}.metrics.jsonl", payload=doc)
            elif self.path.endswith("/v1/traces"):
                _glog.event("otel", "traces", file=_glog.log_dir() / "otel" / f"{_glog.today()}.traces.jsonl", payload=doc)
            self._reply(200, {})
        except Exception as e:
            _glog.event("errors", "otel_collector", error=str(e), path=self.path)
            self._reply(400, {"error": str(e)})

    def _reply(self, code, obj):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)


def port_in_use(port: int) -> bool:
    with socket.socket() as s:
        s.settimeout(0.3)
        return s.connect_ex(("127.0.0.1", port)) == 0


def serve(port: int) -> None:
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    _glog.event("otel", "collector_started", port=port, pid=os.getpid())
    print(f"otel collector listening on 127.0.0.1:{port} -> {(_glog.log_dir() / 'otel').as_posix()}")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


def ensure(port: int) -> None:
    if port_in_use(port):
        print(f"collector: already running on {port}")
        return
    args = [sys.executable, str(Path(__file__).resolve()), "--port", str(port)]
    kw = {"stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL, "close_fds": True}
    if os.name == "nt":
        kw["creationflags"] = 0x00000008 | 0x00000200 | 0x08000000  # DETACHED | NEW_GROUP | NO_WINDOW
    else:
        kw["start_new_session"] = True
    subprocess.Popen(args, **kw)
    print(f"collector: started on {port}")


def main():
    ap = argparse.ArgumentParser(prog="tools/run logs collector")
    ap.add_argument("--port", type=int, default=int(os.environ.get("GOAL_OTEL_PORT", DEFAULT_PORT)))
    ap.add_argument("--ensure", action="store_true", help="start in background if not running")
    a = ap.parse_args()
    ensure(a.port) if a.ensure else serve(a.port)


if __name__ == "__main__":
    main()
