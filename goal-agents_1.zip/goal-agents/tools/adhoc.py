"""adhoc - check and run a generated query script, with capped output.

    bash tools/run adhoc .goals/<goal>/scratch/<task>/<name>.py [--timeout 180] [--max-out 3000]

1. The script must live under .goals/<goal>/scratch/ (which `cleanup` deletes).
2. Static check (AST): only allow-listed imports, no file/process/network access,
   no eval/exec/getattr, no attribute assignment, and no COM methods that change or
   send mail (Send, Delete, Move, Save, ...). Rejections list line numbers.
3. Runs with tools/lib on the path, cwd = the scratch dir, and GOAL_SCRATCH /
   GOAL_ARTIFACTS set. Output over --max-out chars is cut; the full text is kept
   in <name>.out next to the script.
4. Logs (logs/tools/): script source, lint result, full stdout/stderr, and exactly what was
   shown to the model. Each run gets an id (run=xxxxxxxx in the trailer) that also tags the
   data reads it made (logs/data/).

This is a guardrail against mistakes and prompt-injected instructions, not a sandbox.
"""
from __future__ import annotations

import argparse
import ast
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LIB = ROOT / "tools" / "lib"
GOALS = ROOT / ".goals"
sys.path.insert(0, str(LIB))
import _glog  # noqa: E402

STD_OK = {
    "re", "datetime", "collections", "itertools", "functools", "json", "math", "statistics", "textwrap",
    "string", "typing", "dataclasses", "hashlib", "html", "operator", "decimal", "fractions", "difflib",
    "calendar", "unicodedata", "heapq", "bisect", "enum", "pprint", "__future__",
}
BUILTINS_BLOCKED = {"eval", "exec", "compile", "__import__", "open", "input", "breakpoint", "globals", "locals",
                    "vars", "getattr", "setattr", "delattr", "exit", "quit", "memoryview", "help"}
# COM methods that change, send or display mail, plus file-system mutators on Path-like objects.
ATTRS_BLOCKED = {
    "Send", "Delete", "PermanentDelete", "Move", "MoveTo", "CopyTo", "Copy", "Forward", "Reply", "ReplyAll",
    "Save", "SaveAs", "SaveAsFile", "Close", "Display", "Execute", "Respond", "Remove", "Add", "AddMember",
    "CreateItem", "CreateItemFromTemplate", "Logon", "Logoff", "Quit", "MarkAsTask", "ClearTaskFlag",
    "Delegate", "ShowCategoriesDialog", "PrintOut", "Import", "Export",
    "write_text", "write_bytes", "unlink", "rmdir", "rename", "mkdir", "touch", "chmod", "symlink_to",
    "hardlink_to", "open", "system", "popen", "rmtree",
}
MAX_LINES = 400


def lib_modules() -> set[str]:
    return {p.stem for p in LIB.glob("*.py") if not p.stem.startswith("_") and p.stem != "TEMPLATE"}


def lint(src: str, libs: set[str]) -> list[str]:
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        return [f"line {e.lineno}: syntax error: {e.msg}"]
    bad: list[str] = []
    ok_mods = STD_OK | libs
    if src.count("\n") > MAX_LINES:
        bad.append(f"script longer than {MAX_LINES} lines - keep ad hoc scripts short")
    for n in ast.walk(tree):
        ln = getattr(n, "lineno", "?")
        if isinstance(n, ast.Import):
            for a in n.names:
                if a.name.split(".")[0] not in ok_mods:
                    bad.append(f"line {ln}: import '{a.name}' not allowed (use: {', '.join(sorted(libs))} or safe stdlib)")
        elif isinstance(n, ast.ImportFrom):
            mod = (n.module or "").split(".")[0]
            if n.level or mod not in ok_mods:
                bad.append(f"line {ln}: import from '{n.module}' not allowed")
            if any(a.name == "*" for a in n.names) and mod not in libs:
                bad.append(f"line {ln}: 'import *' only allowed from helper libs")
        elif isinstance(n, ast.Name) and n.id in BUILTINS_BLOCKED:
            bad.append(f"line {ln}: '{n.id}' not allowed")
        elif isinstance(n, ast.Attribute):
            if n.attr.startswith("__"):
                bad.append(f"line {ln}: dunder attribute '{n.attr}' not allowed")
            elif n.attr in ATTRS_BLOCKED:
                bad.append(f"line {ln}: '.{n.attr}' not allowed (read-only; use helper methods like save_atts/export)")
            if isinstance(n.ctx, (ast.Store, ast.Del)):
                bad.append(f"line {ln}: assigning/deleting attributes not allowed")
        elif isinstance(n, ast.Subscript) and isinstance(n.ctx, (ast.Store, ast.Del)) and isinstance(n.value, ast.Attribute):
            bad.append(f"line {ln}: item assignment on an attribute not allowed")
    return sorted(set(bad), key=lambda s: (len(s.split(":")[0]), s))


def locate(script: Path) -> tuple[Path, Path, str, str]:
    """Return (scratch_dir, artifacts_dir, goal, task) or exit if not in a goal scratch dir."""
    try:
        rel = script.resolve().relative_to(GOALS.resolve())
    except ValueError:
        sys.exit(fail(2, "script must be under .goals/<goal>/scratch/", script=str(script)))
    parts = rel.parts
    if len(parts) < 3 or parts[1] != "scratch" or script.suffix != ".py":
        sys.exit(fail(2, "script must be .goals/<goal>/scratch/[<task>/]<name>.py", script=str(script)))
    task = parts[2] if len(parts) > 3 else "main"
    return script.resolve().parent, GOALS.resolve() / parts[0] / "artifacts" / task, parts[0], task


def fail(code: int, msg: str, **ctx) -> int:
    print(f"ADHOC ERROR: {msg}")
    _glog.tool("adhoc.error", code=code, message=msg, **ctx)
    return code


class Shown:
    """Collects exactly what is printed (i.e. what the model sees) so it can be logged."""

    def __init__(self):
        self.parts: list[str] = []

    def __call__(self, s: str = "") -> None:
        print(s)
        self.parts.append(s)

    def text(self) -> str:
        return "\n".join(self.parts)


def main() -> int:
    ap = argparse.ArgumentParser(prog="tools/run adhoc")
    ap.add_argument("script")
    ap.add_argument("--timeout", type=int, default=180)
    ap.add_argument("--max-out", type=int, default=3000)
    a = ap.parse_args()

    script = Path(a.script)
    if not script.is_absolute():
        script = (Path.cwd() / script)
    if not script.is_file():
        return fail(2, f"no such script: {a.script}")
    scratch, artifacts, goal, task = locate(script)
    run_id = uuid.uuid4().hex[:8]
    script_rel = script.resolve().relative_to(ROOT.resolve()).as_posix()
    os.environ.update({"GOAL_ID": goal, "GOAL_TASK": task, "GOAL_RUN_ID": run_id, "GOAL_SCRIPT": script_rel})
    src = script.read_text(encoding="utf-8")
    show = Shown()

    problems = lint(src, lib_modules())
    if problems:
        show("LINT REJECTED - fix and rerun:")
        show("\n".join("  " + p for p in problems[:20]))
        _glog.tool("adhoc.lint_rejected", source=src, problems=problems, shown=show.text())
        return 2
    _glog.tool("adhoc.start", source=src, timeout=a.timeout, max_out=a.max_out)

    env = dict(os.environ)
    pp = os.pathsep.join(p for p in (str(LIB), env.get("PYTHONPATH", "")) if p)
    env.update({"PYTHONPATH": pp, "GOAL_SCRATCH": str(scratch), "GOAL_ARTIFACTS": str(artifacts),
                "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8", "PYTHONDONTWRITEBYTECODE": "1"})
    t0 = time.time()
    try:
        p = subprocess.run([sys.executable, "-B", str(script)], cwd=str(scratch), env=env,
                           capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=a.timeout)
    except subprocess.TimeoutExpired as e:
        _glog.tool("adhoc.timeout", seconds=a.timeout, stdout=_txt(e.stdout), stderr=_txt(e.stderr))
        return fail(124, f"timed out after {a.timeout}s - narrow the query (dates, folder, limit)")
    secs = time.time() - t0

    out = p.stdout or ""
    full_path = None
    if len(out) > a.max_out:
        full = script.with_suffix(".out")
        full.write_text(out, encoding="utf-8")
        full_path = full.relative_to(ROOT).as_posix()
        cut = out[: a.max_out].rsplit("\n", 1)[0]
        out = f"{cut}\n[output cut at {a.max_out} of {len(p.stdout)} chars; full: {full_path}]"
    if out.strip():
        show(out.rstrip())
    err = (p.stderr or "").replace(str(ROOT) + os.sep, "").replace(str(ROOT) + "/", "").strip().splitlines()
    if p.returncode in (2, 3) and err and err[-1].startswith(("BLOCKED", "QUERY ERROR")):
        show(err[-1])
    elif p.returncode != 0 and err:
        show("STDERR (tail):")
        show("\n".join("  " + l for l in err[-10:]))
    show(f"[exit={p.returncode} {secs:.1f}s run={run_id}]")
    _glog.tool("adhoc.end", exit=p.returncode, seconds=round(secs, 3), stdout=p.stdout, stderr=p.stderr,
               stdout_chars=len(p.stdout or ""), cut=full_path is not None, full_output=full_path, shown=show.text())
    return p.returncode


def _txt(v) -> str:
    if v is None:
        return ""
    return v.decode("utf-8", "replace") if isinstance(v, bytes) else v


if __name__ == "__main__":
    sys.exit(main())
