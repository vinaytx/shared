"""logs - inspect and manage the framework's logs (for people; agents don't need this).

    bash tools/run logs status                       sizes and file counts per channel
    bash tools/run logs sessions [--n 20]            recent sessions with their first request
    bash tools/run logs timeline [--session ID] [--n 200] [--width 140]
                                                     one line per event: requests, tool calls/returns,
                                                     subagents, responses, runs, data reads, API calls
    bash tools/run logs export [--session ID] [--out FILE.md] [--full]
                                                     Markdown audit report of a session (default: latest)
    bash tools/run logs prune [--days N]             delete log files older than N days (default: logging.retention_days or 30)
    bash tools/run logs enable-api [--port 4318]     log every LLM API request/response (OpenTelemetry), restart needed
    bash tools/run logs disable-api
    bash tools/run logs collector [--ensure]         run the local OTLP receiver
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import shutil
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools" / "lib"))
import _glog  # noqa: E402

LOGS = _glog.log_dir()
LOCAL_SETTINGS = ROOT / ".claude" / "settings.local.json"
API_FLAG = LOGS / ".api_logging_enabled"


# ----------------------------------------------------------------- reading

def read_jsonl(p: Path):
    try:
        with open(p, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        yield json.loads(line)
                    except json.JSONDecodeError:
                        continue
    except FileNotFoundError:
        return


def session_files() -> dict[str, list[Path]]:
    out: dict[str, list[Path]] = {}
    for p in (LOGS / "hooks").glob("*/*.jsonl"):
        out.setdefault(p.stem, []).append(p)
    return out


def latest_session() -> str | None:
    files = session_files()
    if not files:
        return None
    return max(files, key=lambda s: max(f.stat().st_mtime for f in files[s]))


def hook_events(session: str) -> list[dict]:
    recs = [r for p in sorted(session_files().get(session, [])) for r in read_jsonl(p)]
    return sorted(recs, key=lambda r: r.get("ts", ""))


def window(recs: list[dict]) -> tuple[str, str]:
    return (recs[0]["ts"], recs[-1]["ts"]) if recs else ("", "")


def tool_events(lo: str, hi: str) -> list[dict]:
    out = []
    for p in sorted((LOGS / "tools").glob("*.jsonl")):
        out += [r for r in read_jsonl(p) if lo <= r.get("ts", "") <= hi + "z"]
    return out


def data_events(run_ids: set[str]) -> list[dict]:
    out = []
    for p in sorted((LOGS / "data").glob("*/*.jsonl")):
        if any(p.stem.endswith("__" + r) for r in run_ids):
            out += list(read_jsonl(p))
    return out


def otel_events(session: str) -> list[dict]:
    out = []
    for p in sorted((LOGS / "otel").glob("*.jsonl")):
        if p.name.count(".") > 1:  # metrics/traces files
            continue
        out += [r for r in read_jsonl(p) if r.get("session") == session]
    return out


def short(v, n=140) -> str:
    s = v if isinstance(v, str) else json.dumps(v, ensure_ascii=False, default=str)
    s = re.sub(r"\s+", " ", s or "").strip()
    return s if len(s) <= n else s[: n - 1] + "…"


def resp_text(r) -> str:
    tr = r.get("tool_response")
    if isinstance(tr, dict):
        for k in ("stdout", "content", "result", "output", "text"):
            if tr.get(k):
                return tr[k] if isinstance(tr[k], str) else json.dumps(tr[k], ensure_ascii=False, default=str)
    return tr if isinstance(tr, str) else json.dumps(tr, ensure_ascii=False, default=str)


def who(r) -> str:
    return r.get("agent_type") or "main"


# ----------------------------------------------------------------- commands

def cmd_status(a) -> int:
    if not LOGS.exists():
        print(f"no logs yet ({LOGS})")
        return 0
    print(f"logs dir: {LOGS}")
    for ch in sorted(p for p in LOGS.iterdir() if p.is_dir()):
        files = [f for f in ch.rglob("*") if f.is_file()]
        print(f"  {ch.name:12} {len(files):6} files {sum(f.stat().st_size for f in files) / 1048576:9.2f} MB")
    print(f"api logging: {'on' if API_FLAG.exists() else 'off'}")
    return 0


def cmd_sessions(a) -> int:
    files = session_files()
    rows = []
    for s, fs in files.items():
        first = next((r for r in hook_events(s) if r.get("kind") == "user_request"), None)
        mt = max(f.stat().st_mtime for f in fs)
        rows.append((mt, s, short(first.get("prompt") if first else "", 90)))
    for mt, s, p in sorted(rows, reverse=True)[: a.n]:
        print(f"{dt.datetime.fromtimestamp(mt):%Y-%m-%d %H:%M}  {s}  {p}")
    return 0


def timeline_rows(session: str) -> list[tuple[str, str, str, str]]:
    hooks = hook_events(session)
    lo, hi = window(hooks)
    rows = []
    for r in hooks:
        k, w = r.get("kind"), who(r)
        if k == "user_request":
            rows.append((r["ts"], w, "USER", short(r.get("prompt"), 400)))
        elif k == "tool_call":
            ti = r.get("tool_input") or {}
            desc = ti.get("command") or ti.get("file_path") or ti.get("prompt") or ti
            if r.get("tool_name") == "Agent":
                desc = f"-> {ti.get('subagent_type')}: {ti.get('prompt')}"
            rows.append((r["ts"], w, f"CALL {r.get('tool_name')}", short(desc, 400)))
        elif k == "tool_return":
            rows.append((r["ts"], w, f"RET  {r.get('tool_name')}", short(resp_text(r), 400)))
        elif k in ("tool_error", "permission_denied", "turn_failed"):
            rows.append((r["ts"], w, k.upper(), short(r.get("error") or r, 400)))
        elif k == "subagent_start":
            rows.append((r["ts"], w, "SUBAGENT START", r.get("agent_id") or ""))
        elif k == "subagent_response":
            rows.append((r["ts"], w, "SUBAGENT DONE", short(r.get("last_assistant_message"), 400)))
        elif k == "response_to_user":
            rows.append((r["ts"], w, "ASSISTANT", short(r.get("last_assistant_message"), 400)))
        elif k in ("session_start", "session_end", "compact"):
            rows.append((r["ts"], w, k.upper(), short(r.get("source") or r.get("reason") or r.get("trigger") or "", 60)))
    runs = set()
    for t in tool_events(lo, hi):
        if t.get("ev") == "adhoc.end":
            runs.add(t.get("run", ""))
            rows.append((t["ts"], t.get("task", ""), "RUN", f"run={t.get('run')} {t.get('script')} exit={t.get('exit')} "
                                                            f"{t.get('seconds')}s stdout={t.get('stdout_chars')} chars"))
        elif t.get("ev") in ("adhoc.lint_rejected", "guard.block", "cleanup.removed"):
            rows.append((t["ts"], t.get("task") or t.get("agent") or "", t["ev"].upper(),
                         short(t.get("problems") or t.get("reason") or t.get("path"), 300)))
    for d in data_events(runs):
        if d.get("ev") in ("olk.search", "eml.search"):
            rows.append((d["ts"], d.get("task", ""), "DATA " + d["ev"], f"{d.get('count', d.get('matched'))} results "
                                                                      f"{short(d.get('params'), 200)}"))
        elif d.get("ev") in ("olk.body", "eml.body", "olk.save_att", "eml.save_att", "olk.export"):
            rows.append((d["ts"], d.get("task", ""), "DATA " + d["ev"], short(d.get("subject") or d.get("path"), 120)))
    for o in otel_events(session):
        if o.get("ev") == "api_request":
            at = o.get("attributes", {})
            rows.append((o["ts"], "api", "LLM CALL", f"{at.get('model')} in={at.get('input_tokens')} out={at.get('output_tokens')} "
                                                     f"cache_read={at.get('cache_read_tokens')} ${at.get('cost_usd')} {at.get('duration_ms')}ms"))
    return sorted(rows, key=lambda r: r[0])  # stable: keeps file order within the same millisecond


def cmd_timeline(a) -> int:
    s = a.session or latest_session()
    if not s:
        print("no sessions logged yet")
        return 0
    rows = timeline_rows(s)
    print(f"session {s} ({len(rows)} events)")
    for ts, w, kind, text in rows[-a.n:]:
        line = f"{ts[11:23]} {w[:18]:18} {kind:22} {text}"
        print(line if len(line) <= a.width else line[: a.width - 1] + "…")
    return 0


def fence(text, full: bool, n=4000) -> str:
    s = text if isinstance(text, str) else json.dumps(text, ensure_ascii=False, indent=2, default=str)
    if not full and len(s) > n:
        s = s[:n] + f"\n... [{len(s) - n} more chars - use --full]"
    return "```\n" + s.replace("```", "`​``") + "\n```"


def cmd_export(a) -> int:
    s = a.session or latest_session()
    if not s:
        print("no sessions logged yet")
        return 0
    hooks = hook_events(s)
    lo, hi = window(hooks)
    md = [f"# Session log {s}", "", f"From {lo} to {hi}", ""]
    for r in hooks:
        k, w, ts = r.get("kind"), who(r), r["ts"]
        if k == "user_request":
            md += [f"## {ts} - User request", "", r.get("prompt", ""), ""]
        elif k == "tool_call":
            md += [f"### {ts} - {w}: tool call `{r.get('tool_name')}`", "", fence(r.get("tool_input"), a.full), ""]
        elif k == "tool_return":
            md += [f"### {ts} - {w}: tool return `{r.get('tool_name')}`", "", fence(resp_text(r), a.full), ""]
        elif k == "subagent_start":
            md += [f"### {ts} - subagent `{w}` started ({r.get('agent_id')})", ""]
        elif k == "subagent_response":
            md += [f"### {ts} - subagent `{w}` final message", "", fence(r.get("last_assistant_message", ""), a.full), ""]
        elif k == "response_to_user":
            md += [f"## {ts} - Response to user", "", r.get("last_assistant_message", ""), ""]
        elif k in ("tool_error", "permission_denied", "turn_failed"):
            md += [f"### {ts} - {k}", "", fence(r, a.full), ""]
    tools = tool_events(lo, hi)
    runs = [t for t in tools if t.get("ev") == "adhoc.start"]
    if runs:
        md += ["## Generated scripts", ""]
        ends = {t.get("run"): t for t in tools if t.get("ev") == "adhoc.end"}
        for t in runs:
            e = ends.get(t.get("run"), {})
            md += [f"### run {t.get('run')} - {t.get('script')} (exit {e.get('exit')}, {e.get('seconds')}s)", "",
                   "```python\n" + t.get("source", "") + "\n```", "", "Shown to the model:", "", fence(e.get("shown", ""), a.full), ""]
    data = data_events({t.get("run", "") for t in runs})
    if data:
        md += ["## Mail data read", "", "| time | run | event | detail |", "|---|---|---|---|"]
        for d in data:
            det = d.get("params") or d.get("subject") or d.get("path") or d.get("id") or ""
            cnt = d.get("count", d.get("matched", ""))
            md.append(f"| {d['ts'][11:19]} | {d.get('run', '')} | {d['ev']} | {short(det, 90).replace('|', '/')} {cnt} |")
        md += ["", f"Full records: logs/data/ (files ending in __<run>.jsonl)", ""]
    api = [o for o in otel_events(s) if o.get("ev") == "api_request"]
    if api:
        tot = lambda k: sum(float(o.get("attributes", {}).get(k) or 0) for o in api)  # noqa: E731
        md += ["## LLM API calls", "", f"{len(api)} calls, input {int(tot('input_tokens'))} tokens, output "
               f"{int(tot('output_tokens'))}, cache read {int(tot('cache_read_tokens'))}, cost ${tot('cost_usd'):.4f}",
               "", "Raw request/response bodies: logs/api/", ""]
    tdir = LOGS / "transcripts" / s
    if tdir.exists():
        md += ["## Full transcripts", "", *[f"- logs/transcripts/{s}/{f.name}" for f in sorted(tdir.glob("*.jsonl"))], ""]
    out = Path(a.out) if a.out else LOGS / "exports" / f"{s}.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(md), encoding="utf-8")
    print(f"wrote {out}")
    return 0


def cmd_prune(a) -> int:
    days = a.days if a.days is not None else int(_glog.setting("retention_days", 30))
    cutoff = time.time() - days * 86400
    n = 0
    for p in sorted(LOGS.rglob("*"), key=lambda x: -len(x.parts)) if LOGS.exists() else []:
        if p.is_file() and not p.name.startswith(".") and p.stat().st_mtime < cutoff:
            p.unlink()
            n += 1
        elif p.is_dir() and not any(p.iterdir()):
            p.rmdir()
    _glog.tool("logs.prune", days=days, removed=n)
    print(f"logs: pruned {n} files older than {days} days")
    return 0


def load_local() -> dict:
    try:
        return json.loads(LOCAL_SETTINGS.read_text(encoding="utf-8")) if LOCAL_SETTINGS.exists() else {}
    except json.JSONDecodeError:
        raise SystemExit(f"{LOCAL_SETTINGS} is not valid JSON; fix it first")


OTEL_KEYS = ["CLAUDE_CODE_ENABLE_TELEMETRY", "OTEL_LOGS_EXPORTER", "OTEL_METRICS_EXPORTER", "OTEL_EXPORTER_OTLP_PROTOCOL",
             "OTEL_EXPORTER_OTLP_ENDPOINT", "OTEL_LOG_USER_PROMPTS", "OTEL_LOG_ASSISTANT_RESPONSES",
             "OTEL_LOG_TOOL_DETAILS", "OTEL_LOG_RAW_API_BODIES", "OTEL_LOGS_EXPORT_INTERVAL"]


def cmd_enable_api(a) -> int:
    s = load_local()
    api_dir = (LOGS / "api").resolve()
    api_dir.mkdir(parents=True, exist_ok=True)
    s.setdefault("env", {}).update({
        "CLAUDE_CODE_ENABLE_TELEMETRY": "1",
        "OTEL_LOGS_EXPORTER": "otlp",
        "OTEL_METRICS_EXPORTER": "otlp",
        "OTEL_EXPORTER_OTLP_PROTOCOL": "http/json",
        "OTEL_EXPORTER_OTLP_ENDPOINT": f"http://127.0.0.1:{a.port}",
        "OTEL_LOG_USER_PROMPTS": "1",
        "OTEL_LOG_ASSISTANT_RESPONSES": "1",
        "OTEL_LOG_TOOL_DETAILS": "1",
        "OTEL_LOG_RAW_API_BODIES": f"file:{api_dir.as_posix()}",
        "OTEL_LOGS_EXPORT_INTERVAL": "2000",
    })
    LOCAL_SETTINGS.parent.mkdir(parents=True, exist_ok=True)
    LOCAL_SETTINGS.write_text(json.dumps(s, indent=2), encoding="utf-8")
    API_FLAG.parent.mkdir(parents=True, exist_ok=True)
    API_FLAG.write_text(str(a.port))
    _glog.tool("logs.enable_api", port=a.port, api_dir=str(api_dir))
    print(f"api logging enabled in {LOCAL_SETTINGS.relative_to(ROOT).as_posix()} (port {a.port}); "
          "the collector starts automatically at session start. Restart Claude Code to apply.")
    return 0


def cmd_disable_api(a) -> int:
    s = load_local()
    env = s.get("env", {})
    for k in OTEL_KEYS:
        env.pop(k, None)
    if not env:
        s.pop("env", None)
    LOCAL_SETTINGS.write_text(json.dumps(s, indent=2), encoding="utf-8")
    API_FLAG.unlink(missing_ok=True)
    _glog.tool("logs.disable_api")
    print("api logging disabled. Restart Claude Code to apply.")
    return 0


def cmd_session_start(a) -> int:
    """Called by the SessionStart hook: prune old logs, start the collector if API logging is on."""
    a.days = None
    cmd_prune(a)
    if API_FLAG.exists():
        import subprocess
        port = API_FLAG.read_text().strip() or "4318"
        subprocess.run([sys.executable, str(ROOT / "tools" / "otel_collector.py"), "--ensure", "--port", port],
                       capture_output=True, timeout=10)
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(prog="tools/run logs")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("status")
    p = sub.add_parser("sessions"); p.add_argument("--n", type=int, default=20)
    p = sub.add_parser("timeline"); p.add_argument("--session"); p.add_argument("--n", type=int, default=200)
    p.add_argument("--width", type=int, default=160)
    p = sub.add_parser("export"); p.add_argument("--session"); p.add_argument("--out"); p.add_argument("--full", action="store_true")
    p = sub.add_parser("prune"); p.add_argument("--days", type=int)
    p = sub.add_parser("enable-api"); p.add_argument("--port", type=int, default=4318)
    sub.add_parser("disable-api")
    sub.add_parser("session-start")
    p = sub.add_parser("collector"); p.add_argument("--ensure", action="store_true"); p.add_argument("--port", type=int, default=4318)
    a = ap.parse_args()
    if a.cmd == "collector":
        sys.argv = [sys.argv[0], "--port", str(a.port)] + (["--ensure"] if a.ensure else [])
        import otel_collector  # noqa: E402
        otel_collector.main()
        return 0
    return {"status": cmd_status, "sessions": cmd_sessions, "timeline": cmd_timeline, "export": cmd_export,
            "prune": cmd_prune, "enable-api": cmd_enable_api, "disable-api": cmd_disable_api,
            "session-start": cmd_session_start}[a.cmd](a)


if __name__ == "__main__":
    sys.path.insert(0, str(ROOT / "tools"))
    sys.exit(main())
