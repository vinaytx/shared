"""log_event - Claude Code hook that records every conversation event to logs/hooks/.

Wired in .claude/settings.json for all relevant events (async, so it never slows the agent):

  UserPromptSubmit    kind=user_request        the user's prompt
  PreToolUse          kind=tool_call           tool name + full input (incl. Agent prompts sent to subagents)
  PostToolUse         kind=tool_return         full tool response
  PostToolUseFailure  kind=tool_error
  PermissionDenied    kind=permission_denied
  SubagentStart       kind=subagent_start
  SubagentStop        kind=subagent_response   the subagent's final message (what the orchestrator receives)
  Stop                kind=response_to_user    Claude's final message for the turn
  StopFailure         kind=turn_failed
  SessionStart/End, PreCompact/PostCompact, Notification   kind=session/compact/notification

On Stop, SubagentStop, PreCompact, StopFailure and SessionEnd it also mirrors the session's
transcripts (main + every subagent) into logs/transcripts/<session>/. Those transcripts hold every
model response (text, tool_use, thinking blocks when present) with token usage.

Always exits 0; a logging failure must never block Claude Code.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
import _glog  # noqa: E402

KIND = {
    "UserPromptSubmit": "user_request", "UserPromptExpansion": "user_request_expanded",
    "PreToolUse": "tool_call", "PostToolUse": "tool_return", "PostToolUseFailure": "tool_error",
    "PermissionRequest": "permission_request", "PermissionDenied": "permission_denied",
    "SubagentStart": "subagent_start", "SubagentStop": "subagent_response",
    "Stop": "response_to_user", "StopFailure": "turn_failed",
    "SessionStart": "session_start", "SessionEnd": "session_end",
    "PreCompact": "compact", "PostCompact": "compact_done", "Notification": "notification",
}
ARCHIVE_ON = {"Stop", "SubagentStop", "PreCompact", "StopFailure", "SessionEnd"}


def main() -> None:
    raw = sys.stdin.read()
    try:
        data = json.loads(raw) if raw.strip() else {}
    except Exception:
        _glog.event("errors", "hook_bad_json", raw=raw[:5000])
        return
    if not _glog.enabled():
        return
    ev = data.get("hook_event_name", "unknown")
    session = _glog.safe(data.get("session_id"), "nosession")
    payload = _glog.redact(data) if _glog.setting("redact_secrets", True) else data
    rec = {"kind": KIND.get(ev, ev), "session": data.get("session_id"), "agent_id": data.get("agent_id"),
           "agent_type": data.get("agent_type") or ("main" if not data.get("agent_id") else None)}
    rec.update({k: v for k, v in payload.items() if k not in ("session_id", "hook_event_name", "agent_id", "agent_type")})
    _glog.event("hooks", ev, file=_glog.log_dir() / "hooks" / _glog.today() / f"{session}.jsonl", **rec)
    if ev in ARCHIVE_ON:
        try:
            archive(data)
        except Exception as e:
            _glog.event("errors", "transcript_archive_failed", session=data.get("session_id"), error=str(e))


def archive(data: dict) -> None:
    """Copy new bytes of the main + subagent transcripts into logs/transcripts/<session>/."""
    tp = data.get("transcript_path")
    if not tp:
        return
    main_t = Path(os.path.expanduser(tp))
    sources: dict[str, Path] = {}
    if main_t.exists():
        sources["main.jsonl"] = main_t
    sub_dir = main_t.with_suffix("") / "subagents"
    for extra in (data.get("agent_transcript_path"),):
        if extra and Path(extra).exists():
            sources[Path(extra).name] = Path(extra)
    if sub_dir.is_dir():
        for f in sub_dir.glob("*.jsonl"):
            sources[f.name] = f
    if not sources:
        return
    dest = _glog.log_dir() / "transcripts" / _glog.safe(data.get("session_id"), "nosession")
    dest.mkdir(parents=True, exist_ok=True)
    state_p = dest / ".offsets.json"
    with open(dest / ".lock", "a+") as lock:
        _glog._lock(lock)
        try:
            state = json.loads(state_p.read_text()) if state_p.exists() else {}
            for name, src in sources.items():
                size = src.stat().st_size
                off = state.get(name, 0)
                if size < off:  # rewritten - start over
                    off = 0
                if size == off:
                    continue
                with open(src, "rb") as fi:
                    fi.seek(off)
                    chunk = fi.read(size - off)
                cut = chunk.rfind(b"\n") + 1  # copy whole lines only
                if cut <= 0:
                    continue
                with open(dest / name, "ab") as fo:
                    fo.write(chunk[:cut])
                state[name] = off + cut
            state_p.write_text(json.dumps(state))
        finally:
            _glog._unlock(lock)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # never fail the hook
        try:
            _glog.event("errors", "log_event_crash", error=f"{type(e).__name__}: {e}")
        except Exception:
            pass
    sys.exit(0)
