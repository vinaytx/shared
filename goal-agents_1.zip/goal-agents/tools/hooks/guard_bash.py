"""PreToolUse(Bash) hook for workers: allow only single `tools/run adhoc|doctor|cleanup` commands.

Exit 0 = allow, exit 2 = block (stderr is shown to the agent so it can correct itself).
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import shlex
import sys

ALLOWED = re.compile(r'^(bash\s+)?("?\$CLAUDE_PROJECT_DIR/)?(\./)?tools/run"?\s+(adhoc|doctor|cleanup)(\s|$)')
OPERATORS = {";", "&&", "||", "|", "&", ">", ">>", "<", "<<", "|&", ";;", "(", ")"}


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "lib"))
import _glog  # noqa: E402


_INPUT: dict = {}


def block(msg: str) -> None:
    _glog.tool("guard.block", hook="guard_bash", reason=msg, agent=_INPUT.get("agent_type"),
               session=_INPUT.get("session_id"), command=(_INPUT.get("tool_input") or {}).get("command"))
    sys.stderr.write(f"Blocked by worker policy: {msg}. Allowed: 'bash tools/run adhoc <script>', "
                     "'bash tools/run doctor', 'bash tools/run cleanup <goal> --task <task>'. "
                     "Write scripts with the Write tool into your scratch dir.\n")
    sys.exit(2)


def main() -> None:
    global _INPUT
    try:
        _INPUT = json.load(sys.stdin)
        cmd = str((_INPUT.get("tool_input") or {}).get("command", "")).strip()
    except Exception:
        block("unreadable hook input")
    if not cmd:
        sys.exit(0)
    if "\n" in cmd or "`" in cmd or "$(" in cmd:
        block("newlines, backticks and $(...) are not allowed")
    try:
        lex = shlex.shlex(cmd, posix=True, punctuation_chars=True)
        lex.whitespace_split = True
        if any(t in OPERATORS for t in lex):
            block("chaining, pipes and redirects are not allowed")
    except ValueError as e:
        block(f"unparseable command ({e})")
    if not ALLOWED.match(cmd):
        block("command not allowed")
    if re.search(r"\scleanup\s.*--purge", cmd):
        block("workers may not purge goals")
    _glog.tool("guard.allow", hook="guard_bash", agent=_INPUT.get("agent_type"), session=_INPUT.get("session_id"),
               command=cmd)
    sys.exit(0)


if __name__ == "__main__":
    main()
