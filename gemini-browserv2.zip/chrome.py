"""
One direct connection to the attended Chrome.

    Chrome (started by you, logged in to Databricks, --remote-debugging-port=9222)
        ^
        |  Chrome DevTools Protocol, one websocket
    this module (Playwright connect_over_cdp)

Nothing is spawned: if Chrome is not running on the port, we raise a clear
error telling you to run scripts/start_chrome.bat. All Databricks calls are
made as `fetch()` inside the Databricks tab, so they carry your login cookies.
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

import requests
from playwright.async_api import Browser, Page, async_playwright

from config import settings

log = logging.getLogger(__name__)


class ChromeNotRunning(Exception):
    pass


class Chrome:
    """Process-wide singleton: one CDP connection, one Databricks tab, one lock."""

    _instance: "Chrome | None" = None

    def __init__(self) -> None:
        cfg = settings()
        self.devtools_url: str = cfg["browser"]["devtools_url"]
        self.workspace: str = cfg["databricks"]["workspace_url"].rstrip("/")
        self.tab_title: str = cfg["browser"].get("genie_tab_title", "Genie")
        self.genie_url: str = f"{self.workspace}/genie/rooms/{cfg['databricks']['genie_space_id']}"
        self._pw = None
        self._browser: Browser | None = None
        self._page: Page | None = None
        self.lock = asyncio.Lock()

    @classmethod
    def get(cls) -> "Chrome":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    # -- connection ----------------------------------------------------------

    @staticmethod
    def port_info(devtools_url: str) -> dict:
        """GET /json/version; raises ChromeNotRunning if nothing listens."""
        try:
            r = requests.get(f"{devtools_url}/json/version", timeout=3)
            r.raise_for_status()
            return r.json()
        except Exception as exc:  # noqa: BLE001
            raise ChromeNotRunning(
                f"No Chrome DevTools endpoint at {devtools_url}. "
                "Start Chrome with scripts/start_chrome.bat and log in to Databricks.") from exc

    async def connect(self) -> None:
        if self._browser and self._browser.is_connected():
            return
        self.port_info(self.devtools_url)
        self._pw = await async_playwright().start()
        self._browser = await self._pw.chromium.connect_over_cdp(self.devtools_url)
        log.info("Connected to Chrome %s", self._browser.version)

    async def close(self) -> None:
        # Only drop OUR websocket; the user's Chrome keeps running.
        if self._browser:
            await self._browser.close()
        if self._pw:
            await self._pw.stop()
        self._browser = self._page = self._pw = None

    async def list_tabs(self) -> list[dict]:
        """Titles and URLs of all open tabs (for diagnostics)."""
        await self.connect()
        out = []
        for ctx in self._browser.contexts:
            for p in ctx.pages:
                try:
                    out.append({"title": await p.title(), "url": p.url})
                except Exception:  # noqa: BLE001
                    out.append({"title": "?", "url": p.url})
        return out

    async def page(self) -> Page:
        """
        The tab to work in, chosen in this order:
          1. a tab whose title contains browser.genie_tab_title (e.g. "Genie One - Databricks")
          2. any tab on the workspace URL
          3. a new tab (same window) opened at the Genie space URL
        """
        await self.connect()
        if self._page and not self._page.is_closed():
            return self._page
        contexts = self._browser.contexts
        if not contexts:
            raise ChromeNotRunning("Chrome has no browser context; open a window first.")
        pages = [p for ctx in contexts for p in ctx.pages]
        want = self.tab_title.lower()
        for p in pages:
            try:
                if want in (await p.title()).lower():
                    log.info("Using Genie tab: %s", await p.title())
                    self._page = p
                    return p
            except Exception:  # noqa: BLE001
                continue
        for p in pages:
            if p.url.startswith(self.workspace):
                log.info("Genie tab %r not found; using workspace tab %s", self.tab_title, p.url)
                self._page = p
                return p
        log.info("No Databricks tab found; opening %s", self.genie_url)
        self._page = await contexts[0].new_page()
        await self._page.goto(self.genie_url, wait_until="domcontentloaded")
        return self._page

    async def current_tab(self) -> dict:
        p = await self.page()
        return {"title": await p.title(), "url": p.url}

    # -- primitives ------------------------------------------------------------

    async def evaluate(self, js: str, arg: Any = None) -> Any:
        page = await self.page()
        return await page.evaluate(js, arg)

    async def navigate(self, url: str) -> None:
        page = await self.page()
        await page.goto(url, wait_until="domcontentloaded")

    async def screenshot(self, path: str) -> str:
        page = await self.page()
        await page.screenshot(path=path, full_page=False)
        return path

    async def api(self, method: str, path: str, body: dict | None = None) -> tuple[int, Any]:
        """Call a Databricks REST path from inside the tab. Returns (status, json_or_text)."""
        cfg = settings()["databricks"]
        headers = {"Content-Type": "application/json", **cfg.get("extra_headers", {})}
        js = """async ({url, method, headers, body}) => {
            const r = await fetch(url, {method, headers, credentials: "include",
                                        body: body === null ? undefined : body});
            const text = await r.text();
            let js = null; try { js = JSON.parse(text); } catch (e) {}
            return {status: r.status, json: js, text: js ? null : text.slice(0, 2000)};
        }"""
        res = await self.evaluate(js, {"url": self.workspace + path, "method": method,
                                       "headers": headers,
                                       "body": None if body is None else json.dumps(body)})
        return res["status"], (res["json"] if res["json"] is not None else res["text"])
