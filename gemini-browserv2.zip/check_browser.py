"""
Step-by-step check of the browser connection to Databricks.

    python scripts/check_browser.py                      # steps 1-4
    python scripts/check_browser.py --test               # + send the configured test question to Genie
    python scripts/check_browser.py --sql "SELECT 1"     # + run a SQL statement
    python scripts/check_browser.py --ask "How many rows are in the KPI table?"   # + ask Genie

Each step prints PASS/FAIL and what to do on failure.
"""
from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import settings  # noqa: E402


def step(n: int, title: str, ok: bool, detail: str = "", fix: str = "") -> bool:
    print(f"[{n}] {'PASS' if ok else 'FAIL'}  {title}" + (f"  -> {detail}" if detail else ""))
    if not ok and fix:
        print(f"      fix: {fix}")
    return ok


async def main(a: argparse.Namespace) -> int:
    cfg = settings()
    ws, dv = cfg["databricks"]["workspace_url"], cfg["browser"]["devtools_url"]

    # 1. settings sanity
    if not step(1, "config/settings.yaml has a real workspace_url",
                not ws.startswith("https://<"), ws, "edit config/settings.yaml"):
        return 1

    # 2. Chrome debug port
    from browser.chrome import Chrome, ChromeNotRunning
    try:
        info = Chrome.port_info(dv)
        step(2, "Chrome DevTools port reachable", True, f"{info.get('Browser')} at {dv}")
    except ChromeNotRunning as exc:
        step(2, "Chrome DevTools port reachable", False, str(exc),
             "run scripts\\start_chrome.bat (Windows) or scripts/start_chrome.sh")
        return 1

    # 3. Genie tab
    chrome = Chrome.get()
    try:
        tabs = await chrome.list_tabs()
        print("      open tabs:")
        for t in tabs:
            print(f"        - {t['title'][:60]!r}  {t['url'][:80]}")
        tab = await chrome.current_tab()
        want = cfg["browser"]["genie_tab_title"]
        step(3, f"Tab {want!r} found", want.lower() in tab["title"].lower(),
             f"using {tab['title']!r}",
             f"open the Genie space in the agent Chrome (tab title should contain {want!r}); "
             "falling back to another workspace tab")
    except Exception as exc:  # noqa: BLE001
        step(3, "Databricks tab available", False, str(exc),
             f"open {ws} in the agent Chrome window")
        await chrome.close()
        return 1

    # 4. logged in?
    from browser.session import probe_session
    p = await probe_session()
    if not step(4, "Logged in to Databricks", p["logged_in"],
                p["email"] or p["error"] or "",
                f"log in to {ws} in the agent Chrome window, then re-run"):
        await chrome.close()
        return 1

    # 5. optional test messages
    from browser import genie_driver
    if a.test:
        q = cfg["browser"]["test_question"]
        print(f"[5] sending test message to Genie: {q!r} ...")
        h = await genie_driver.health_check(deep=True)
        step(5, "Genie answered the test message", h.get("genie_ok", False),
             h.get("genie_answer") or h.get("genie_error", ""),
             "check genie_space_id; open the space in the tab; see state/audit/ for the raw response")
        if h.get("genie_ok"):
            print("      sql:", h.get("genie_sql") or "(none)")
            print("      url:", h.get("genie_url"))
    if a.sql:
        r = await genie_driver.run_sql(a.sql)
        step(5, "SQL statement", r.ok, f"{r.row_count} rows, cols={r.columns}" if r.ok else r.error,
             "check sql_warehouse_id in settings.yaml and that the warehouse is running")
        if r.ok:
            for row in r.rows[:10]:
                print("      ", row)
    if a.ask:
        print(f"[5] asking Genie: {a.ask!r} (this can take a minute) ...")
        r = await genie_driver.ask_genie(a.ask)
        step(5, "Genie question", r.ok,
             (f"{r.row_count} rows; sql={r.sql[:120]!r}" if r.ok else r.error),
             "check genie_space_id in settings.yaml; open the Genie space once in the agent Chrome")
        if r.ok:
            print("      answer:", (r.answer_text or "(no text)")[:500])
            print("      url:   ", r.url)
            for row in r.rows[:10]:
                print("      ", row)
    await chrome.close()
    return 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--test", action="store_true", help="send browser.test_question to Genie")
    ap.add_argument("--sql", help="SQL to execute as a test")
    ap.add_argument("--ask", help="question to send to Genie as a test")
    sys.exit(asyncio.run(main(ap.parse_args())))
