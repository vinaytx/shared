# AI Bot Business Opportunities for Telecom Operators
### Research brief: Always-on bots, Chamberlain myQ AI, and what Verizon / AT&T can launch

*Prepared: October 24, 2026 · Scope: US consumer & small-business markets · Sources: listed in §9 (numbered [n])*

---

## 1. Executive summary

1. **Always-on agents went mainstream in 2026.** The open-source OpenClaw framework exploded in January 2026, showing that consumers want an AI that runs continuously, remembers context and acts proactively (briefings, reminders, inbox triage, home control) rather than waiting for prompts [5][6][7]. OpenAI hired its creator in February to lead "personal agents" [8][9], and by fall 2026 commercial personal agents (e.g., Meta's Muse) were contacting companies on users' behalf [11].
2. **Demand is far ahead of supply.** An October 2026 survey of ~2,000 US consumers found two-thirds interested in an AI agent that deals with companies for them, but at most ~6% have actually had one do it; negotiation/getting a better price is the task consumers are most willing to delegate [11].
3. **The safety gap is the opening.** Self-hosted always-on agents carry serious security risk; large companies banned OpenClaw on corporate networks [6][9]. Mainstream consumers will need a *trusted, managed, always-on* agent — a role that matches a carrier's strengths (identity, billing, network, 24/7 support, retail presence).
4. **Chamberlain shows the device-to-AI-subscription playbook.** Chamberlain (LiftMaster/Chamberlain, 50M+ homes, ~14–15M daily myQ app users) layered myQ AI detection onto garage openers, cameras, a video doorbell and — at CES 2026 — the myQ Secure View 3-in-1 smart lock, using AI to coordinate actions (auto-lock, close garage) across access points, with AI features tied to a paid video subscription [12][13][14][16][17]. Its closed-API stance and paywall criticism are lessons in what *not* to do [18][19].
5. **Carriers have started, but mostly on care, not new revenue.** Verizon's Gemini-based assistant and AT&T's network-based **Digital Receptionist** pilot are the clearest US moves [20][21][24][25]; T-Mobile launched network-native **Live Translation** [27][28]; Deutsche Telekom launched an in-network **Magenta AI Call Assistant** with ElevenLabs [30]. Bundling third-party AI subscriptions is widespread globally but take-up is uncertain [32][33].
6. **Recommendation:** Verizon/AT&T should build a **carrier-grade, always-on "Personal Agent" platform** anchored in the phone number and the home broadband connection, monetized as a tiered add-on ($5–$15/mo) with partner revenue share. Priority launch candidates: (a) AI Call Agent / Receptionist+, (b) "Bill & Deals Negotiator" agent, (c) Home Guardian agent (smart-home/access orchestration in the Chamberlain mold), (d) Family/Senior Safety agent, (e) SMB AI front desk. Details in §6.

---

## 2. Methodology

- **Approach:** Systematic desk research across three tracks — (A) rise of always-on bots/personal agents, (B) Chamberlain Group's myQ AI product line, (C) telecom operator AI services (US + international benchmarks) — followed by a synthesis to identify operator opportunities.
- **Sources:** Company press releases and support pages, trade press (CE Pro, CX Today, Mobile World Live, Telecoms.com, RCR Wireless), mainstream tech press (PCWorld, Tom's Guide, Bloomberg), analyst/insight firms (CCS Insight, Rethink, Lorikeet survey).
- **Evidence grading:** **[P]** primary (company/official), **[T]** trade/press, **[S]** secondary/aggregator — treat with caution.
- **Limitations:** No financial disclosures for privately held Chamberlain (Blackstone-owned). No Chamberlain garage-specific AI launch after January 2026 was found in public sources; if you are referring to a more recent or regional announcement, share the link and this brief can be updated. Some 2026 "trend" articles are low quality and were excluded.

---

## 3. Track A — The rise and launch of always-on bots

### 3.1 Timeline

| When | Event | Significance | Ref |
|---|---|---|---|
| Late Jan 2026 | OpenClaw (earlier names Clawdbot → Moltbot) goes viral; ~147k GitHub stars within weeks | First mass-market proof of a persistent, proactive personal agent | [7] |
| Jan–Feb 2026 | Moltbook — a social network for OpenClaw agents — spreads virally | Shows public fascination and the unpredictability of autonomous agents | [6][9] |
| Feb 2026 | Companies tell employees not to install OpenClaw; Meta and others ban it on corporate networks | Security/governance is the core barrier | [6][9] |
| Feb 15, 2026 | OpenAI hires creator Peter Steinberger to drive "next generation of personal agents"; OpenClaw moves to an independent open-source foundation | Big-tech validation of the always-on agent category | [8][9][10] |
| Feb–Mar 2026 | T-Mobile, Deutsche Telekom put AI agents *inside the network* (translation, call assistant) | Telcos begin claiming the "network-native agent" position | [27][30] |
| Sep–Oct 2026 | Consumer agents (Meta Muse, others) start calling/messaging companies for users; Amazon blocks Muse, PayPal opens checkout to it; eBay bans buy-for-me agents | "Agent economy" arrives; platforms pick sides | [11] |

### 3.2 What makes an "always-on" bot different

- **Persistence & memory:** runs continuously on its own machine with long-term memory, reminders and scheduled jobs, rather than a prompt–response cycle [5][6].
- **Proactivity:** does background work (cron jobs, daily briefings, monitoring email/notifications) [6][7].
- **Lives in messaging channels:** users talk to it through WhatsApp, Telegram, iMessage, Signal, Slack, etc. [7][9] — i.e., through the phone's messaging layer, which carriers sit next to.
- **Acts across a person's digital life:** email, calendar, files, browser, shell, home devices [7][10].
- Creator's thesis: personal agents could replace ~80% of phone apps [10].

### 3.3 Demand signals (Lorikeet survey, Sept 30–Oct 8, 2026, n=1,966 US) [11]

| Metric | Finding |
|---|---|
| Interested in an agent that deals with companies for them | **66%** |
| Say an AI tool has contacted a company itself for them | **≤6.3%** (≈1 in 16) |
| Comfortable letting an agent get a better price | **55.5%** (vs. 38.5% for bookings) |
| Early users who repeat the behaviour | **76%**; >1 in 4 weekly or daily |
| Jobs done | Returns, refunds, cancellations, claims, negotiating rates |
| Meta Muse scale | ~6.6M downloads, ~1.8M daily users (citing Reuters, Oct 6) |

*Note: panel is AI-literate; usage numbers are upper bounds.*

**Implication for telcos:** Carriers are *both* likely targets of negotiating agents (bill reviews, cancellations, retention offers) *and* well positioned to provide the trusted agent itself.

### 3.4 Barriers

- Security & safety of giving agents broad access [6][9].
- Platform hostility (blocking agents) [11].
- Consumer ambivalence — most interest is "somewhat"; only ~10% prefer an agent fully handle tasks today [11].

---

## 4. Track B — Chamberlain Group's myQ AI offering

### 4.1 Company context
- Blackstone portfolio company; brands LiftMaster and Chamberlain in **50+ million homes**; **14–15 million** people use the myQ app daily [12][16].
- Strategy: evolve from access hardware into a software- and AI-driven company (engineering across cloud, ML and AI within myQ) [15].

### 4.2 Product evolution (AI layer on access hardware)

| Date | Launch | AI element | Ref |
|---|---|---|---|
| 2023 | myQ Smart Garage Video Keypad | Edge-AI-ready camera at the garage | [P] [17b] |
| 2024 | myQ Smart Outdoor Camera + AI enhancements | Vehicle & animal detection for subscribers; "Smart Secure" auto-locks doors/closes garage when a person is detected | [14] |
| May 2025 | First myQ Video Doorbell + outdoor camera | Devices react to what they see (lock doors, close garage) | [13] |
| **Jan 6, 2026 (CES)** | **myQ Secure View 3-in-1 Smart Lock** (lock + 2K HDR video doorbell + camera; face, fingerprint, PIN, app, key) | myQ AI detects people, vehicles, animals, packages; fewer false alerts; auto lock/unlock based on approved vs. unknown person; unified garage + front door + perimeter in one app | [12][16][17] |
| Jul 2026 | myQ Connected Garage in Hyundai vehicles | Geofenced auto/prompted open-close; valet mode | [20b] |
| Oct 2026 | Certified integration with Josh.ai (pro smart-home) | Paid/certified partner access model | [19b] |

### 4.3 Business model
- Hardware + recurring subscription. Video AI processing (searchable recordings, AI features) is enabled with an active **myQ Video subscription** [P][16b].
- Partner program: third parties pay/certify for access; myQ blocked unauthorized API access in 2023 (Home Assistant integration removed) [18][19].
- Distribution: pro-installer channel (LiftMaster) plus retail; auto OEM integrations (Mercedes, VW, Hyundai) [S][20b].

### 4.4 Lessons for telcos
1. **Own a trusted "control point" and layer AI on it.** Chamberlain's hardware chokepoint is the garage door; a carrier's is the phone number, SIM/eSIM identity and the home gateway.
2. **AI value = cross-device orchestration**, not single-device detection: "person detected → lock front door → close garage" [12][14].
3. **Reward the existing base first.** The lock was offered exclusively to myQ users for a week before general availability [12][16].
4. **Avoid the backlash.** Reviewers flagged consumer skepticism over features moved behind paywalls and disabled third-party integrations [18]. A carrier should keep an open, partner-friendly agent platform.
5. **Partner, don't compete:** a carrier "Home Guardian" agent could *orchestrate* myQ, Ring, ADT, etc., and bill for it — the same role Hyundai and Josh.ai play for myQ.

---

## 5. Track C — What telecom operators are doing

### 5.1 United States

| Operator | AI initiative | Type | Monetized? | Ref |
|---|---|---|---|---|
| **Verizon** | Verizon Assistant in My Verizon app built with Google Gemini; handles upgrades, adding lines, billing, savings; small specialized models to limit hallucinations; hands off to human "Customer Champions" | Care/self-service | Indirect (churn, cost) | [21][22][23] |
| Verizon | Personal Research Assistant for ~28,000 reps; "Segment of Me" personalized offers; AI routing cut handle time by 2–4 min | Care/marketing | Indirect | [22][24] |
| Verizon | Google One AI Premium (Gemini) add-on at $10/mo on myPlan/myHome (Feb 2025) — first US carrier AI perk | Third-party bundle | Yes, add-on | [34][35] |
| **AT&T** | **Digital Receptionist** — network-based, voice-to-voice agentic AI that answers unknown callers, asks who/why, blocks spam, patches urgent calls, takes messages or delivery windows, live transcript, "Do Not Screen" list; piloted in North Texas | **New consumer agent** | TBD | [25][26][27b] |
| AT&T | Stated vision: future agent could book restaurant reservations or handle calls on your behalf via text instructions | Roadmap | — | [25] |
| AT&T | Enterprise agentic AI platform (reported H2O.ai "Super Agent") | Internal | Indirect | [S][29b] |
| **T-Mobile** | **Live Translation** — network-native, no app, any phone, 50+ languages, activated by dialing a code; beta for postpaid in 2026; uses multiple LLMs | New consumer service | Free beta | [27][28][28b] |
| T-Mobile | OpenAI partnership for intent-driven care platform | Care | Indirect | [29] |

*Analyst caution: Rethink argues T-Mobile's service is an AI overlay on IMS rather than true agentic AI [28c] — differentiation claims will be scrutinized.*

### 5.2 International benchmarks

| Operator | Initiative | Ref |
|---|---|---|
| Deutsche Telekom | **Magenta AI Call Assistant** (MWC 2026) — in-network AI on any phone: in-call agents, live translation, call summaries in Magenta app; built with ElevenLabs. Also the "AI Phone" with bundled Perplexity | [30][31][33] |
| SK Telecom | "A." (A-dot) personal assistant rebuilt on LLM agents; free access to multiple models (own A.X, ChatGPT, Claude, Perplexity) | [31b][31c] |
| DT, SKT, e&, Singtel | Global Telco AI Alliance; telco-specific LLM for assistants | [31d] |
| Airtel / Jio (India) | Perplexity Pro free to ~360M Airtel customers; Jio offers Gemini Pro for 18 months | [32b] |
| Circles.Life, giga! (Singapore) | AI-aggregator plans with multiple paid models from ~S$8/mo | [32c] |

**CCS Insight view:** Operators across markets are bundling premium AI (ChatGPT Plus, Perplexity Pro); Perplexity deals reach 250M+ subscribers, but take-up may be limited [32].

### 5.3 Pattern analysis
- **Bundles are a commodity race** — easy to copy, margin goes to the AI lab, and value disappears when the free period ends [32][33].
- **Network-native agents are the defensible play** — call screening, translation and call assistance work on any phone without an app, and require the carrier's network position [25][27][30].
- **US carriers have not yet launched a paid, always-on *personal* agent.** That gap is the core opportunity.

---

## 6. Opportunities for Verizon / AT&T

### 6.1 Carrier "right to win" assets
| Asset | Why it matters for always-on bots |
|---|---|
| Verified identity (phone number, SIM/eSIM, KYC) | Agents need a trusted identity to act for a user — and businesses need to verify agent contacts [11] |
| Voice & messaging network (IMS, RCS, SMS) | Agents live in messaging/voice; network-native means no app, any device [27][30] |
| Billing relationship (~100M+ accounts each) | One-click add-on monetization; family plans = household graph |
| Home broadband gateway (Fios / AT&T Fiber, FWA) | Natural hub for always-on home agents and device orchestration |
| 24/7 care + retail stores | Human backstop and setup help mainstream users need |
| Fraud/spam data (AT&T blocks/labels 2B+ robocalls/month) | Unique training data for protective agents [25] |
| Trust/regulation (CPNI, FCC) | A regulated party is a safer custodian than self-hosted bots [6] |

### 6.2 Opportunity portfolio

#### O1. AI Call Agent ("Receptionist+") — *Launch first*
- **What:** Expand call screening into a full always-on voice agent: screens calls, takes messages, confirms deliveries, books appointments, makes outbound calls on request (reservations, hold-waiting, rescheduling), live translation, call summaries.
- **Evidence:** AT&T pilot + stated roadmap [25][26]; T-Mobile translation demand (more day-one sign-ups than T-Satellite beta) [28b]; DT Magenta AI Call Assistant [30].
- **Model:** Free basic screening (retention); **Premium $5–8/line/mo** for outbound tasks, translation, summaries; family-plan bundles.
- **Moat:** Network-native, works on any phone including flip phones/seniors.

#### O2. "My Bills & Deals" Negotiator Agent
- **What:** Always-on agent that monitors the household's subscriptions, insurance, utilities and bills; negotiates rates, cancels unused services, files refunds/claims — with user approval.
- **Evidence:** Negotiation is the #1 task consumers will delegate (55.5%); real-world examples of insurance switching and airline credits [11]; Verizon already runs a "Savings Boost" tool [23].
- **Model:** Subscription ($5–10/mo) or share-of-savings; affiliate revenue from switching offers.
- **Caveat:** Should include the carrier's own bill to be credible (a feature, not a bug — reduces churn via transparency).

#### O3. Home Guardian Agent (Chamberlain playbook, carrier-scale)
- **What:** An always-on home agent running on the broadband gateway/cloud that orchestrates cameras, locks, garage doors (via myQ partnership), thermostats and Wi-Fi: "unknown person at door → lock front door, close garage, text me a clip", "kids home → notify parents", "garage left open at 10pm → close".
- **Evidence:** Chamberlain's cross-device AI orchestration and subscription model [12][14][16b]; certified-partner model (Josh.ai, Hyundai) shows myQ will partner [19b][20b].
- **Model:** $10–15/mo home tier bundled with fiber/FWA; partner hardware financing on the bill; revenue share with myQ/others.
- **Differentiator vs. Chamberlain/Ring:** brand-agnostic; carrier owns the gateway and 24/7 support.

#### O4. Family & Senior Safety Agent
- **What:** Always-on guardian for kids and aging parents: scam-call interception, suspicious-text explanation, daily check-in calls for seniors, medication reminders, location/geofence alerts, escalation to family.
- **Evidence:** Spam/fraud is escalating with AI-powered scammers [25]; network-native voice works on basic phones [27].
- **Model:** Add-on per line ($5–10) or premium family plan; partnerships with insurers/health plans.

#### O5. SMB AI Front Desk (business lines)
- **What:** Always-on agent attached to a small business's phone number: answers calls/texts 24/7, books appointments, takes orders, answers FAQs, follows up leads, and handles *incoming consumer agents* ("agent front door").
- **Evidence:** Businesses must prepare for customers arriving as agents and for money conversations (refunds, cancellations) [11].
- **Model:** $30–150/mo per location; usage tiers. Strong fit with Verizon Business / AT&T Business sales channels.

#### O6. Carrier Agent Identity & Trust Layer (platform/B2B2C)
- **What:** Use number verification and network APIs to certify that an AI agent is acting for a verified subscriber, with scoped permissions — "an agent can do what the customer could do, and nothing more" [11].
- **Evidence:** Platforms are blocking unverified agents (Amazon/Muse, eBay) [11]; enterprises banned unmanaged agents [9].
- **Model:** Per-verification API fees to merchants, banks, AI labs; positions carriers as infrastructure for the agent economy.

#### O7. Managed Personal Agent ("OpenClaw-as-a-service, safely")
- **What:** A hosted, sandboxed always-on assistant reachable by RCS/SMS/voice, with curated skills (calendar, email, briefings, reminders, shopping), powered by partner LLMs.
- **Evidence:** OpenClaw demand and its security issues [6][7][9]; SKT's multi-model "A." assistant [31c].
- **Model:** Tiered subscription; replaces commoditized "free ChatGPT/Gemini" bundles with a carrier-owned experience.
- **Risk:** Direct competition with OpenAI/Google/Meta personal agents — better to partner and white-label than build models.

### 6.3 Prioritization matrix (analyst judgment)

| # | Opportunity | Customer demand | Carrier advantage | Time to market | Revenue potential | Risk | Priority |
|---|---|---|---|---|---|---|---|
| O1 | AI Call Agent | High | **Very high** | Short (AT&T pilot exists) | Med–High | Low–Med | **1** |
| O4 | Family & Senior Safety | High | High | Short | Medium | Low | **2** |
| O3 | Home Guardian | Medium–High | High (gateway) | Medium (partners) | High | Medium | **3** |
| O2 | Bills & Deals Negotiator | High | Medium | Medium | Medium | Med (regulatory, self-cannibalization) | 4 |
| O5 | SMB AI Front Desk | High | High (B2B channel) | Short–Medium | High | Medium (crowded market) | 4 |
| O6 | Agent Identity & Trust | Emerging | **Very high** | Long (ecosystem) | High (platform) | High | Strategic bet |
| O7 | Managed Personal Agent | Medium | Medium | Medium | Medium | High (big-tech competition) | Partner-led |

### 6.4 Suggested product architecture
```
            ┌───────────────────────────────────────────┐
            │  Carrier Personal Agent Platform           │
            │  (identity • consent • memory • billing)   │
            └───────┬───────────┬───────────┬───────────┘
                    │           │           │
       Voice/IMS agent    RCS/SMS agent   Home gateway agent
       (calls, translate) (chat, tasks)   (devices, security)
                    │           │           │
            Partner LLMs (Gemini, OpenAI, Anthropic, etc.) + skills
                    │
       Partner ecosystem: myQ/Chamberlain, Ring, ADT, insurers,
       banks, merchants, OTT, healthcare
```

### 6.5 Go-to-market ideas
- **Seed the base first** (Chamberlain-style early access for existing customers) [12].
- **Free tier for protection, paid tier for action** — protective features build trust; delegated actions are the upsell.
- **Bundle into premium plans** (Verizon myPlan perks, AT&T Unlimited Premium) and fiber/FWA home tiers.
- **Retail-store onboarding** for seniors/families; human backstop as a differentiator vs. self-hosted bots.
- **Partner with Chamberlain myQ** for a co-branded Home Guardian pilot in high-garage-penetration suburbs (e.g., Dallas–Fort Worth, where AT&T already pilots the Digital Receptionist [26]).

---

## 7. Risks & mitigations

| Risk | Mitigation |
|---|---|
| Agent errors / hallucinations with real-world consequences | Small specialized models + human handoff (Verizon approach) [21]; approval gates for payments/commitments |
| Privacy & regulation (call recording/consent laws, CPNI, FCC) | Opt-in, transparent disclosure to callers, data minimization, on-network processing [26] |
| Security of always-on agents | Sandboxing, scoped permissions, audit trails — the opposite of unmanaged self-hosted bots [6][9] |
| Competition from OpenAI/Google/Meta/Apple personal agents and on-device call screening | Compete on network-native, any-device, identity and human support; partner on models |
| Cannibalization (negotiator agents lowering carrier ARPU) | Position as trust/loyalty driver; offset with add-on revenue |
| Paywall backlash (Chamberlain lesson) | Never remove existing free features; clear tiering; open partner APIs [18] |
| Low take-up (as with AI bundles) | Lead with tangible, everyday value (spam, safety, home) rather than generic chatbots [32] |

---

## 8. Recommended next steps
1. Validate demand: conjoint/pricing survey with 2–3k subscribers on O1, O3, O4 bundles.
2. Pilot O1 + O4 together as a "Protect & Assist" add-on in one metro.
3. Open partnership talks with Chamberlain (myQ) and a security provider for an O3 pilot on fiber/FWA customers.
4. Stand up an "agent front door" for the carrier's own care channels (be ready for customers' negotiating agents) [11].
5. Engage standards/industry groups on an agent identity framework (O6) using network APIs.

---

## 9. References

**Track A — Always-on bots**
- [5] Dan Unogwu (LinkedIn post reshared widely), OpenClaw personal agent experience — https://ca.linkedin.com/in/unogwudan [S]
- [6] G2 Learn, "OpenClaw and Moltbook explained" (Feb 2026) — https://learn.g2.com/openclaw-and-moltbook-explained [T]
- [7] Decrypt via MEXC, "OpenClaw Opens the Gates for AI Agents — What's Real and What's Not" — https://www.mexc.com/it-IT/news/620198 [T]
- [7b] AI Agents Simplified, "OpenClaw Unpacked" — https://aiagentssimplified.substack.com/p/openclaw-unpacked [S]
- [8] Bloomberg, "OpenAI Hires OpenClaw AI Agent Developer Steinberger" (Feb 15, 2026) — https://www.bloomberg.com/news/articles/2026-02-15/openai-hires-openclaw-ai-agent-developer-peter-steinberg [T]
- [9] Pure AI, "OpenAI Hires OpenClaw Founder as Agentic AI Debate Intensifies" (Feb 17, 2026) — https://pureai.com/articles/2026/02/17/openai-hires-openclaw-founder-as-agentic-ai-debate-intensifies.aspx [T]
- [10] The Neuron, "OpenAI Hires OpenClaw Creator to Build Next-Gen Personal AI" — https://www.theneuron.ai/explainer-articles/openai-hires-openclaw-peter-steinberger-personal-agents/ [T]
- [10b] Tom's Guide, "OpenAI hires the developer behind OpenClaw" — https://tomsguide.com/ai/openai-hires-the-developer-behind-openclaw-this-is-how-ai-agents-grow-up [T]
- [11] Lorikeet, "The Agent Economy: How Consumers Actually Use AI Agents" (survey of 1,966 US consumers, Oct 2026) — https://www.lorikeetcx.ai/content/the-agent-economy/read [T]

**Track B — Chamberlain / myQ**
- [12] Chamberlain Group press release, "Redefines Smart Home Security with Launch of myQ Secure View 3-in-1 Smart Lock" (Jan 6, 2026) — https://www.chamberlaingroup.com/press/chamberlain-group-redefines-smart-home-security-with-launch-of-myq-secure-view-3-in-1-smart-lock [P]
- [13] CE Pro, "myQ Gets Its First Ever Video Doorbell" (May 2025) — https://www.cepro.com/briefs/myq-gets-its-first-ever-video-doorbell-for-access-control-platform/618868 [T]
- [14] Chamberlain Group, "myQ Expands Smart Access Ecosystem with First Smart Outdoor Camera and Advanced AI Features" — https://www.chamberlaingroup.com/press/myq-expands-smart-access-ecosystem-with-launch-of-first-smart-outdoor-camera-and-advanced-ai-features [P]
- [15] Built In Chicago, Chamberlain "Software Product Manager, myQ App" posting (Aug 2026) — https://www.builtinchicago.org/job/software-product-manager/9738472 [P]
- [16] CE Pro, "Chamberlain Group Expands Beyond the Garage with myQ Secure View" (Jan 2026) — https://www.cepro.com/news/chamberlain-group-expands-beyond-the-garage-with-myq-secure-view-3-in-1-smart-lock/624485 [T]
- [16b] Chamberlain support, "myQ Video AI Processing" — https://support.chamberlaingroup.com/s/article/myQ-Video-AI-Processing-Enable-or-Disable [P]
- [17] WiFi HiFi, "CES 2026: myQ Secure View is a Smart Lock, Doorbell & Camera in One" — https://wifihifi.com/ces-2026-myq-secure-view-smart-lock-doorbell-camera/ [T]
- [17b] Security Sales & Integration, "Chamberlain Group Launches myQ Smart Garage Video Keypad" — https://www.securitysales.com/news/myq-smart-garage-video-keypad/151765/ [T]
- [17c] SecurityInfoWatch, "Chamberlain Group Brings Biometric Intelligence to the Front Door" — https://www.securityinfowatch.com/ces-show/news/55341281/ [T]
- [18] PCWorld, coverage of Chamberlain's first smart lock and subscription criticism — https://www.pcworld.com/article/3021418 [T]
- [19] Home Assistant blog, "Removal of MyQ integration" (Nov 2023) — https://www.home-assistant.io/blog/2023/11/06/removal-of-myq-integration/ [P]
- [19b] Quest Review Center, "Josh.ai widens smart home reach with myQ…" (Oct 2026) — https://questreviewcenter.com/smart-home-tech/josh-ai-widens-smart-home-reach-with-myq-powershades-and-sonos-amp-multi-support [T]
- [20b] PR Newswire, "Hyundai Motor America and Chamberlain Group Bring myQ Connected Garage to Hyundai Vehicles" (Jul 8, 2026) — https://www.prnewswire.com/news-releases/hyundai-motor-america-and-chamberlain-group-bring-myq-connected-garage-technology-to-hyundai-vehicles-302820311.html [P]
- [20c] Altss profile, Chamberlain business model (hardware + subscriptions, dealer channel) — https://altss.com/profile/the-chamberlain-group [S]

**Track C — Telecom operators**
- [21] CO/AI, "Verizon launches Gemini-powered AI customer service" — https://getcoai.com/news/can-you-satisfy-my-query-now-verizon-launches-gemini-powered-ai-customer-service-with-90-accuracy/ [T]
- [22] CX Today, "Verizon Teams Up with Google to Give 28,000 Customer Support Reps a Personal Research Assistant" — https://www.cxtoday.com/contact-center/verizon-teams-up-with-google-to-give-28000-customer-support-reps-a-personal-research-assistant/ [T]
- [23] CXM World, "Verizon Assigns Dedicated Experts Until Problems Are Fixed" — https://cxm.world/customer-experience/verizon-assigns-dedicated-experts-until-problems-are-fixed/ [T]
- [23b] PhoneArena, "Verizon … unveils Project 624" — https://www.phonearena.com/news/Verizon-reasserts-dominance-over-T-Mobile-and-unveils-Project-624-to-keep-customers-happy_id171638 [T]
- [24] Telecoms.com, "Verizon using generative AI to do customer service better" — https://www.telecoms.com/ai/verizon-using-generative-ai-to-do-customer-service-better [T]
- [25] AT&T blog (Andy Markus), "Tired of Screening Spam Calls? An AI Digital Receptionist Could Do It for You" (Sep 16, 2025) — https://www.att.com/es-us/sdabout/blogs/2025/ai-digital-receptionist.html [P]
- [26] Dallas Innovates, "AT&T Is Testing an AI 'Digital Receptionist' With Select North Texas Customers" — https://dallasinnovates.com/personal-call-screening-att-is-testing-an-ai-digital-receptionist-with-select-north-texas-customers/ [T]
- [27b] Mobile World Live, AT&T digital receptionist coverage — https://www.mobileworldlive.com/?p=444480 [T]
- [27] TYN Magazine / Mobile World Live, "T-Mobile US claims world-first with agentic AI platform" (Feb 2026) — https://tynmagazine.com/t-mobile-us-claims-world-first-with-agentic-ai-platform/ [T]
- [28] IEEE ComSoc Techblog, "T-Mobile US … 5G-A with agentic AI and live voice call translation" (Feb 11, 2026) — https://techblog.comsoc.org/2026/02/11/t-mobile-us-announces-new-broadband-targets-5g-a-with-agentic-ai-and-live-voice-call-translation [T]
- [28b] Mobile World Live via esrot, "T-Mobile US readies AI Live Translation trial" (Apr 9, 2026) — https://esrot.com/news/t-mobile-us-readies-ai-live-translation-trial [T]
- [28c] Rethink Research, "T-Mobile offers tempting morsel, it's not agentic AI though" — https://rethinkresearch.biz/articles/t-mobile-offers-tempting-morsel-its-not-agentic-ai-though/ [T]
- [29] Nasdaq/Zacks, "T Integrates AI to Enhance Client Service" — https://www.nasdaq.com/articles/t-integrates-ai-enhance-client-service-will-it-boost-user-growth [T]
- [29b] AT&T job-posting summaries citing H2O AI Super Agent deployment (unverified) — https://simplify.jobs/p/98969d07-3c9c-4636-8b86-844204ec2b21/Retail-Sales-Consultant [S]
- [30] ElevenLabs/Deutsche Telekom partnership post (Magenta AI Call Assistant, MWC 2026) — https://ar.linkedin.com/in/esteban-cataldi-5092192a [S]
- [31] Deutsche Telekom, "AI agents: The AI revolution takes off" — https://www.telekom.com/en/blog/group/article/ai-agents-the-ai-revolution-takes-off-1095226 [P]
- [31b] RCR Wireless, "SK Telecom fully revamps its AI personal assistant" — https://rcrwireless.com/20240826/featured/sk-telekom-fully-revamps-ai-personal-assistant [T]
- [31c] Verdict, SK Telecom A. multi-model access — https://www.verdict.co.uk/sk-telecom-ai-samples/ [T]
- [31d] Deutsche Telekom newsroom, "SK Telecom and Deutsche Telekom develop LLM for telcos" — https://www.telekom.com/en/newsroom/latest-updates/media-information/2023/10/sk-telecom-and-deutsche-telekom-develop-llm-for-telcos [P]
- [32] CCS Insight, "Operators Jump on the Premium Generative AI Bandwagon" (Feb 2026) — https://www.ccsinsight.com/?p=41270 [T]
- [32b] Voice&Data, "Airtel and Jio drive new era of AI-powered services in telecom" — https://www.voicendata.com/telecom/airtel-and-jio-drive-new-era-of-ai-powered-services-in-telecom-10806113 [T]
- [32c] The Straits Times (via Magzter), "Virtual telcos bundle mobile plans with access to AI models" (Jul 2026) — https://www.magzter.com/stories/newspaper/The-Straits-Times/VIRTUAL-TELCOS-BUNDLE-MOBILE-PLANS-WITH-ACCESS-TO-AI-MODELS-FOR-AS-LOW-AS-8-A-MONTH [T]
- [33] Global Brands Magazine, "Free AI Subscriptions Became a Business. Now the First Bills Land" (Aug 2026) — https://www.globalbrandsmagazine.com/?p=123779 [T]
- [34] GSMArena, "Verizon will give you Google's premium AI subscription for half the price" — https://m.gsmarena.com/verizon_will_give_you_googles_premium_ai_subscription_for_half_the_price-news-66385.php [T]
- [35] GadgetBond, "Verizon Google One AI Premium bundle" — https://gadgetbond.com/verizon-google-one-ai-premium-bundle-availability/ [T]

---
*Pricing ranges and prioritization scores in §6 are analyst estimates for discussion, not sourced figures.*
