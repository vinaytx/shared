# Genie x Gemini autonomous analysis agents

Goal-driven multi-agent system (Google ADK + Gemini) that investigates network
element performance KPIs against configuration data held in Databricks, using
**a manually logged-in Chrome session** as the only channel to Databricks Genie.

```
agents/agent.py          root_agent = LoopAgent(goal_orchestrator)
agents/specialists.py    schema_agent, sql_agent, analysis_agent
tools/data_tools.py      ask_genie, run_sql, get_schema, sample_table  (ADK tools)
tools/analysis_tools.py  correlate_kpi_with_config, before_after_change, describe_result
tools/control_tools.py   set_plan, record_hypothesis, record_finding, checkpoint, finish_goal
browser/genie_driver.py  Genie/SQL calls via fetch() in the logged-in tab (no LLM)
browser/session.py       login-expiry detection, pause/resume, notifications
browser/chrome.py        one direct CDP connection to the attended Chrome (Playwright)
scripts/start_chrome.*   launch the agent Chrome with the debug port
scripts/check_browser.py step-by-step connection check + test messages
config/settings.yaml     all knobs
main.py                  CLI runner
```

## 1. One-time setup

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

### Google authentication (same method as Gemini CLI: sign in with your Google account)

Gemini CLI keeps its OAuth tokens in `~/.gemini/oauth_creds.json`. The Google
SDKs used by ADK keep theirs in the equivalent *Application Default
Credentials* file, created by:

```bash
gcloud auth application-default login      # opens a browser, sign in with your Google account
gcloud services enable aiplatform.googleapis.com --project <your-project>
```

Then in `config/settings.yaml` set `auth.method: google_oauth` (default) and
`auth.gcp_project` to a Google Cloud project you own (the Gemini calls are
billed/quota'd through Vertex AI in that project). `config/auth.py` verifies
and refreshes the credentials at startup and tells you exactly what to do if
they are missing or revoked. For an unattended VM use a service account: set
`auth.service_account_file`.

If you prefer an AI Studio key instead, set `auth.method: api_key` and put
`GOOGLE_API_KEY` in `.env`.

Also edit in `config/settings.yaml`: workspace URL, Genie space id, SQL
warehouse id, catalog/schema of the config + KPI tables.

## 2. Browser: start Chrome, log in, send a test message

The agents talk to **one** Chrome that you start and log into. The connection is a
single Chrome DevTools websocket (Playwright `connect_over_cdp`); nothing else is
spawned. Your everyday Chrome can stay open; the agent Chrome uses its own profile.

```
scripts\start_chrome.bat https://<your-workspace>.cloud.databricks.com     (Windows)
scripts/start_chrome.sh  https://<your-workspace>.cloud.databricks.com      (macOS/Linux)
```
The script prints the JSON from `http://127.0.0.1:9222/json/version` when the debug
port is up. **Log in to Databricks in that new window.** Then check each step:

```
python scripts\check_browser.py
[1] PASS  config/settings.yaml has a real workspace_url
[2] PASS  Chrome DevTools port reachable  -> Chrome/146.0.x at http://127.0.0.1:9222
[3] PASS  Databricks tab available        -> https://<ws>/...
[4] PASS  Logged in to Databricks         -> you@company.com
```
Send test messages to the Databricks window:
```
python scripts\check_browser.py --sql "SELECT current_user(), now()"
python scripts\check_browser.py --ask "How many tables are in the space?"
```
Each failing step prints the fix. Common ones:

| symptom | cause / fix |
|---|---|
| step 2 FAIL, `curl http://127.0.0.1:9222/json/version` fails | Chrome was launched without the flags or the port is taken. Run the script again; if a stale agent Chrome exists, close it first (`taskkill /F /FI "WINDOWTITLE eq *genie-agent*"` or via Task Manager). |
| a *second* agent window appears | You ran the script twice. It is harmless; Chrome reuses the same profile/port. Close the extra window. |
| step 4 FAIL with HTTP 401/403 while the UI works | The SSO cookie is not sent to `/api/...`. Open DevTools > Network on any Genie request the UI makes, copy its custom headers into `databricks.extra_headers`. |
| `--ask` times out | Open the Genie space once in the agent Chrome, confirm `genie_space_id` from its URL. |

To use your everyday Chrome instead of a separate one (Chrome 145+): open
`chrome://inspect/#remote-debugging`, enable it, and Chrome will offer a port; put that
URL in `browser.devtools_url`. Approve the consent prompt on first connection.

## 3. Run a goal

```bash
python main.py "Which configuration parameters are associated with low downlink throughput on LTE cells in region North over the last 7 days?"
```

Output streams each agent's turn; a JSON report lands in `state/checkpoints/<goal_id>-report.json`
and every Genie/SQL call is written to `state/audit/` (question, SQL, rows, error, Genie URL).

Or use the ADK dev UI for interactive debugging: `adk web` (select `agents`).

## 4. When the login expires

Before every call the driver asks Databricks `/scim/v2/Me` through the tab. On 401/403
it writes `state/NEEDS_LOGIN`, posts to `notify.webhook_url` if set, and waits. Log in
again in the agent Chrome window; the probe succeeds within ~15 s and the run resumes.
Progress is checkpointed after every orchestrator turn, so you can also kill the process
and `python main.py --resume <goal_id>`.

## 5. How Databricks is reached

All calls are `fetch()` executed inside the Databricks tab against
`/api/2.0/genie/...` (Genie Conversation API) and `/api/2.0/sql/statements`
(Statement Execution API), reusing the tab's login cookies. No UI clicking, no
DOM scraping, and the code is one file: `browser/genie_driver.py`. Because the
tab is the only credential holder, nothing in this project ever sees a password
or token.

## 6. Hardening checklist before trusting results

- Run `ask_genie` 50x on one known question; fix every failure in the driver first.
- Build an ADK eval set: `adk eval agents tests/goals.evalset.json` with 20-30
  goal → expected-finding pairs from past incidents.
- Curate the Genie space (instructions, example SQL, joins). Genie quality bounds
  the whole system.
- Keep `run.max_queries_per_goal` low until the SQL agent's queries are consistently sane.

## 7. Swapping in the real API later

`browser/genie_driver.py` is the only module that knows about Chrome. If you
get a PAT or the managed MCP server later, reimplement `ask_genie`, `run_sql`
and `fetch_schema` with the Databricks SDK; nothing above it changes.
