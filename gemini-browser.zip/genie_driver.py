"""
Genie / SQL driver over the logged-in Chrome tab. No LLM, no UI scraping.

    ask_genie(question, conversation_id=None) -> GenieResult
    run_sql(statement)                        -> SqlResult
    fetch_schema(catalog, schema)             -> list[dict]
    health_check()                            -> dict

Every call is a REST request executed by fetch() inside the Databricks tab, so
it reuses your login. Every call is written to state/audit/ for replay.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from browser.chrome import Chrome
from browser.session import SessionExpired, ensure_logged_in, probe_session
from config import settings

log = logging.getLogger(__name__)
_cfg = settings()
AUDIT = Path(_cfg["run"]["checkpoint_dir"]).parent / "audit"
AUDIT.mkdir(parents=True, exist_ok=True)


@dataclass
class GenieResult:
    ok: bool
    question: str
    conversation_id: str | None = None
    message_id: str | None = None
    answer_text: str = ""
    sql: str = ""
    columns: list[str] = field(default_factory=list)
    rows: list[list[Any]] = field(default_factory=list)
    row_count: int = 0
    truncated: bool = False
    status: str = ""
    error: str = ""
    url: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class SqlResult:
    ok: bool
    statement: str
    columns: list[str] = field(default_factory=list)
    rows: list[list[Any]] = field(default_factory=list)
    row_count: int = 0
    truncated: bool = False
    error: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def _audit(kind: str, payload: dict) -> None:
    (AUDIT / f"{time.strftime('%Y%m%d-%H%M%S')}-{kind}.json").write_text(
        json.dumps(payload, indent=2, default=str))


async def _api(method: str, path: str, body: dict | None = None) -> dict:
    status, data = await Chrome.get().api(method, path, body)
    if status in (401, 403):
        raise SessionExpired(f"HTTP {status} on {path}")
    if status >= 400:
        raise RuntimeError(f"HTTP {status} on {path}: {str(data)[:500]}")
    return data if isinstance(data, dict) else {}


def _cap(rows: list) -> tuple[list, bool]:
    n = _cfg["run"]["max_rows_returned"]
    return (rows[:n], True) if len(rows) > n else (rows, False)


def _parse_statement(sr: dict) -> tuple[list[str], list, int, bool]:
    cols = [c["name"] for c in sr.get("manifest", {}).get("schema", {}).get("columns", [])]
    rows, trunc = _cap(sr.get("result", {}).get("data_array", []))
    total = sr.get("manifest", {}).get("total_row_count", len(rows))
    return cols, rows, total, trunc or bool(sr.get("manifest", {}).get("truncated"))


async def health_check() -> dict:
    return await probe_session()


# ----------------------------------------------------------------- Genie
async def _ask(question: str, conversation_id: str | None) -> GenieResult:
    sid = _cfg["databricks"]["genie_space_id"]
    base = f"/api/2.0/genie/spaces/{sid}"
    if conversation_id:
        msg = await _api("POST", f"{base}/conversations/{conversation_id}/messages", {"content": question})
    else:
        msg = await _api("POST", f"{base}/start-conversation", {"content": question})
        conversation_id = msg.get("conversation_id") or msg.get("conversation", {}).get("id")
    message_id = msg.get("message_id") or msg.get("id") or msg.get("message", {}).get("id")
    res = GenieResult(ok=False, question=question, conversation_id=conversation_id, message_id=message_id,
                      url=f"{_cfg['databricks']['workspace_url']}/genie/rooms/{sid}/chats/{conversation_id}")

    deadline = time.time() + _cfg["browser"]["genie_timeout_s"]
    while time.time() < deadline:
        m = await _api("GET", f"{base}/conversations/{conversation_id}/messages/{message_id}")
        res.status = m.get("status", "")
        if res.status == "COMPLETED":
            break
        if res.status in ("FAILED", "CANCELLED", "QUERY_RESULT_EXPIRED"):
            err = m.get("error")
            res.error = err.get("error", res.status) if isinstance(err, dict) else res.status
            return res
        await asyncio.sleep(_cfg["browser"]["poll_interval_s"])
    else:
        res.error = "timeout waiting for Genie"
        return res

    for att in m.get("attachments", []):
        if "text" in att:
            res.answer_text += att["text"].get("content", "")
        if "query" in att:
            q = att["query"]
            res.sql = q.get("query", "")
            if q.get("description"):
                res.answer_text += ("\n" if res.answer_text else "") + q["description"]
            if att.get("attachment_id"):
                qr = await _api("GET", f"{base}/conversations/{conversation_id}/messages/{message_id}"
                                       f"/attachments/{att['attachment_id']}/query-result")
                res.columns, res.rows, res.row_count, res.truncated = _parse_statement(
                    qr.get("statement_response", {}))
    res.ok = True
    return res


async def ask_genie(question: str, conversation_id: str | None = None) -> GenieResult:
    chrome = Chrome.get()
    async with chrome.lock:
        await ensure_logged_in()
        try:
            res = await _ask(question, conversation_id)
        except SessionExpired:
            await ensure_logged_in()
            res = await _ask(question, conversation_id)
        except Exception as exc:  # noqa: BLE001
            log.exception("ask_genie failed")
            shot = str(AUDIT / f"{time.strftime('%Y%m%d-%H%M%S')}-genie-error.png")
            try:
                await chrome.screenshot(shot)
            except Exception:  # noqa: BLE001
                shot = ""
            res = GenieResult(ok=False, question=question, error=str(exc))
            _audit("genie-error", {**res.to_dict(), "screenshot": shot})
            return res
    _audit("genie", res.to_dict())
    return res


# ------------------------------------------------------------------- SQL
async def run_sql(statement: str) -> SqlResult:
    chrome = Chrome.get()
    async with chrome.lock:
        await ensure_logged_in()
        try:
            resp = await _api("POST", "/api/2.0/sql/statements", {
                "warehouse_id": _cfg["databricks"]["sql_warehouse_id"], "statement": statement,
                "wait_timeout": "50s", "on_wait_timeout": "CONTINUE", "disposition": "INLINE",
                "format": "JSON_ARRAY", "row_limit": _cfg["run"]["max_rows_returned"]})
            deadline = time.time() + _cfg["browser"]["sql_timeout_s"]
            while resp.get("status", {}).get("state") in ("PENDING", "RUNNING") and time.time() < deadline:
                await asyncio.sleep(_cfg["browser"]["poll_interval_s"])
                resp = await _api("GET", f"/api/2.0/sql/statements/{resp['statement_id']}")
            state = resp.get("status", {}).get("state")
            if state != "SUCCEEDED":
                err = resp.get("status", {}).get("error", {}).get("message", state)
                res = SqlResult(ok=False, statement=statement, error=str(err))
            else:
                cols, rows, total, trunc = _parse_statement(resp)
                res = SqlResult(ok=True, statement=statement, columns=cols, rows=rows,
                                row_count=total, truncated=trunc)
        except Exception as exc:  # noqa: BLE001
            log.exception("run_sql failed")
            res = SqlResult(ok=False, statement=statement, error=str(exc))
    _audit("sql", res.to_dict())
    return res


async def fetch_schema(catalog: str, schema: str) -> list[dict]:
    res = await run_sql(f"""
    SELECT c.table_name, c.column_name, c.data_type, c.comment AS column_comment,
           t.comment AS table_comment, t.table_type
    FROM {catalog}.information_schema.columns c
    JOIN {catalog}.information_schema.tables t
      ON t.table_schema = c.table_schema AND t.table_name = c.table_name
    WHERE c.table_schema = '{schema}'
    ORDER BY c.table_name, c.ordinal_position""")
    if not res.ok:
        raise RuntimeError(res.error)
    return [dict(zip(res.columns, r)) for r in res.rows]
