"""
Login state of the attended Chrome.

probe_session()     -> dict(logged_in, email, error)
ensure_logged_in()  -> blocks until logged in; writes/clears state/NEEDS_LOGIN and notifies
"""
from __future__ import annotations

import asyncio
import logging
import time
from pathlib import Path

import requests

from browser.chrome import Chrome, ChromeNotRunning
from config import settings

log = logging.getLogger(__name__)


class SessionExpired(Exception):
    pass


def _flag() -> Path:
    return Path(settings()["run"]["needs_login_flag"])


def needs_login() -> bool:
    return _flag().exists()


def notify(text: str) -> None:
    log.warning("NOTIFY: %s", text)
    url = settings()["notify"].get("webhook_url")
    if url:
        try:
            requests.post(url, json={"text": text}, timeout=10)
        except Exception as exc:  # noqa: BLE001
            log.error("notify failed: %s", exc)


async def probe_session() -> dict:
    """Ask Databricks who we are, using the tab's cookies."""
    try:
        chrome = Chrome.get()
        tab = await chrome.current_tab()
        status, body = await chrome.api("GET", "/api/2.0/preview/scim/v2/Me")
    except ChromeNotRunning as exc:
        return {"logged_in": False, "email": None, "error": str(exc)}
    except Exception as exc:  # noqa: BLE001
        return {"logged_in": False, "email": None, "error": f"probe failed: {exc}"}
    if status == 200 and isinstance(body, dict):
        return {"logged_in": True, "email": body.get("userName"), "error": None, "tab": tab}
    return {"logged_in": False, "email": None, "error": f"HTTP {status} (not logged in?)", "tab": tab}


async def ensure_logged_in() -> None:
    p = await probe_session()
    if p["logged_in"]:
        _flag().unlink(missing_ok=True)
        return
    _flag().write_text(str(time.time()))
    notify(f"Genie agents paused: {p['error']}. Log in to Databricks in the agent Chrome window.")
    while True:
        await asyncio.sleep(15)
        p = await probe_session()
        if p["logged_in"]:
            _flag().unlink(missing_ok=True)
            notify(f"Genie agents resumed as {p['email']}.")
            return
