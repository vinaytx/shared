@echo off
REM Starts a SEPARATE Chrome instance for the agents (own profile, debug port 9222).
REM Your everyday Chrome can stay open; this one is independent.
set PROFILE=%USERPROFILE%\.genie-agent-chrome
set CHROME="C:\Program Files\Google\Chrome\Application\chrome.exe"
if not exist %CHROME% set CHROME="C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"

echo Starting agent Chrome with profile %PROFILE% on port 9222 ...
start "" %CHROME% --remote-debugging-port=9222 --user-data-dir="%PROFILE%" --no-first-run --new-window "%~1"
timeout /t 3 >nul
curl -s http://127.0.0.1:9222/json/version && echo. && echo Debug port OK. Now log in to Databricks in the new window. || echo FAILED: port 9222 not listening. See README section "Browser".
