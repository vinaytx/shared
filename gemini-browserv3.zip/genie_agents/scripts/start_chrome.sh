#!/usr/bin/env bash
# macOS/Linux equivalent of start_chrome.bat
PROFILE="$HOME/.genie-agent-chrome"
if [[ "$OSTYPE" == darwin* ]]; then CHROME="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"; else CHROME="google-chrome"; fi
"$CHROME" --remote-debugging-port=9222 --user-data-dir="$PROFILE" --no-first-run --new-window "${1:-about:blank}" >/dev/null 2>&1 &
sleep 3
curl -s http://127.0.0.1:9222/json/version && echo && echo "Debug port OK. Log in to Databricks in the new window." || echo "FAILED: port 9222 not listening."
