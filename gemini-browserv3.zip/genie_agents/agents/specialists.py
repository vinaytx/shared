"""Specialist ADK agents. Each is a focused LlmAgent exposed to the orchestrator as a tool."""
from __future__ import annotations

from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool

from config import settings
from tools import analysis_tools, data_tools

_m = settings()["models"]
_db = settings()["databricks"]

# --------------------------------------------------------------------------
schema_agent = LlmAgent(
    name="schema_agent",
    model=_m["specialist"],
    description="Explains which tables and columns exist for network element config and KPIs, "
                "how they join, and what each column means.",
    instruction=f"""
You are a data catalog expert for the Databricks schema `{_db['catalog']}.{_db['schema']}`.

Given a question from the orchestrator, do the following:
1. Call get_schema (use refresh=false unless told the schema changed).
2. Identify the tables relevant to the question: config/parameter tables, KPI/performance
   tables, and dimension tables (network element, cell, site, region, time).
3. Determine join keys (element id, cell id, timestamp/date). Call sample_table on at most
   3 tables if column semantics are unclear.
4. Reply with a compact SCHEMA CARD in this exact format:

TABLES
- <fully qualified table>: <one-line purpose>; grain=<one row per ...>; keys=<...>
COLUMNS OF INTEREST
- <table>.<column> (<type>): <meaning / units / value range if known>
JOINS
- <table a>.<col> = <table b>.<col>
CAVEATS
- <nulls, sparse periods, naming quirks>

Be precise. Never invent columns that are not in get_schema output.
""",
    tools=[FunctionTool(data_tools.get_schema), FunctionTool(data_tools.sample_table)],
    output_key="schema_card",
)

# --------------------------------------------------------------------------
sql_agent = LlmAgent(
    name="sql_agent",
    model=_m["specialist"],
    description="Turns an analytical question into data: either asks Genie or writes and runs "
                "aggregated SQL. Returns columns/rows plus the SQL used.",
    instruction=f"""
You retrieve data from Databricks for a network performance investigation.
Schema context (from the schema agent, may be empty): {{schema_card?}}

Choose the retrieval path:
- Use ask_genie when the request is a plain business question that the curated Genie space
  can answer (e.g. "average throughput per region last week"). Pass follow_up=true when the
  request refines the previous question. Always report the SQL Genie generated.
- Use run_sql when the request needs precise control: window functions, joins between
  config and KPI tables, before/after comparisons, percentiles, or more than ~1000 rows of
  aggregated output.

Rules for run_sql:
1. Always aggregate. Never return raw per-sample KPI rows; return one row per element (or
   per element-day) with aggregates (avg, p50, p95, count).
2. First call run_sql with dry_run=true. If it succeeds, run the full statement.
3. Use fully-qualified table names `{_db['catalog']}.{_db['schema']}.<table>`.
4. Keep result sets under {settings()['run']['max_rows_returned']} rows; use GROUP BY and
   WHERE time filters.
5. If a query fails, read the error, fix the SQL once, and retry. If it fails again, report
   the error instead of guessing.
6. If a tool returns status "needs_login", stop and report that a human must log in.

Respond with:
RESULT_SUMMARY: <one paragraph: what the data shows, row count, any truncation>
SQL: <the exact statement that produced the data>
COLUMNS: <json list>
ROWS: <json list of lists, exactly as returned>
""",
    tools=[FunctionTool(data_tools.ask_genie), FunctionTool(data_tools.run_sql),
           FunctionTool(data_tools.get_schema)],
    output_key="last_sql_result",
)

# --------------------------------------------------------------------------
analysis_agent = LlmAgent(
    name="analysis_agent",
    model=_m["analysis"],
    description="Statistically correlates performance KPIs with configuration parameters and "
                "returns ranked, evidence-backed conclusions.",
    instruction="""
You are a network performance analyst. You receive query results (COLUMNS + ROWS) and a
question, and you must produce evidence-backed conclusions using the tools, not intuition.

Approach:
1. Call describe_result to sanity-check the data (sample size, nulls, outliers).
2. For "which config parameters affect KPI X": call correlate_kpi_with_config with the KPI
   column and every candidate config column. Read the ranked output.
3. For "did change Y hurt/help KPI X": call before_after_change.
4. Treat p_value < 0.01 with a meaningful effect size as "supported"; p < 0.05 as "weak";
   otherwise "not supported". Sample size matters: fewer than 30 elements is low confidence.
5. State confounders you cannot rule out (e.g. parameter correlates with site type or traffic).

Respond with:
CONCLUSIONS
- <parameter or change>: <supported/weak/not supported>; effect=<...>; p=<...>; n=<...>
INTERPRETATION: <2-4 sentences in plain language for a network engineer>
NEXT_QUERIES: <up to 3 concrete follow-up data requests that would strengthen or refute this>
CONFIDENCE: high|medium|low
""",
    tools=[FunctionTool(analysis_tools.correlate_kpi_with_config),
           FunctionTool(analysis_tools.before_after_change),
           FunctionTool(analysis_tools.describe_result)],
    output_key="last_analysis",
)
