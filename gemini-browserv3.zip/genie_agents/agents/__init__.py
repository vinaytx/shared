"""Agent package. Configures Google auth on import so `adk web` / `adk run agents` work."""
from config.auth import configure_google_auth

configure_google_auth()
