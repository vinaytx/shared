"""
Root agent: a LoopAgent that re-runs the goal orchestrator until it calls
finish_goal (which escalates) or max_iterations is reached.

`adk run agents` / `adk web` pick up `root_agent` from this module.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

from google.adk.agents import LlmAgent, LoopAgent
from google.adk.agents.callback_context import CallbackContext
from google.adk.tools import FunctionTool
from google.adk.tools.agent_tool import AgentTool

from agents.specialists import analysis_agent, schema_agent, sql_agent
from config import settings
from tools import control_tools

log = logging.getLogger(__name__)
_cfg = settings()


def _after_iteration(callback_context: CallbackContext) -> None:
    """Persist state after every orchestrator turn so a login pause loses nothing."""
    st = callback_context.state
    d = Path(_cfg["run"]["checkpoint_dir"])
    path = d / f"{st.get('goal_id', 'goal')}.json"
    snap = {k: st.get(k) for k in ("goal", "goal_id", "plan", "hypotheses", "findings",
                                  "query_log", "queries_used", "final_summary")}
    path.write_text(json.dumps(snap, indent=2, default=str))


orchestrator = LlmAgent(
    name="goal_orchestrator",
    model=_cfg["models"]["orchestrator"],
    description="Plans and drives an autonomous investigation of network KPIs vs configuration.",
    instruction=f"""
You are the lead investigator for an autonomous network-performance analysis system.

GOAL: {{goal}}

State you can rely on (may be empty on the first turn):
- plan: {{plan?}}
- hypotheses so far: {{hypotheses?}}
- findings so far: {{findings?}}
- queries used: {{queries_used?}} of {_cfg['run']['max_queries_per_goal']}

Each turn, do exactly ONE step of the investigation, then stop so state is checkpointed:

1. If there is no plan: ask schema_agent what tables/columns exist for this goal, then call
   set_plan with 3-6 concrete steps (which KPI, which config parameters, which time window,
   which comparisons). Call record_hypothesis for each candidate explanation with status "open".
2. Otherwise take the next open step: ask sql_agent for the specific aggregated data you need
   (be explicit: table, columns, filters, grain, time window). Then hand the COLUMNS/ROWS and
   the question to analysis_agent.
3. Update hypotheses with record_hypothesis (supported / refuted / inconclusive) and record
   confirmed results with record_finding, including the exact SQL so a human can verify.
4. Decide: if the goal is answered with at least medium confidence, or every hypothesis is
   closed, or the query budget is nearly exhausted, call finish_goal with a clear summary that
   states findings, effect sizes, confidence, and what a human should verify before acting.
   Otherwise, note what to do next turn and end your reply.

Hard rules:
- Never fabricate numbers. Every quantitative claim must come from a tool result.
- Correlation is not causation: phrase findings as "associated with", and list confounders.
- If any tool reports status "needs_login", call checkpoint and end the turn saying the
  system is paused awaiting a human login. Do not retry in the same turn.
- Do not repeat a query you already ran (see query log via state); refine it instead.
""",
    tools=[
        AgentTool(agent=schema_agent),
        AgentTool(agent=sql_agent),
        AgentTool(agent=analysis_agent),
        FunctionTool(control_tools.set_plan),
        FunctionTool(control_tools.record_hypothesis),
        FunctionTool(control_tools.record_finding),
        FunctionTool(control_tools.checkpoint),
        FunctionTool(control_tools.finish_goal),
    ],
    after_agent_callback=_after_iteration,
)

root_agent = LoopAgent(
    name="goal_loop",
    description="Runs the orchestrator until the goal is finished or the iteration cap is hit.",
    sub_agents=[orchestrator],
    max_iterations=_cfg["run"]["max_loop_iterations"],
)
