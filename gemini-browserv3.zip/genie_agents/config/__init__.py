"""Load config/settings.yaml once and expose it as a nested dict."""
from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

import yaml
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")


@lru_cache(maxsize=1)
def settings() -> dict:
    path = Path(os.environ.get("GENIE_AGENTS_SETTINGS", ROOT / "config" / "settings.yaml"))
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    # make relative state paths absolute
    for key in ("checkpoint_dir", "needs_login_flag", "schema_cache"):
        cfg["run"][key] = str(ROOT / cfg["run"][key])
    Path(cfg["run"]["checkpoint_dir"]).mkdir(parents=True, exist_ok=True)
    return cfg
