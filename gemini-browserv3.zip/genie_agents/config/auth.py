"""
Google authentication for the Gemini calls made by ADK / google-genai.

Two methods (settings.auth.method):

  google_oauth  Sign in with your Google account, like Gemini CLI does.
                The SDK reads Application Default Credentials (ADC), which
                `gcloud auth application-default login` writes to:
                  Windows      %APPDATA%\\gcloud\\application_default_credentials.json
                  macOS/Linux  ~/.config/gcloud/application_default_credentials.json
                That file has the same shape as ~/.gemini/oauth_creds.json
                (client id/secret + refresh_token) and is refreshed automatically.
                Requests are routed through Vertex AI in auth.gcp_project.

  api_key       Uses GOOGLE_API_KEY from .env (AI Studio key).

Why not read ~/.gemini/oauth_creds.json directly?  That refresh token is bound
to the Gemini CLI's own OAuth client id/secret, which the CLI embeds and which
Google may rotate; reusing it from another program is unsupported and brittle.
ADC gives you the identical sign-in experience through the supported channel.

`configure_google_auth()` must run before any ADK agent/model object is built,
because google-genai reads these environment variables at client creation.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path

from config import settings

log = logging.getLogger(__name__)

_ADC_HELP = (
    "No Google credentials found.\n"
    "Sign in with your Google account (one time):\n"
    "    gcloud auth application-default login\n"
    "If you don't have gcloud: https://cloud.google.com/sdk/docs/install\n"
    "Then set auth.gcp_project in config/settings.yaml to a project with the\n"
    "Vertex AI API enabled (gcloud services enable aiplatform.googleapis.com)."
)


def configure_google_auth() -> dict:
    """Set the env vars google-genai/ADK expect and verify credentials exist."""
    auth = settings()["auth"]
    method = auth.get("method", "google_oauth")

    if method == "api_key":
        os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "0"
        if not os.environ.get("GOOGLE_API_KEY"):
            raise RuntimeError("auth.method is api_key but GOOGLE_API_KEY is not set in .env")
        return {"method": "api_key", "identity": "api key"}

    if method != "google_oauth":
        raise RuntimeError(f"Unknown auth.method: {method}")

    # --- Google account via ADC + Vertex AI ---------------------------------
    project, location = auth.get("gcp_project", ""), auth.get("gcp_location", "us-central1")
    if not project or project.startswith("<"):
        raise RuntimeError("Set auth.gcp_project in config/settings.yaml")
    os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "1"
    os.environ["GOOGLE_CLOUD_PROJECT"] = project
    os.environ["GOOGLE_CLOUD_LOCATION"] = location
    os.environ.pop("GOOGLE_API_KEY", None)   # avoid the SDK preferring a stale key

    sa = auth.get("service_account_file") or ""
    if sa:
        sa_path = Path(sa).expanduser()
        if not sa_path.exists():
            raise RuntimeError(f"service_account_file not found: {sa_path}")
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str(sa_path)

    import google.auth
    from google.auth import exceptions as gexc
    from google.auth.transport.requests import Request

    try:
        creds, detected_project = google.auth.default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"])
    except gexc.DefaultCredentialsError as exc:
        raise RuntimeError(_ADC_HELP) from exc

    # Refresh once now so an expired/revoked token fails here, not mid-run.
    try:
        creds.refresh(Request())
    except gexc.RefreshError as exc:
        raise RuntimeError(
            "Google credentials are expired or revoked. Re-run:\n"
            "    gcloud auth application-default login") from exc

    identity = getattr(creds, "service_account_email", None) or _adc_email(creds) or "google account"
    log.info("Google auth OK: %s, project=%s, location=%s", identity, project, location)
    return {"method": "google_oauth", "identity": identity, "project": project, "location": location}


def _adc_email(creds) -> str | None:
    """Best-effort: ask the userinfo endpoint who we are (for the --check output)."""
    try:
        import requests
        r = requests.get("https://www.googleapis.com/oauth2/v3/userinfo",
                         headers={"Authorization": f"Bearer {creds.token}"}, timeout=10)
        if r.ok:
            return r.json().get("email")
    except Exception:  # noqa: BLE001
        pass
    return None
