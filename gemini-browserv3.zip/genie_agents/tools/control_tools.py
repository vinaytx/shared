"""Tools the orchestrator uses to manage the goal loop and persist progress."""
from __future__ import annotations

import json
import time
from pathlib import Path

from google.adk.tools import ToolContext

from config import settings


def record_hypothesis(hypothesis: str, status: str, evidence: str, tool_context: ToolContext) -> dict:
    """
    Record a hypothesis and its current status so it is not re-tested.

    Args:
        hypothesis: e.g. "Cells with parameter X=on have lower throughput".
        status: one of "open", "supported", "refuted", "inconclusive".
        evidence: short summary of the data/statistics behind the status.
    """
    hs = tool_context.state.get("hypotheses", [])
    for h in hs:
        if h["hypothesis"] == hypothesis:
            h.update(status=status, evidence=evidence)
            break
    else:
        hs.append({"hypothesis": hypothesis, "status": status, "evidence": evidence})
    tool_context.state["hypotheses"] = hs
    return {"ok": True, "count": len(hs)}


def record_finding(title: str, detail: str, confidence: str, supporting_sql: str,
                   tool_context: ToolContext) -> dict:
    """
    Record a confirmed finding for the final report.

    Args:
        title: one-line finding.
        detail: what was measured, effect size, caveats.
        confidence: "high", "medium" or "low".
        supporting_sql: the SQL a human can re-run to verify.
    """
    fs = tool_context.state.get("findings", [])
    fs.append({"title": title, "detail": detail, "confidence": confidence,
               "sql": supporting_sql, "at": time.time()})
    tool_context.state["findings"] = fs
    return {"ok": True, "count": len(fs)}


def checkpoint(tool_context: ToolContext) -> dict:
    """Write the current goal state (plan, hypotheses, findings, query log) to disk."""
    d = Path(settings()["run"]["checkpoint_dir"])
    goal_id = tool_context.state.get("goal_id", "goal")
    path = d / f"{goal_id}.json"
    snapshot = {k: tool_context.state.get(k) for k in
                ("goal", "goal_id", "plan", "hypotheses", "findings", "query_log", "queries_used")}
    path.write_text(json.dumps(snapshot, indent=2, default=str))
    return {"ok": True, "path": str(path)}


def finish_goal(summary: str, tool_context: ToolContext) -> dict:
    """
    Call ONLY when the goal is answered or cannot be answered with available data.
    Ends the orchestration loop.

    Args:
        summary: final answer to the goal in plain language, referencing recorded findings.
    """
    tool_context.state["final_summary"] = summary
    checkpoint(tool_context)
    tool_context.actions.escalate = True   # stops the enclosing LoopAgent
    return {"ok": True}


def set_plan(steps: list[str], tool_context: ToolContext) -> dict:
    """Store or replace the ordered list of investigation steps for this goal."""
    tool_context.state["plan"] = steps
    return {"ok": True, "steps": len(steps)}
