"""
ADK FunctionTools that the SQL and schema agents call.

Every tool returns a plain dict so Gemini can read it. Row payloads are kept
compact (list-of-lists + columns) and capped by settings.run.max_rows_returned.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from google.adk.tools import ToolContext

from browser import genie_driver
from browser.session import needs_login
from config import settings

QUERY_COUNT_KEY = "queries_used"


def _quota_ok(tool_context: ToolContext) -> bool:
    used = tool_context.state.get(QUERY_COUNT_KEY, 0)
    limit = settings()["run"]["max_queries_per_goal"]
    if used >= limit:
        return False
    tool_context.state[QUERY_COUNT_KEY] = used + 1
    return True


async def ask_genie(question: str, tool_context: ToolContext, follow_up: bool = False) -> dict:
    """
    Ask the Databricks Genie space a natural-language data question and get
    the answer text, the SQL Genie generated, and the result rows.

    Args:
        question: Natural-language question about the network config/KPI data.
        follow_up: True to continue the previous Genie conversation (keeps context),
                   False to start a fresh conversation.
    Returns:
        dict with ok, answer_text, sql, columns, rows, row_count, truncated,
        conversation_id, url, error.
    """
    if needs_login():
        return {"ok": False, "status": "needs_login",
                "error": "Browser session expired; a human must log in to Databricks."}
    if not _quota_ok(tool_context):
        return {"ok": False, "error": "Query quota for this goal exhausted."}
    conv = tool_context.state.get("genie_conversation_id") if follow_up else None
    res = await genie_driver.ask_genie(question, conversation_id=conv)
    if res.conversation_id:
        tool_context.state["genie_conversation_id"] = res.conversation_id
    _log_query(tool_context, "genie", question, res.sql, res.ok, res.error)
    return res.to_dict()


async def run_sql(statement: str, tool_context: ToolContext, dry_run: bool = False) -> dict:
    """
    Execute a SQL statement on the Databricks SQL warehouse.

    Args:
        statement: The SQL to run. Must be a single SELECT/WITH statement.
        dry_run: If True, wraps the statement with LIMIT 10 to validate cheaply.
    Returns:
        dict with ok, columns, rows, row_count, truncated, error.
    """
    if needs_login():
        return {"ok": False, "status": "needs_login",
                "error": "Browser session expired; a human must log in to Databricks."}
    stripped = statement.strip().rstrip(";")
    head = stripped.lstrip().upper()
    if not (head.startswith("SELECT") or head.startswith("WITH")):
        return {"ok": False, "error": "Only SELECT/WITH statements are allowed."}
    if dry_run:
        stripped = f"SELECT * FROM ({stripped}) AS _dry LIMIT 10"
    if not _quota_ok(tool_context):
        return {"ok": False, "error": "Query quota for this goal exhausted."}
    res = await genie_driver.run_sql(stripped)
    _log_query(tool_context, "sql", statement, stripped, res.ok, res.error)
    return res.to_dict()


async def get_schema(tool_context: ToolContext, refresh: bool = False) -> dict:
    """
    Return the table/column structure for the configured catalog.schema.
    Cached on disk; pass refresh=True to re-read from Databricks.

    Returns:
        dict: {"tables": {table_name: {"comment": str, "columns": [{"name","type","comment"}]}}}
    """
    cfg = settings()
    cache = Path(cfg["run"]["schema_cache"])
    ttl = cfg["run"]["schema_cache_ttl_hours"] * 3600
    if cache.exists() and not refresh and time.time() - cache.stat().st_mtime < ttl:
        return json.loads(cache.read_text())
    if needs_login():
        return {"ok": False, "status": "needs_login"}
    rows = await genie_driver.fetch_schema(cfg["databricks"]["catalog"], cfg["databricks"]["schema"])
    tables: dict[str, dict] = {}
    for r in rows:
        t = tables.setdefault(r["table_name"], {"comment": r.get("table_comment") or "",
                                                "type": r.get("table_type"), "columns": []})
        t["columns"].append({"name": r["column_name"], "type": r["data_type"],
                             "comment": r.get("column_comment") or ""})
    out = {"catalog": cfg["databricks"]["catalog"], "schema": cfg["databricks"]["schema"],
           "tables": tables, "fetched_at": time.time()}
    cache.write_text(json.dumps(out, indent=2))
    return out


async def sample_table(table_name: str, tool_context: ToolContext, n: int = 5) -> dict:
    """Return n sample rows from a table (fully-qualified name is added automatically)."""
    cfg = settings()["databricks"]
    fq = table_name if "." in table_name else f"{cfg['catalog']}.{cfg['schema']}.{table_name}"
    return await run_sql(f"SELECT * FROM {fq} LIMIT {int(n)}", tool_context)


def _log_query(tool_context: ToolContext, kind: str, request: str, sql: str, ok: bool, error: str) -> None:
    log = tool_context.state.get("query_log", [])
    log.append({"kind": kind, "request": request[:500], "sql": sql[:2000], "ok": ok, "error": error})
    tool_context.state["query_log"] = log[-200:]
