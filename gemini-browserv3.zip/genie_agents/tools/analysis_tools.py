"""
Deterministic statistics tools for the analysis agent.

Input convention: `columns` (list[str]) + `rows` (list[list]) exactly as the
data tools return them, so the agent can pass a query result straight through.
"""
from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from scipy import stats

from google.adk.tools import ToolContext


def _df(columns: list[str], rows: list[list[Any]]) -> pd.DataFrame:
    df = pd.DataFrame(rows, columns=columns)
    for c in df.columns:
        df[c] = pd.to_numeric(df[c], errors="ignore")
    return df


def correlate_kpi_with_config(columns: list[str], rows: list[list], kpi_column: str,
                              config_columns: list[str], tool_context: ToolContext) -> dict:
    """
    Rank configuration parameters by how strongly they separate a KPI.

    Numeric config -> Spearman correlation with the KPI.
    Categorical/low-cardinality config -> Kruskal-Wallis test across groups plus
    per-group KPI medians, so the agent can see which value performs worse.

    Args:
        columns, rows: a query result (one row per network element or per element-day).
        kpi_column: name of the KPI column to explain.
        config_columns: config parameter columns to test.
    Returns:
        dict with "ranked": list of {parameter, kind, statistic, p_value, effect, groups}
        sorted by p_value, plus "n" and any "warnings".
    """
    df = _df(columns, rows)
    if kpi_column not in df.columns:
        return {"ok": False, "error": f"KPI column {kpi_column} not in result"}
    df = df.dropna(subset=[kpi_column])
    y = pd.to_numeric(df[kpi_column], errors="coerce")
    out, warnings = [], []
    for p in config_columns:
        if p not in df.columns:
            warnings.append(f"missing column {p}")
            continue
        x = df[p]
        try:
            if pd.api.types.is_numeric_dtype(x) and x.nunique() > 8:
                r, pv = stats.spearmanr(x, y, nan_policy="omit")
                out.append({"parameter": p, "kind": "numeric", "statistic": float(r),
                            "p_value": float(pv), "effect": float(abs(r)), "groups": None})
            else:
                groups = [g[kpi_column].astype(float).values for _, g in df.groupby(p) if len(g) >= 3]
                if len(groups) < 2:
                    warnings.append(f"{p}: fewer than 2 groups with >=3 samples")
                    continue
                h, pv = stats.kruskal(*groups)
                med = df.groupby(p)[kpi_column].agg(["median", "count"]).reset_index()
                spread = float(med["median"].max() - med["median"].min())
                out.append({"parameter": p, "kind": "categorical", "statistic": float(h),
                            "p_value": float(pv), "effect": spread,
                            "groups": med.rename(columns={p: "value"}).to_dict(orient="records")})
        except Exception as exc:  # noqa: BLE001
            warnings.append(f"{p}: {exc}")
    out.sort(key=lambda d: d["p_value"])
    return {"ok": True, "n": int(len(df)), "kpi": kpi_column, "ranked": out, "warnings": warnings}


def before_after_change(columns: list[str], rows: list[list], element_column: str,
                        time_column: str, kpi_column: str, change_time_column: str,
                        tool_context: ToolContext, window_days: int = 3) -> dict:
    """
    For each element with a config change timestamp, compare the KPI in the
    window before vs after the change (paired). Reports median delta and a
    Wilcoxon signed-rank p-value across elements.

    Args:
        columns, rows: result with one row per element per time bucket, including a
                       column with the element's config change time (null if none).
        element_column, time_column, kpi_column, change_time_column: column names.
        window_days: size of the before/after windows.
    """
    df = _df(columns, rows)
    df[time_column] = pd.to_datetime(df[time_column], errors="coerce")
    df[change_time_column] = pd.to_datetime(df[change_time_column], errors="coerce")
    df = df.dropna(subset=[time_column, change_time_column, kpi_column])
    per_elem = []
    for elem, g in df.groupby(element_column):
        ct = g[change_time_column].iloc[0]
        w = pd.Timedelta(days=window_days)
        before = g[(g[time_column] < ct) & (g[time_column] >= ct - w)][kpi_column].astype(float)
        after = g[(g[time_column] >= ct) & (g[time_column] < ct + w)][kpi_column].astype(float)
        if len(before) and len(after):
            per_elem.append({"element": elem, "before_median": float(before.median()),
                             "after_median": float(after.median()),
                             "delta": float(after.median() - before.median())})
    if len(per_elem) < 2:
        return {"ok": False, "error": "not enough elements with both before and after data",
                "elements": per_elem}
    deltas = np.array([e["delta"] for e in per_elem])
    try:
        stat, pv = stats.wilcoxon(deltas)
    except ValueError:
        stat, pv = float("nan"), float("nan")
    return {"ok": True, "n_elements": len(per_elem), "median_delta": float(np.median(deltas)),
            "share_worse": float((deltas < 0).mean()), "wilcoxon_p": float(pv),
            "elements": sorted(per_elem, key=lambda e: e["delta"])[:50]}


def describe_result(columns: list[str], rows: list[list], tool_context: ToolContext) -> dict:
    """Quick summary statistics of a query result (per numeric column) for sanity checks."""
    df = _df(columns, rows)
    desc = df.describe(include="all").T.fillna("").astype(str)
    return {"ok": True, "n": int(len(df)), "summary": desc.to_dict(orient="index")}
