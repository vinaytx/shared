"""
MCP server that exposes the Genie driver, SQL access, analysis and goal-control
tools to Gemini CLI. Run by Gemini CLI itself (stdio) via settings.json.

    python -m gemini_cli.mcp_server          # what Gemini CLI launches

All heavy lifting is the same code as the ADK version (browser/, tools/); this
file only adapts the interface and swaps ADK session state for state_store.
"""
from __future__ import annotations

import logging
import sys
import uuid
from pathlib import Path

# Make the project root importable regardless of Gemini CLI's cwd
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from mcp.server.fastmcp import FastMCP  # noqa: E402

from browser import genie_driver  # noqa: E402
from browser.session import needs_login  # noqa: E402
from config import settings  # noqa: E402
from gemini_cli import state_store  # noqa: E402
from tools import analysis_tools  # noqa: E402

logging.basicConfig(level=logging.INFO, stream=sys.stderr)   # stdout is the MCP channel
mcp = FastMCP("genie-tools")
_cfg = settings()


class _Ctx:
    """Minimal stand-in for ADK ToolContext: analysis tools only need .state."""
    def __init__(self) -> None:
        self.state = state_store.load()


def _use_quota() -> str | None:
    st = state_store.load()
    if st["queries_used"] >= _cfg["run"]["max_queries_per_goal"]:
        return "Query quota for this goal exhausted."
    st["queries_used"] += 1
    state_store.save(st)
    return None


def _log(kind: str, request: str, sql: str, ok: bool, error: str) -> None:
    st = state_store.load()
    st["query_log"] = (st["query_log"] + [{"kind": kind, "request": request[:500],
                                          "sql": sql[:2000], "ok": ok, "error": error}])[-200:]
    state_store.save(st)


# ---------------------------------------------------------------- data tools
@mcp.tool()
async def ask_genie(question: str, follow_up: bool = False) -> dict:
    """Ask the Databricks Genie space a natural-language data question. Returns answer text,
    the SQL Genie generated, columns and rows. follow_up=True continues the previous
    Genie conversation."""
    if needs_login():
        return {"ok": False, "status": "needs_login",
                "error": "Browser session expired; a human must log in to Databricks."}
    if (err := _use_quota()):
        return {"ok": False, "error": err}
    st = state_store.load()
    conv = st.get("genie_conversation_id") if follow_up else None
    res = await genie_driver.ask_genie(question, conversation_id=conv)
    if res.conversation_id:
        st = state_store.load()
        st["genie_conversation_id"] = res.conversation_id
        state_store.save(st)
    _log("genie", question, res.sql, res.ok, res.error)
    return res.to_dict()


@mcp.tool()
async def run_sql(statement: str, dry_run: bool = False) -> dict:
    """Execute a single SELECT/WITH statement on the Databricks SQL warehouse.
    dry_run=True wraps it in LIMIT 10 to validate cheaply. Returns columns and rows."""
    if needs_login():
        return {"ok": False, "status": "needs_login",
                "error": "Browser session expired; a human must log in to Databricks."}
    stripped = statement.strip().rstrip(";")
    if not stripped.lstrip().upper().startswith(("SELECT", "WITH")):
        return {"ok": False, "error": "Only SELECT/WITH statements are allowed."}
    if dry_run:
        stripped = f"SELECT * FROM ({stripped}) AS _dry LIMIT 10"
    if (err := _use_quota()):
        return {"ok": False, "error": err}
    res = await genie_driver.run_sql(stripped)
    _log("sql", statement, stripped, res.ok, res.error)
    return res.to_dict()


@mcp.tool()
async def get_schema(refresh: bool = False) -> dict:
    """Return tables and columns (with comments) of the configured catalog.schema.
    Cached on disk; refresh=True re-reads from Databricks."""
    import json, time
    cache = Path(_cfg["run"]["schema_cache"])
    ttl = _cfg["run"]["schema_cache_ttl_hours"] * 3600
    if cache.exists() and not refresh and time.time() - cache.stat().st_mtime < ttl:
        return json.loads(cache.read_text())
    if needs_login():
        return {"ok": False, "status": "needs_login"}
    db = _cfg["databricks"]
    rows = await genie_driver.fetch_schema(db["catalog"], db["schema"])
    tables: dict[str, dict] = {}
    for r in rows:
        t = tables.setdefault(r["table_name"], {"comment": r.get("table_comment") or "",
                                                "type": r.get("table_type"), "columns": []})
        t["columns"].append({"name": r["column_name"], "type": r["data_type"],
                             "comment": r.get("column_comment") or ""})
    out = {"catalog": db["catalog"], "schema": db["schema"], "tables": tables}
    cache.write_text(json.dumps(out, indent=2))
    return out


@mcp.tool()
async def sample_table(table_name: str, n: int = 5) -> dict:
    """Return n sample rows from a table in the configured catalog.schema."""
    db = _cfg["databricks"]
    fq = table_name if "." in table_name else f"{db['catalog']}.{db['schema']}.{table_name}"
    return await run_sql(f"SELECT * FROM {fq} LIMIT {int(n)}")


# ------------------------------------------------------------ analysis tools
@mcp.tool()
def correlate_kpi_with_config(columns: list[str], rows: list[list], kpi_column: str,
                              config_columns: list[str]) -> dict:
    """Rank config parameters by how strongly they separate a KPI (Spearman for numeric,
    Kruskal-Wallis + per-group medians for categorical). Pass a query result's columns/rows."""
    return analysis_tools.correlate_kpi_with_config(columns, rows, kpi_column, config_columns, _Ctx())


@mcp.tool()
def before_after_change(columns: list[str], rows: list[list], element_column: str,
                        time_column: str, kpi_column: str, change_time_column: str,
                        window_days: int = 3) -> dict:
    """Paired before/after comparison of a KPI around each element's config-change time."""
    return analysis_tools.before_after_change(columns, rows, element_column, time_column,
                                              kpi_column, change_time_column, _Ctx(), window_days)


@mcp.tool()
def describe_result(columns: list[str], rows: list[list]) -> dict:
    """Summary statistics per column of a query result, for sanity checks."""
    return analysis_tools.describe_result(columns, rows, _Ctx())


# ------------------------------------------------------------- control tools
@mcp.tool()
def start_goal(goal: str) -> dict:
    """Start a new investigation goal (resets plan, hypotheses, findings, quota)."""
    st = state_store.reset(goal, uuid.uuid4().hex[:8])
    return {"ok": True, "goal_id": st["goal_id"]}


@mcp.tool()
def get_goal_state() -> dict:
    """Return the current goal, plan, hypotheses, findings, queries used and status."""
    st = state_store.load()
    return {k: st.get(k) for k in ("goal", "goal_id", "status", "plan", "hypotheses",
                                   "findings", "queries_used", "final_summary")} | {
        "max_queries": _cfg["run"]["max_queries_per_goal"], "needs_login": needs_login()}


@mcp.tool()
def set_plan(steps: list[str]) -> dict:
    """Store or replace the ordered investigation steps."""
    st = state_store.load(); st["plan"] = steps; state_store.save(st)
    return {"ok": True, "steps": len(steps)}


@mcp.tool()
def record_hypothesis(hypothesis: str, status: str, evidence: str) -> dict:
    """Record/update a hypothesis: status is open | supported | refuted | inconclusive."""
    st = state_store.load()
    for h in st["hypotheses"]:
        if h["hypothesis"] == hypothesis:
            h.update(status=status, evidence=evidence); break
    else:
        st["hypotheses"].append({"hypothesis": hypothesis, "status": status, "evidence": evidence})
    state_store.save(st)
    return {"ok": True, "count": len(st["hypotheses"])}


@mcp.tool()
def record_finding(title: str, detail: str, confidence: str, supporting_sql: str) -> dict:
    """Record a confirmed finding (with the SQL a human can re-run) for the final report."""
    st = state_store.load()
    st["findings"].append({"title": title, "detail": detail, "confidence": confidence,
                           "sql": supporting_sql})
    state_store.save(st)
    return {"ok": True, "count": len(st["findings"])}


@mcp.tool()
def finish_goal(summary: str) -> dict:
    """Mark the goal complete with a final summary. Ends the headless loop."""
    st = state_store.load()
    st.update(final_summary=summary, status="done")
    state_store.save(st)
    return {"ok": True}


@mcp.tool()
async def check_databricks_session(deep: bool = False) -> dict:
    """Is the attended Chrome tab logged in to Databricks (and as whom)? deep=True also sends
    the configured test question to Genie and returns its answer, proving data access."""
    return await genie_driver.health_check(deep=deep)


if __name__ == "__main__":
    mcp.run(transport="stdio")
