"""
Headless goal loop for Gemini CLI (replaces ADK's LoopAgent).

    python -m gemini_cli.run_headless "Which config parameters are associated with low DL throughput ...?"

Each iteration runs `gemini -p` once in the project directory (so GEMINI.md, the
subagents and the MCP server are picked up). The MCP server persists state
between iterations, so every turn starts by calling get_goal_state and picks
up where the last one stopped. The loop ends when status becomes "done", when
the browser needs a login (it waits and resumes), or at max iterations.
"""
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from browser.session import needs_login  # noqa: E402
from config import settings  # noqa: E402
from gemini_cli import state_store  # noqa: E402

PROJECT = Path(__file__).resolve().parent            # gemini_cli/ holds GEMINI.md + .gemini/
_cfg = settings()


def run_turn(prompt: str) -> str:
    cmd = ["gemini", "-p", prompt, "--yolo"]        # --yolo auto-approves MCP tool calls
    proc = subprocess.run(cmd, cwd=PROJECT, capture_output=True, text=True,
                          timeout=_cfg["browser"]["genie_timeout_s"] * 4)
    if proc.returncode != 0:
        print(proc.stderr, file=sys.stderr)
    return proc.stdout


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    goal = " ".join(sys.argv[1:])
    st = state_store.load()
    if st.get("goal") != goal or st.get("status") == "done":
        state_store.reset(goal, time.strftime("%Y%m%d-%H%M%S"))
        first_prompt = f"/investigate {goal}"
    else:
        print(f"Resuming goal {st['goal_id']}")
        first_prompt = ("Continue the investigation from get_goal_state. Follow GEMINI.md. "
                        f"GOAL: {goal}")

    for i in range(_cfg["run"]["max_loop_iterations"]):
        print(f"\n===== iteration {i + 1} =====")
        prompt = first_prompt if i == 0 else (
            "Continue the investigation: call get_goal_state, take the next step per "
            f"GEMINI.md, and call finish_goal if the goal is answered. GOAL: {goal}")
        print(run_turn(prompt))
        st = state_store.load()
        if st["status"] == "done":
            break
        while needs_login():
            print("Paused: log in to Databricks in the attended Chrome window ...")
            time.sleep(30)

    st = state_store.load()
    print("\n=== FINAL SUMMARY ===\n", st.get("final_summary") or "(loop ended before finish_goal)")
    print(f"\nFindings: {len(st['findings'])}, queries used: {st['queries_used']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
