# Running the agents inside Gemini CLI (no API key / Vertex needed)

Gemini CLI is the orchestrator LLM (runs on your Code Assist licence). The
Python code in this repo is exposed to it as an MCP server, and the three
specialists are Gemini CLI subagents.

```
gemini_cli/
  mcp_server.py            genie-tools MCP server (Genie, SQL, schema, stats, goal state)
  state_store.py           shared JSON state (plan, hypotheses, findings, quota)
  run_headless.py          goal loop: re-runs `gemini -p` until finish_goal
  GEMINI.md                orchestrator instructions (read automatically by the CLI)
  .gemini/agents/*.md      schema-agent, sql-agent, analysis-agent
  .gemini/commands/investigate.toml   /investigate <goal>
  settings.snippet.json    MCP server + subagent settings to merge into settings.json
```

## Setup

1. Complete the base setup in the top-level README **except** the Google auth
   section (Gemini CLI already handles that): venv, `pip install -r requirements.txt`,
   `config/settings.yaml`, start Chrome with `scripts\\start_chrome.bat`, log in, and confirm with `python scripts\\check_browser.py --sql "SELECT 1"`.
2. Merge `settings.snippet.json` into `~/.gemini/settings.json` (replace `<PROJECT_ROOT>`;
   on Windows use `.venv\Scripts\python.exe`). Subagents may still be behind the
   `experimental.enableAgents` flag in your CLI version; check `gemini --version` docs.
3. Verify the MCP server loads:
   ```
   cd genie_agents/gemini_cli
   gemini
   > /mcp            # should list genie-tools with ask_genie, run_sql, ... 
   > /agents         # should list schema-agent, sql-agent, analysis-agent
   > check_databricks_session   (or ask: "is the databricks session logged in?")
   ```

## Run

Interactive (recommended while tuning prompts):
```
cd genie_agents/gemini_cli
gemini
> /investigate Which configuration parameters are associated with low downlink throughput on LTE cells in region North over the last 7 days?
```
Approve tool calls as they come, or start with `gemini --yolo` to auto-approve.

Headless loop (unattended apart from the browser login):
```
python -m gemini_cli.run_headless "Which configuration parameters are associated with ..."
```
State is in `state/checkpoints/gemini_cli_state.json`; per-call audit JSON in `state/audit/`.
If the Databricks session expires the MCP tools return `needs_login`, the loop
waits, and resumes after you log in again in the Chrome window.

## Notes

- Subagents do NOT inherit the main session's tools. Each agent file lists its MCP tools
  with the qualified `genie-tools__<tool>` name (double underscore) and declares the
  `genie-tools` server inline under `mcpServers:` so it is loaded for that agent. Short
  names like `get_schema` fail validation with "Invalid tool name". Adjust the paths in
  the three `.gemini/agents/*.md` files to your machine (forward slashes are fine on Windows).
- If your CLI version still rejects the qualified names, use a wildcard instead:
  `tools: ["mcp_genie-tools_*"]` grants every tool from that server.
- Gemini CLI enforces its own per-day request quota on Code Assist licences; the
  `run.max_queries_per_goal` and `max_loop_iterations` settings keep a runaway goal cheap.
- The ADK version (`main.py`) still works unchanged if you later get API/Vertex access.
