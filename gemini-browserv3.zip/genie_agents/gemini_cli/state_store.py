"""
File-backed goal state for the Gemini CLI deployment.

The ADK version kept state in the session; here the MCP server owns it so the
orchestrator (Gemini CLI) and all subagents see the same plan/findings/quota.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from config import settings

_PATH = Path(settings()["run"]["checkpoint_dir"]) / "gemini_cli_state.json"
_DEFAULT = {"goal": "", "goal_id": "", "status": "idle", "plan": [], "hypotheses": [],
            "findings": [], "query_log": [], "queries_used": 0,
            "genie_conversation_id": None, "final_summary": ""}


def load() -> dict:
    if _PATH.exists():
        return {**_DEFAULT, **json.loads(_PATH.read_text())}
    return dict(_DEFAULT)


def save(state: dict) -> None:
    state["updated_at"] = time.time()
    _PATH.write_text(json.dumps(state, indent=2, default=str))


def reset(goal: str, goal_id: str) -> dict:
    st = dict(_DEFAULT)
    st.update(goal=goal, goal_id=goal_id, status="running")
    save(st)
    return st
