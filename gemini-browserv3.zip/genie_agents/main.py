"""
Run one goal end to end.

    python main.py "Find which config parameters are associated with low DL throughput
                    on LTE cells in region North during the last 7 days"

    python main.py --check        # only verify the browser session is logged in
    python main.py --resume <goal_id>
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
import uuid
from pathlib import Path

from config import settings
from config.auth import configure_google_auth

# Auth env vars must be in place BEFORE ADK/google-genai objects are created,
# so this runs at import time, ahead of the agents package.
AUTH_INFO = configure_google_auth()

from google.adk.runners import Runner           # noqa: E402
from google.adk.sessions import DatabaseSessionService  # noqa: E402
from google.genai import types                  # noqa: E402

from agents.agent import root_agent             # noqa: E402
from browser import genie_driver                # noqa: E402
from browser.chrome import Chrome            # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("main")
APP = "genie_agents"
USER = "operator"


async def check_session() -> int:
    print(f"Google auth: {AUTH_INFO['method']} as {AUTH_INFO['identity']}"
          + (f" (project {AUTH_INFO['project']}, {AUTH_INFO['location']})"
             if AUTH_INFO['method'] == 'google_oauth' else ""))
    p = await genie_driver.health_check()
    print("Databricks browser session:", f"OK as {p['email']}" if p["logged_in"] else f"NOT LOGGED IN ({p['error']})")
    if p["logged_in"]:
        print(f"Using tab: {p['tab']['title']!r}")
    print("For step-by-step diagnostics run: python scripts/check_browser.py --test")
    await Chrome.get().close()
    return 0 if p["logged_in"] else 1


async def run_goal(goal: str, goal_id: str | None) -> int:
    cfg = settings()
    goal_id = goal_id or uuid.uuid4().hex[:8]
    session_service = DatabaseSessionService(db_url="sqlite:///state/sessions.db")
    session = await session_service.get_session(app_name=APP, user_id=USER, session_id=goal_id)
    if session is None:
        session = await session_service.create_session(
            app_name=APP, user_id=USER, session_id=goal_id,
            state={"goal": goal, "goal_id": goal_id, "queries_used": 0,
                   "hypotheses": [], "findings": [], "query_log": []})
        print(f"goal_id={goal_id}")
    else:
        print(f"resuming goal_id={goal_id}: {session.state.get('goal')}")

    runner = Runner(agent=root_agent, app_name=APP, session_service=session_service)
    msg = types.Content(role="user", parts=[types.Part(text=f"Investigate this goal: {goal}")])
    try:
        async for event in runner.run_async(user_id=USER, session_id=goal_id, new_message=msg):
            if event.content and event.content.parts:
                for p in event.content.parts:
                    if p.text:
                        print(f"[{event.author}] {p.text.strip()[:1500]}")
                    if p.function_call:
                        print(f"[{event.author}] -> {p.function_call.name}")
    finally:
        await Chrome.get().close()

    final = await session_service.get_session(app_name=APP, user_id=USER, session_id=goal_id)
    report = {
        "goal": goal, "goal_id": goal_id,
        "summary": final.state.get("final_summary"),
        "findings": final.state.get("findings", []),
        "hypotheses": final.state.get("hypotheses", []),
        "queries_used": final.state.get("queries_used", 0),
    }
    out = Path(cfg["run"]["checkpoint_dir"]) / f"{goal_id}-report.json"
    out.write_text(json.dumps(report, indent=2, default=str))
    print("\n=== FINAL SUMMARY ===\n", report["summary"] or "(loop ended without finish_goal)")
    print(f"\nReport written to {out}")
    return 0


def cli() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("goal", nargs="?", help="Investigation goal in plain language")
    ap.add_argument("--check", action="store_true", help="Verify browser login only")
    ap.add_argument("--resume", metavar="GOAL_ID", help="Resume a paused/checkpointed goal")
    a = ap.parse_args()
    if a.check:
        return asyncio.run(check_session())
    if a.resume:
        ck = Path(settings()["run"]["checkpoint_dir"]) / f"{a.resume}.json"
        goal = json.loads(ck.read_text())["goal"] if ck.exists() else (a.goal or "")
        return asyncio.run(run_goal(goal, a.resume))
    if not a.goal:
        ap.print_help()
        return 2
    return asyncio.run(run_goal(a.goal, None))


if __name__ == "__main__":
    sys.exit(cli())
