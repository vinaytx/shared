"""adhoc - check and run a generated query script, with capped output.

    bash tools/run adhoc .goals/<goal>/scratch/<task>/<name>.py [--timeout 180] [--max-out 3000]

1. The script must live under .goals/<goal>/scratch/ (which `cleanup` deletes).
2. Static check (AST): only allow-listed imports, no file/process/network access,
   no eval/exec/getattr, no attribute assignment, and no COM methods that change or
   send mail (Send, Delete, Move, Save, ...). Rejections list line numbers.
3. Runs with tools/lib on the path, cwd = the scratch dir, and GOAL_SCRATCH /
   GOAL_ARTIFACTS set. Output over --max-out chars is cut; the full text is kept
   in <name>.out next to the script.

This is a guardrail against mistakes and prompt-injected instructions, not a sandbox.
"""
from __future__ import annotations

import argparse
import ast
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LIB = ROOT / "tools" / "lib"
GOALS = ROOT / ".goals"

STD_OK = {
    "re", "datetime", "collections", "itertools", "functools", "json", "math", "statistics", "textwrap",
    "string", "typing", "dataclasses", "hashlib", "html", "operator", "decimal", "fractions", "difflib",
    "calendar", "unicodedata", "heapq", "bisect", "enum", "pprint", "__future__",
}
BUILTINS_BLOCKED = {"eval", "exec", "compile", "__import__", "open", "input", "breakpoint", "globals", "locals",
                    "vars", "getattr", "setattr", "delattr", "exit", "quit", "memoryview", "help"}
# COM methods that change, send or display mail, plus file-system mutators on Path-like objects.
ATTRS_BLOCKED = {
    "Send", "Delete", "PermanentDelete", "Move", "MoveTo", "CopyTo", "Copy", "Forward", "Reply", "ReplyAll",
    "Save", "SaveAs", "SaveAsFile", "Close", "Display", "Execute", "Respond", "Remove", "Add", "AddMember",
    "CreateItem", "CreateItemFromTemplate", "Logon", "Logoff", "Quit", "MarkAsTask", "ClearTaskFlag",
    "Delegate", "ShowCategoriesDialog", "PrintOut", "Import", "Export",
    "write_text", "write_bytes", "unlink", "rmdir", "rename", "mkdir", "touch", "chmod", "symlink_to",
    "hardlink_to", "open", "system", "popen", "rmtree",
}
MAX_LINES = 400


def lib_modules() -> set[str]:
    return {p.stem for p in LIB.glob("*.py") if not p.stem.startswith("_") and p.stem != "TEMPLATE"}


def lint(src: str, libs: set[str]) -> list[str]:
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        return [f"line {e.lineno}: syntax error: {e.msg}"]
    bad: list[str] = []
    ok_mods = STD_OK | libs
    if src.count("\n") > MAX_LINES:
        bad.append(f"script longer than {MAX_LINES} lines - keep ad hoc scripts short")
    for n in ast.walk(tree):
        ln = getattr(n, "lineno", "?")
        if isinstance(n, ast.Import):
            for a in n.names:
                if a.name.split(".")[0] not in ok_mods:
                    bad.append(f"line {ln}: import '{a.name}' not allowed (use: {', '.join(sorted(libs))} or safe stdlib)")
        elif isinstance(n, ast.ImportFrom):
            mod = (n.module or "").split(".")[0]
            if n.level or mod not in ok_mods:
                bad.append(f"line {ln}: import from '{n.module}' not allowed")
            if any(a.name == "*" for a in n.names) and mod not in libs:
                bad.append(f"line {ln}: 'import *' only allowed from helper libs")
        elif isinstance(n, ast.Name) and n.id in BUILTINS_BLOCKED:
            bad.append(f"line {ln}: '{n.id}' not allowed")
        elif isinstance(n, ast.Attribute):
            if n.attr.startswith("__"):
                bad.append(f"line {ln}: dunder attribute '{n.attr}' not allowed")
            elif n.attr in ATTRS_BLOCKED:
                bad.append(f"line {ln}: '.{n.attr}' not allowed (read-only; use helper methods like save_atts/export)")
            if isinstance(n.ctx, (ast.Store, ast.Del)):
                bad.append(f"line {ln}: assigning/deleting attributes not allowed")
        elif isinstance(n, ast.Subscript) and isinstance(n.ctx, (ast.Store, ast.Del)) and isinstance(n.value, ast.Attribute):
            bad.append(f"line {ln}: item assignment on an attribute not allowed")
    return sorted(set(bad), key=lambda s: (len(s.split(":")[0]), s))


def locate(script: Path) -> tuple[Path, Path]:
    """Return (scratch_dir, artifacts_dir) or exit if the script is not in a goal scratch dir."""
    try:
        rel = script.resolve().relative_to(GOALS.resolve())
    except ValueError:
        sys.exit(fail(2, "script must be under .goals/<goal>/scratch/"))
    parts = rel.parts
    if len(parts) < 3 or parts[1] != "scratch" or script.suffix != ".py":
        sys.exit(fail(2, "script must be .goals/<goal>/scratch/[<task>/]<name>.py"))
    task = parts[2] if len(parts) > 3 else "main"
    return script.resolve().parent, GOALS.resolve() / parts[0] / "artifacts" / task


def fail(code: int, msg: str) -> int:
    print(f"ADHOC ERROR: {msg}")
    return code


def main() -> int:
    ap = argparse.ArgumentParser(prog="tools/run adhoc")
    ap.add_argument("script")
    ap.add_argument("--timeout", type=int, default=180)
    ap.add_argument("--max-out", type=int, default=3000)
    a = ap.parse_args()

    script = Path(a.script)
    if not script.is_absolute():
        script = (Path.cwd() / script)
    if not script.is_file():
        return fail(2, f"no such script: {a.script}")
    scratch, artifacts = locate(script)

    problems = lint(script.read_text(encoding="utf-8"), lib_modules())
    if problems:
        print("LINT REJECTED - fix and rerun:")
        print("\n".join("  " + p for p in problems[:20]))
        return 2

    env = dict(os.environ)
    pp = os.pathsep.join(p for p in (str(LIB), env.get("PYTHONPATH", "")) if p)
    env.update({"PYTHONPATH": pp, "GOAL_SCRATCH": str(scratch), "GOAL_ARTIFACTS": str(artifacts),
                "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8", "PYTHONDONTWRITEBYTECODE": "1"})
    t0 = time.time()
    try:
        p = subprocess.run([sys.executable, "-B", str(script)], cwd=str(scratch), env=env,
                           capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=a.timeout)
    except subprocess.TimeoutExpired:
        return fail(124, f"timed out after {a.timeout}s - narrow the query (dates, folder, limit)")
    secs = time.time() - t0

    out = p.stdout or ""
    if len(out) > a.max_out:
        full = script.with_suffix(".out")
        full.write_text(out, encoding="utf-8")
        cut = out[: a.max_out].rsplit("\n", 1)[0]
        out = f"{cut}\n[output cut at {a.max_out} of {len(p.stdout)} chars; full: {full.relative_to(ROOT).as_posix()}]"
    if out.strip():
        print(out.rstrip())
    err = (p.stderr or "").replace(str(ROOT) + os.sep, "").replace(str(ROOT) + "/", "").strip().splitlines()
    if p.returncode in (2, 3) and err and err[-1].startswith(("BLOCKED", "QUERY ERROR")):
        print(err[-1])
    elif p.returncode != 0 and err:
        print("STDERR (tail):")
        print("\n".join("  " + l for l in err[-10:]))
    print(f"[exit={p.returncode} {secs:.1f}s]")
    return p.returncode


if __name__ == "__main__":
    sys.exit(main())
