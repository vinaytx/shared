"""cleanup - delete generated scripts (and optionally all goal data).

    bash tools/run cleanup <goal_id>                 remove .goals/<goal_id>/scratch (scripts, .out files)
    bash tools/run cleanup <goal_id> --task T1       remove only .goals/<goal_id>/scratch/T1
    bash tools/run cleanup <goal_id> --purge         remove the whole .goals/<goal_id> (plan, results, artifacts)
    bash tools/run cleanup --stale [--hours 12]      remove scratch dirs untouched for N hours (any goal)
    bash tools/run cleanup --list                    show goals and their sizes

Only ever deletes inside <project>/.goals/.
"""
from __future__ import annotations

import argparse
import re
import shutil
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
GOALS = (ROOT / ".goals").resolve()
ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,120}$")


def size(p: Path) -> int:
    return sum(f.stat().st_size for f in p.rglob("*") if f.is_file()) if p.exists() else 0


def files(p: Path) -> int:
    return sum(1 for f in p.rglob("*") if f.is_file()) if p.exists() else 0


def rm(p: Path) -> tuple[int, int]:
    p = p.resolve()
    if p == GOALS or GOALS not in p.parents:
        raise SystemExit(f"CLEANUP ERROR: refusing to delete outside .goals: {p}")
    if not p.exists():
        return 0, 0
    n, b = files(p), size(p)
    shutil.rmtree(p)
    return n, b


def newest_mtime(p: Path) -> float:
    return max([p.stat().st_mtime] + [f.stat().st_mtime for f in p.rglob("*")])


def main() -> int:
    ap = argparse.ArgumentParser(prog="tools/run cleanup")
    ap.add_argument("goal", nargs="?")
    ap.add_argument("--task")
    ap.add_argument("--purge", action="store_true")
    ap.add_argument("--stale", action="store_true")
    ap.add_argument("--hours", type=float, default=12)
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()

    if a.list:
        for g in sorted(GOALS.iterdir()) if GOALS.exists() else []:
            if g.is_dir():
                print(f"{g.name}\tscratch={files(g / 'scratch')} files\ttotal={size(g) // 1024} KB")
        return 0

    if a.stale:
        cutoff, n_dirs, n_files = time.time() - a.hours * 3600, 0, 0
        for sc in GOALS.glob("*/scratch") if GOALS.exists() else []:
            if sc.is_dir() and newest_mtime(sc) < cutoff:
                n, _ = rm(sc)
                n_dirs, n_files = n_dirs + 1, n_files + n
                if not any(sc.parent.iterdir()):
                    sc.parent.rmdir()
        for g in GOALS.iterdir() if GOALS.exists() else []:
            if g.is_dir() and not any(g.iterdir()):
                g.rmdir()
        print(f"cleanup: removed {n_dirs} stale scratch dirs ({n_files} files)" if n_dirs else "cleanup: nothing stale")
        return 0

    if not a.goal or not ID.match(a.goal):
        print("CLEANUP ERROR: give a goal id (see --list), or --stale")
        return 2
    goal = GOALS / a.goal
    if not goal.exists():
        print(f"cleanup: {a.goal} not found (already clean)")
        return 0
    if a.purge:
        target = goal
    elif a.task:
        if not ID.match(a.task):
            print("CLEANUP ERROR: bad task id")
            return 2
        target = goal / "scratch" / a.task
    else:
        target = goal / "scratch"
    n, b = rm(target)
    print(f"cleanup: removed {target.relative_to(ROOT).as_posix()} ({n} files, {b // 1024} KB)")
    if not a.purge and goal.exists() and not any(goal.iterdir()):
        goal.rmdir()
    return 0


if __name__ == "__main__":
    sys.exit(main())
