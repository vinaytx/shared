"""doctor - check what each mail source needs. Compact key=value output.

    bash tools/run doctor            (all)
    bash tools/run doctor outlook
    bash tools/run doctor barracuda
"""
from __future__ import annotations

import os
import platform
import struct
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "lib"))
from _base import EnvError  # noqa: E402
import olk  # noqa: E402
import eml  # noqa: E402

problems: list[str] = []


def line(**kv):
    print(" ".join(f"{k}={v}" for k, v in kv.items()))


def outlook() -> bool:
    bits = struct.calcsize("P") * 8
    line(python=sys.version.split()[0], bits=bits, os=platform.system())
    if os.name == "nt":
        try:
            import ctypes
            if ctypes.windll.shell32.IsUserAnAdmin():
                problems.append("shell is elevated (admin): run Claude Code non-elevated, same as Outlook")
        except Exception:
            pass
    try:
        stores = olk.stores()
    except EnvError as e:
        problems.append(f"{e.code}: {e.msg} | {e.hint}")
        line(outlook="unavailable")
        return False
    line(outlook="connected", stores=len(stores))
    for s in stores:
        print(f"  store\t{s['name']}" + ("\t[archive?]" if s["archive"] else ""))
    return True


def barracuda(have_outlook: bool):
    local = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
    addin_dir = local / "Barracuda" / "Message Archiver" / "Outlook Add-In"
    line(addin_cache=addin_dir.exists())
    archive = []
    if have_outlook:
        archive = [s["name"] for s in olk.stores() if s["archive"]]
    line(archive_stores=len(archive))
    try:
        d = eml.export_dir()
        n = sum(1 for p in d.rglob("*") if p.suffix.lower() in (".eml", ".zip"))
        line(export_dir=d, eml_or_zip=n)
    except EnvError:
        line(export_dir="none")
        d = None
    if archive:
        line(barracuda_path="olk.archive_stores()")
    elif d:
        line(barracuda_path="eml.search()")
    else:
        problems.append("no Barracuda source: sync Archive Stores in the Outlook add-in, or export EML and set BARRACUDA_EXPORT_DIR")


def main():
    what = sys.argv[1] if len(sys.argv) > 1 else "all"
    ok = outlook() if what in ("all", "outlook", "barracuda") else False
    if what in ("all", "barracuda"):
        barracuda(ok)
    for p in problems:
        print("PROBLEM " + p)
    print("[doctor ok]" if not problems else f"[doctor: {len(problems)} problem(s)]")
    return 0 if not problems else 3


if __name__ == "__main__":
    sys.exit(main())
