"""PreToolUse(Write|Edit) hook for workers: files may only be written as .py scripts
inside the project's .goals/<goal>/scratch/ tree. Exit 0 = allow, 2 = block.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path


def main() -> None:
    try:
        data = json.load(sys.stdin)
    except Exception:
        sys.stderr.write("Blocked: unreadable hook input\n")
        sys.exit(2)
    fp = (data.get("tool_input") or {}).get("file_path") or ""
    root = Path(os.environ.get("CLAUDE_PROJECT_DIR") or data.get("cwd") or ".").resolve()
    p = Path(fp)
    p = (p if p.is_absolute() else root / p).resolve()
    try:
        rel = p.relative_to(root / ".goals")
    except ValueError:
        rel = None
    if rel is None or len(rel.parts) < 3 or rel.parts[1] != "scratch" or p.suffix != ".py":
        sys.stderr.write(f"Blocked by worker policy: workers may only write .py scripts under "
                         f".goals/<goal>/scratch/<task>/ (got {fp}). Save data with out.save() inside the script.\n")
        sys.exit(2)
    sys.exit(0)


if __name__ == "__main__":
    main()
