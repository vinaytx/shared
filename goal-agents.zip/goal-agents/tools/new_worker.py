"""new-worker - scaffold a worker agent and its helper library.

    bash tools/run new-worker jira-tickets --lib jira --purpose "Searches Jira tickets"

Creates .claude/agents/workers/<name>.md (from .claude/goal-framework/WORKER_TEMPLATE.md)
and tools/lib/<lib>.py (from tools/lib/TEMPLATE.py, skipped if it exists).
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main() -> int:
    ap = argparse.ArgumentParser(prog="tools/run new-worker")
    ap.add_argument("name", help="lowercase-with-dashes, e.g. jira-tickets")
    ap.add_argument("--lib", help="helper module name (default: first word of name)")
    ap.add_argument("--purpose", default="__ONE_LINE_PURPOSE__")
    a = ap.parse_args()
    if not re.fullmatch(r"[a-z][a-z0-9-]{1,62}", a.name):
        print("ERROR: name must be lowercase letters, digits, dashes")
        return 2
    lib = (a.lib or a.name.split("-")[0]).replace("-", "_")
    if not re.fullmatch(r"[a-z][a-z0-9_]{1,40}", lib) or lib in {"out", "olk", "eml"} and not a.lib:
        print(f"ERROR: pick a different --lib (got '{lib}')")
        return 2
    agent = ROOT / ".claude" / "agents" / "workers" / f"{a.name}.md"
    if agent.exists():
        print(f"ERROR: {agent.relative_to(ROOT).as_posix()} exists")
        return 2
    purpose = a.purpose if a.purpose == "__ONE_LINE_PURPOSE__" else a.purpose.strip().rstrip(".") + "."
    tmpl = (ROOT / ".claude" / "goal-framework" / "WORKER_TEMPLATE.md").read_text(encoding="utf-8")
    agent.write_text(tmpl.replace("__NAME__", a.name).replace("__LIB__", lib).replace("__ONE_LINE_PURPOSE__", purpose),
                     encoding="utf-8")
    print(f"created {agent.relative_to(ROOT).as_posix()}")
    libp = ROOT / "tools" / "lib" / f"{lib}.py"
    if libp.exists():
        print(f"kept existing tools/lib/{lib}.py")
    else:
        libp.write_text((ROOT / "tools" / "lib" / "TEMPLATE.py").read_text(encoding="utf-8").replace("__LIB__", lib),
                        encoding="utf-8")
        print(f"created tools/lib/{lib}.py")
    print("next: fill Capabilities + cheat sheet in the agent file, implement the lib, then: bash tools/run registry")
    return 0


if __name__ == "__main__":
    sys.exit(main())
