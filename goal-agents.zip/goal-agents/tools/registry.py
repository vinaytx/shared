"""registry - list workers (.claude/agents/workers/**/*.md), their capabilities and helper libs.

Claude Code already shows worker descriptions to the orchestrator, so this is mainly for
people adding workers: it also flags missing libs and duplicate names.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WORKERS = ROOT / ".claude" / "agents" / "workers"


def frontmatter(text: str) -> tuple[dict, str]:
    if not text.startswith("---"):
        return {}, text
    end = text.find("\n---", 3)
    if end < 0:
        return {}, text
    fm = {m.group(1): m.group(2).strip().strip("'\"")
          for m in re.finditer(r"^([A-Za-z][\w-]*):[ \t]*(.*)$", text[3:end], re.M)}
    return fm, text[end + 4:]


def capabilities(body: str) -> list[str]:
    m = re.search(r"^##\s+Capabilities\s*\n(.*?)(?=^##\s|\Z)", body, re.S | re.M)
    return [re.sub(r"^\s*[-*]\s+", "", l).strip() for l in (m.group(1).splitlines() if m else []) if re.match(r"^\s*[-*]\s+", l)]


def main() -> int:
    names, problems = [], []
    for path in sorted(WORKERS.rglob("*.md")) if WORKERS.exists() else []:
        fm, body = frontmatter(path.read_text(encoding="utf-8"))
        rel = path.relative_to(ROOT).as_posix()
        if not fm.get("name") or not fm.get("description"):
            problems.append(f"{rel}: missing name/description (Claude Code skips it)")
            continue
        libs = sorted(set(re.findall(r"tools/lib/([a-z0-9_]+)\.py", body)))
        for lib in libs:
            if not (ROOT / "tools" / "lib" / f"{lib}.py").exists():
                problems.append(f"{fm['name']}: tools/lib/{lib}.py not found")
        names.append(fm["name"])
        print(f"{fm['name']}\tmodel={fm.get('model', 'inherit')}\tlibs={','.join(libs) or '-'}\t{rel}")
        for c in capabilities(body):
            print(f"  - {c}")
    for n in {n for n in names if names.count(n) > 1}:
        problems.append(f"duplicate worker name '{n}'")
    for p in problems:
        print("PROBLEM " + p)
    print(f"[{len(names)} workers]")
    return 0 if not problems else 1


if __name__ == "__main__":
    sys.exit(main())
