"""__LIB__ - read-only helpers for <system>, used by ad hoc scripts.

Keep the API small and the docstring a cheat sheet - workers read it to write scripts.

  search(query=None, since=None, limit=200) -> [Rec]
  get(id) -> Rec
  Rec fields : id title updated ...
  Rec methods: detail(n=2000)

Raise EnvError(code, msg, hint) when the environment isn't ready (missing credentials,
service unreachable) so the worker reports `blocked`. Raise QueryError for bad input.
Never print secrets. Never expose write/delete operations here.
"""
from __future__ import annotations

from _base import EnvError, QueryError, clip, day  # noqa: F401

__all__ = ["search", "get"]


def search(query=None, since=None, limit=200):
    raise EnvError("ENV_NOT_IMPLEMENTED", "__LIB__.search is not implemented yet", "implement tools/lib/__LIB__.py")


def get(id):
    raise EnvError("ENV_NOT_IMPLEMENTED", "__LIB__.get is not implemented yet", "implement tools/lib/__LIB__.py")
