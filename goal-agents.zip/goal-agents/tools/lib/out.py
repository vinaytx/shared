"""out - compact output for ad hoc scripts (keeps tokens low).

  rows(items, "received from_email subject natt", n=25, w=60, save=None)
      Print up to n rows as TSV (header first). Cells cut to w chars. Ends with
      "# shown/total". save="name.jsonl" writes ALL rows (all listed fields) to the
      artifacts dir and prints its path.
  say(*parts)           one line of text
  kv(**pairs)           "k=v k=v" on one line
  count(items, field, n=15)   top values of a field with counts
  dedupe(items, key="msgid")  drop items whose key was already seen (None keys kept)
  save(name, data)      write text / list of dicts (JSONL) / bytes to artifacts (overwrites); returns path

Items can be Msg / EMsg objects (olk, eml) or dicts.
"""
from __future__ import annotations

import collections
import datetime as dt
import json
from pathlib import Path

from _base import ARTIFACTS, ROOT

__all__ = ["rows", "say", "kv", "count", "dedupe", "save"]


def _get(item, field):
    if isinstance(item, dict):
        v = item.get(field)
    else:
        v = getattr(item, field, None)
        if callable(v):
            v = None
    if isinstance(v, dt.datetime):
        return v.strftime("%Y-%m-%d %H:%M")
    return v


def _cell(v, w):
    s = "" if v is None else str(v).replace("\t", " ").replace("\r", " ").replace("\n", " ")
    return s if len(s) <= w else s[: w - 1] + "…"


def rows(items, fields="received from_email subject natt", n=25, w=60, save=None):
    items = list(items)
    fl = fields.split() if isinstance(fields, str) else list(fields)
    print("\t".join(fl))
    for it in items[:n]:
        print("\t".join(_cell(_get(it, f), w) for f in fl))
    print(f"# {min(n, len(items))}/{len(items)} rows")
    if save:
        p = globals()["save"](save, [{f: _get(it, f) for f in fl} for it in items])
        print(f"# saved {len(items)} rows -> {p}")
    return items


def say(*parts):
    print(" ".join(str(p) for p in parts))


def kv(**pairs):
    print(" ".join(f"{k}={v}" for k, v in pairs.items()))


def count(items, field, n=15):
    c = collections.Counter(_get(it, field) for it in items)
    for val, k in c.most_common(n):
        print(f"{k}\t{_cell(val, 70)}")
    print(f"# {len(c)} distinct")
    return c


def dedupe(items, key="msgid"):
    seen, out = set(), []
    for it in items:
        k = _get(it, key)
        if k is not None and k in seen:
            continue
        if k is not None:
            seen.add(k)
        out.append(it)
    return out


def save(name, data) -> str:
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    p = ARTIFACTS / Path(str(name)).name  # overwrite: reruns of a script replace their output
    if isinstance(data, (bytes, bytearray)):
        p.write_bytes(data)
    elif isinstance(data, str):
        p.write_text(data, encoding="utf-8")
    else:
        with p.open("w", encoding="utf-8") as f:
            for d in data:
                f.write(json.dumps(d, ensure_ascii=False, default=str) + "\n")
    try:
        return p.resolve().relative_to(ROOT.resolve()).as_posix()
    except ValueError:
        return str(p)
