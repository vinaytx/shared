"""Shared plumbing for ad hoc scripts. Scripts normally don't import this directly.

Environment set by the runner (tools/adhoc.py):
  GOAL_SCRATCH    the script's scratch dir (deleted on cleanup)
  GOAL_ARTIFACTS  where kept outputs go (.goals/<goal>/artifacts/<task>)
"""
from __future__ import annotations

import datetime as dt
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]          # project root
SCRATCH = Path(os.environ.get("GOAL_SCRATCH") or ROOT / ".goals" / "adhoc" / "scratch" / "main")
ARTIFACTS = Path(os.environ.get("GOAL_ARTIFACTS") or ROOT / ".goals" / "adhoc" / "artifacts" / "main")

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
except Exception:
    pass


class EnvError(Exception):
    """Environment not ready (Outlook closed, add-in missing...). Worker should report `blocked`."""

    def __init__(self, code: str, msg: str, hint: str = ""):
        super().__init__(msg)
        self.code, self.msg, self.hint = code, msg, hint


class QueryError(Exception):
    """Bad input to a helper (unknown store, bad date...). Fix the script and rerun."""


def _excepthook(tp, val, tb):
    if isinstance(val, EnvError):
        sys.stderr.write(f"BLOCKED {val.code}: {val.msg}" + (f" | hint: {val.hint}" if val.hint else "") + "\n")
        sys.exit(3)
    if isinstance(val, QueryError):
        sys.stderr.write(f"QUERY ERROR: {val}\n")
        sys.exit(2)
    sys.__excepthook__(tp, val, tb)


sys.excepthook = _excepthook


def day(s, end=False):
    """'2024-01-31' -> datetime (start or end of day). Accepts datetime/date too."""
    if s is None or s == "":
        return None
    if isinstance(s, dt.datetime):
        return s
    if isinstance(s, dt.date):
        s = s.isoformat()
    try:
        d = dt.datetime.strptime(str(s)[:10], "%Y-%m-%d")
    except ValueError:
        raise QueryError(f"date '{s}' is not YYYY-MM-DD")
    return d + dt.timedelta(days=1, seconds=-1) if end else d


def clip(text, n: int) -> str:
    t = re.sub(r"\n{3,}", "\n\n", str(text or "").replace("\r\n", "\n")).strip()
    return t if not n or len(t) <= n else t[:n] + f" ...[+{len(t) - n} chars]"


def one_line(text, n: int = 160) -> str:
    t = re.sub(r"\s+", " ", str(text or "")).strip()
    return t if len(t) <= n else t[: n - 1] + "…"


def safe_name(name, default="file") -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(name or "")).strip(" .")
    return (name or default)[:150]


def unique(directory: Path, name: str) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    p, i = directory / name, 1
    while p.exists():
        p = directory / f"{Path(name).stem} ({i}){Path(name).suffix}"
        i += 1
    return p


def rel(p) -> str:
    """Project-relative path string (shorter output)."""
    try:
        return Path(p).resolve().relative_to(ROOT.resolve()).as_posix()
    except ValueError:
        return str(p)


def config() -> dict:
    p = ROOT / "tools" / "config.json"
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        raise QueryError(f"tools/config.json is invalid JSON: {e}")
