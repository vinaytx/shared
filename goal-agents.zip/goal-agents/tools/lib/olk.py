"""olk - read-only classic Outlook (COM) helpers for ad hoc scripts.

  stores()                         -> list of dicts: name, id, path, archive (looks like Barracuda)
  store(name=None)                 -> one store (case-insensitive substring; None = default store)
  archive_stores()                 -> stores that look like the Barracuda archive
  folders(st=None, depth=3)        -> list of dicts: store, path, items
  search(st=None, folder=None, frm=None, to=None, subject=None, body=None, text=None,
         since=None, until=None, attach=None, unread=None, recurse=True, limit=200) -> [Msg]
        st: None (default Inbox) | name | store | list of either.  folder: "Inbox/Sub".
        Text filters are case-insensitive substrings; dates "YYYY-MM-DD".
  get(id, sid=None)                -> Msg

  Msg fields : id sid folder received from_name from_email to cc subject natt size unread
               msgid (Internet Message-ID, fetched on first use)
  Msg methods: body(n=2000) headers(n=4000) atts() save_atts(sub="", index=None) export(fmt="msg")
  m.item is the raw COM MailItem (read properties only).

New Outlook (olk.exe) has no COM interface and is not supported.
"""
from __future__ import annotations

import datetime as dt
import os
import subprocess

from _base import ARTIFACTS, rel, EnvError, QueryError, clip, config, day, one_line, safe_name, unique

__all__ = ["stores", "store", "archive_stores", "folders", "search", "get", "Msg"]

_INBOX, _MAIL_FOLDER = 6, 0
_MAIL_CLASSES = {43, 53, 54, 55, 56, 57}
_P_HEADERS = "http://schemas.microsoft.com/mapi/proptag/0x007D001F"
_P_SMTP = "http://schemas.microsoft.com/mapi/proptag/0x39FE001F"
_P_MSGID = "http://schemas.microsoft.com/mapi/proptag/0x1035001F"
_P_SENDER_SMTP = "http://schemas.microsoft.com/mapi/proptag/0x5D01001F"
_FORMATS = {"txt": 0, "html": 5, "msg": 9}
_ns = None


# ----------------------------------------------------------------- connection

def _procs() -> str:
    if os.name != "nt":
        return ""
    try:
        return subprocess.run(["tasklist", "/FO", "CSV", "/NH"], capture_output=True, text=True, timeout=10).stdout.lower()
    except Exception:
        return ""


def ns():
    global _ns
    if _ns is not None:
        return _ns
    if os.name != "nt" and not os.environ.get("GOAL_FAKE_COM"):
        raise EnvError("ENV_NOT_WINDOWS", "Outlook COM needs Windows", "run Claude Code on the PC with classic Outlook")
    try:
        import pythoncom  # type: ignore
        import win32com.client  # type: ignore
    except ImportError:
        raise EnvError("ENV_NO_PYWIN32", "pywin32 not installed", "py -m pip install pywin32")
    try:
        pythoncom.CoInitialize()
    except Exception:
        pass
    try:
        n = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
        _ = n.Stores.Count
    except Exception as e:
        p = _procs()
        hint = ("start classic Outlook as the same user and elevation as Claude Code (both non-admin); "
                "New Outlook has no COM - switch to classic")
        if '"olk.exe"' in p and '"outlook.exe"' not in p:
            raise EnvError("ENV_NEW_OUTLOOK", "only New Outlook is running", hint)
        raise EnvError("ENV_OUTLOOK_UNAVAILABLE", f"cannot connect to Outlook: {e}", hint)
    _ns = n
    return n


def _g(o, a, default=None):
    try:
        v = getattr(o, a)
        return default if v is None else v
    except Exception:
        return default


def _date(v):
    if v is None or not hasattr(v, "year") or v.year >= 4500:
        return None
    try:
        return dt.datetime(v.year, v.month, v.day, v.hour, v.minute, v.second)
    except Exception:
        return None


# ----------------------------------------------------------------- stores / folders

def _hints():
    env = os.environ.get("BARRACUDA_STORE_HINTS")
    h = env.split(",") if env else config().get("barracuda", {}).get("archive_store_hints")
    return [x.strip().lower() for x in (h or ["barracuda", "archive search", "message archiver", "archive"]) if x.strip()]


def _all():
    n = ns()
    return [n.Stores.Item(i) for i in range(1, n.Stores.Count + 1)]


def _is_archive(s) -> bool:
    hay = f"{_g(s, 'DisplayName', '')} {_g(s, 'FilePath', '')}".lower()
    return any(h in hay for h in _hints())


def stores():
    return [{"name": _g(s, "DisplayName", ""), "id": _g(s, "StoreID", ""), "path": _g(s, "FilePath", "") or None,
             "archive": _is_archive(s)} for s in _all()]


def store(name=None):
    if name is None:
        return ns().DefaultStore
    if not isinstance(name, str):
        return name
    all_ = _all()
    low = name.lower()
    hit = [s for s in all_ if (_g(s, "DisplayName", "") or "").lower() == low] or \
          [s for s in all_ if low in (_g(s, "DisplayName", "") or "").lower()]
    if not hit:
        raise QueryError(f"no store matches '{name}'. stores: {[_g(s, 'DisplayName') for s in all_]}")
    return hit[0]


def archive_stores():
    hit = [s for s in _all() if _is_archive(s)]
    if not hit:
        raise EnvError("ENV_NO_ARCHIVE_STORE", "no Outlook store looks like the Barracuda archive",
                       "Outlook > File > Barracuda Networks > Configure > Archive Stores > add + sync; "
                       "or set archive_store_hints in tools/config.json; or use eml exports")
    return hit


def _path(folder) -> str:
    parts = [p for p in (_g(folder, "FolderPath", "") or "").split("\\") if p]
    return "/".join(parts[1:])


def _resolve(st, path):
    cur = st.GetRootFolder()
    for part in [p for p in str(path).replace("\\", "/").split("/") if p]:
        nxt = None
        for i in range(1, cur.Folders.Count + 1):
            f = cur.Folders.Item(i)
            if (_g(f, "Name", "") or "").lower() == part.lower():
                nxt = f
                break
        if nxt is None:
            raise QueryError(f"folder '{path}' not in store '{_g(st, 'DisplayName')}'")
        cur = nxt
    return cur


def _walk(folder, recurse=True, depth=0, max_depth=25):
    yield folder, depth
    if recurse and depth < max_depth:
        try:
            subs = folder.Folders
            for i in range(1, subs.Count + 1):
                yield from _walk(subs.Item(i), recurse, depth + 1, max_depth)
        except Exception:
            pass


def folders(st=None, depth=3):
    s = store(st)
    return [{"store": _g(s, "DisplayName", ""), "path": _path(f), "items": _g(_g(f, "Items"), "Count")}
            for f, d in _walk(s.GetRootFolder(), True, 0, depth) if d > 0 and _g(f, "DefaultItemType", 0) == _MAIL_FOLDER]


# ----------------------------------------------------------------- messages

class Msg:
    __slots__ = ("item", "id", "sid", "folder", "received", "from_name", "from_email", "to", "cc",
                 "subject", "natt", "size", "unread", "_msgid")

    def __init__(self, item, folder=None):
        self.item = item
        parent = folder if folder is not None else _g(item, "Parent")
        self.id = _g(item, "EntryID", "")
        self.sid = _g(parent, "StoreID", "") if parent is not None else ""
        self.folder = _path(parent) if parent is not None else ""
        self.received = _date(_g(item, "ReceivedTime")) or _date(_g(item, "SentOn"))
        self.from_name = _g(item, "SenderName", "")
        self.from_email = _sender(item)
        self.to = _g(item, "To", "")
        self.cc = _g(item, "CC", "")
        self.subject = _g(item, "Subject", "")
        a = _g(item, "Attachments")
        self.natt = _g(a, "Count", 0) if a is not None else 0
        self.size = _g(item, "Size")
        self.unread = bool(_g(item, "UnRead", False))
        self._msgid = False

    @property
    def msgid(self):
        if self._msgid is False:
            self._msgid = _prop(self.item, _P_MSGID)
        return self._msgid

    def body(self, n=2000):
        return clip(_g(self.item, "Body", ""), n)

    def headers(self, n=4000):
        return clip(_prop(self.item, _P_HEADERS) or "", n)

    def atts(self):
        a = _g(self.item, "Attachments")
        out = []
        for i in range(1, (_g(a, "Count", 0) if a is not None else 0) + 1):
            x = a.Item(i)
            out.append({"i": i, "name": _g(x, "FileName", "") or _g(x, "DisplayName", ""), "size": _g(x, "Size"),
                        "embedded": _g(x, "Type") == 5})
        return out

    def save_atts(self, sub="", index=None):
        """Save attachments under the artifacts dir; returns list of paths."""
        d = ARTIFACTS / safe_name(sub) if sub else ARTIFACTS
        paths = []
        for a in self.atts():
            if index and a["i"] != index:
                continue
            name = safe_name(a["name"], f"att{a['i']}") + (".msg" if a["embedded"] else "")
            p = unique(d, name)
            self.item.Attachments.Item(a["i"]).SaveAsFile(str(p.resolve()))
            paths.append(rel(p))
        return paths

    def export(self, fmt="msg"):
        if fmt not in _FORMATS:
            raise QueryError(f"fmt must be one of {sorted(_FORMATS)}")
        p = unique(ARTIFACTS, safe_name(self.subject or self.id[:16], "message") + "." + fmt)
        self.item.SaveAs(str(p.resolve()), _FORMATS[fmt])
        return rel(p)

    def __repr__(self):
        r = self.received.strftime("%Y-%m-%d") if self.received else "?"
        return f"<Msg {r} {self.from_email} {one_line(self.subject, 60)!r}>"


def _prop(item, tag):
    try:
        return item.PropertyAccessor.GetProperty(tag) or None
    except Exception:
        return None


def _sender(item) -> str:
    if (_g(item, "SenderEmailType", "") or "").upper() == "EX":
        try:
            u = item.Sender.GetExchangeUser()
            if u is not None and u.PrimarySmtpAddress:
                return u.PrimarySmtpAddress
        except Exception:
            pass
        return _prop(item, _P_SENDER_SMTP) or _prop(item, _P_SMTP) or _g(item, "SenderEmailAddress", "")
    return _g(item, "SenderEmailAddress", "")


def _like(prop, v):
    return f'"{prop}" LIKE \'%{str(v).replace(chr(39), chr(39) * 2)}%\''


def _filter(frm, to, subject, body, text, since, until, attach, unread):
    c = []
    if frm:
        c.append("(" + " OR ".join(_like(p, frm) for p in ("urn:schemas:httpmail:fromemail", "urn:schemas:httpmail:fromname",
                                                           "http://schemas.microsoft.com/mapi/proptag/0x0C1F001F")) + ")")
    if to:
        c.append("(" + " OR ".join(_like(p, to) for p in ("urn:schemas:httpmail:displayto", "urn:schemas:httpmail:displaycc")) + ")")
    if subject:
        c.append(_like("urn:schemas:httpmail:subject", subject))
    if body:
        c.append(_like("urn:schemas:httpmail:textdescription", body))
    if text:
        c.append("(" + _like("urn:schemas:httpmail:subject", text) + " OR " + _like("urn:schemas:httpmail:textdescription", text) + ")")
    for d, op in ((day(since), ">="), (day(until, end=True), "<=")):
        if d:
            c.append(f'"urn:schemas:httpmail:datereceived" {op} \'{d.astimezone(dt.timezone.utc):%Y-%m-%d %H:%M}\'')
    if attach is not None:
        c.append(f'"urn:schemas:httpmail:hasattachment" = {1 if attach else 0}')
    if unread is not None:
        c.append(f'"urn:schemas:httpmail:read" = {0 if unread else 1}')
    return "@SQL=" + " AND ".join(c) if c else None


def search(st=None, folder=None, frm=None, to=None, subject=None, body=None, text=None, since=None, until=None,
           attach=None, unread=None, recurse=True, limit=200):
    flt = _filter(frm, to, subject, body, text, since, until, attach, unread)
    n = ns()
    if st is None:
        starts = [_resolve(n.DefaultStore, folder) if folder else n.GetDefaultFolder(_INBOX)]
    else:
        sts = st if isinstance(st, (list, tuple)) else [st]
        starts = [_resolve(store(s), folder) if folder else store(s).GetRootFolder() for s in sts]
    out = []
    for start in starts:
        for f, _ in _walk(start, recurse):
            if len(out) >= limit:
                break
            if _g(f, "DefaultItemType", 0) != _MAIL_FOLDER:
                continue
            try:
                items = f.Items
                items.Sort("[ReceivedTime]", True)
                hits = items.Restrict(flt) if flt else items
                it = hits.GetFirst()
            except Exception:
                continue
            while it is not None and len(out) < limit:
                if _g(it, "Class", 43) in _MAIL_CLASSES:
                    out.append(Msg(it, f))
                try:
                    it = hits.GetNext()
                except Exception:
                    break
    out.sort(key=lambda m: m.received or dt.datetime.min, reverse=True)
    return out


def get(id, sid=None):
    try:
        it = ns().GetItemFromID(id, sid) if sid else ns().GetItemFromID(id)
    except EnvError:
        raise
    except Exception as e:
        raise QueryError(f"cannot open item {id[:16]}...: {e} (pass sid; ids change when items move)")
    return Msg(it)
