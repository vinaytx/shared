# Goal agents v2: script-generating workers for Outlook + Barracuda (Claude Code, Windows)

Workers don't call a fixed CLI. For each task they **write a short throwaway Python
script** against small helper libraries, run it through a guarded runner, return a compact
result, and **delete the script** when done. Results that must be kept (JSONL, attachments)
go to an artifacts folder that survives cleanup.

```
/goal "Acme invoices since 2015, mailbox + archive, de-duplicated"
  orchestrator ── fast path: 1 worker, no plan file ── or plan path: .goals/<id>/plan.json
     ├─▶ outlook-mail       writes .goals/<id>/scratch/T1/q1.py ─▶ bash tools/run adhoc ... ─▶ compact TSV
     ├─▶ barracuda-archive  writes .goals/<id>/scratch/T2/q1.py ─▶ bash tools/run adhoc ... ─▶ compact TSV
     │        each worker: bash tools/run cleanup <id> --task <T>   (scripts gone)
     └─ report ─▶ bash tools/run cleanup <id>                        (anything left gone)
SessionStart hook: cleanup --stale (sweeps scratch from crashed runs after 12h)
```

## Where the token savings come from

| Lever | How |
|---|---|
| Tiny scripts | Helper libs (`olk`, `eml`, `out`) do the heavy lifting, so a typical query is 3-6 lines. |
| Compact output | `out.rows()` prints TSV capped at 25 rows and 60-char cells; the runner cuts stdout at 3000 chars and keeps the rest in a file. |
| Data stays on disk | Full result sets go to `artifacts/*.jsonl`; only summaries enter the conversation. |
| Isolated context | Raw query output lives in the worker's context. The orchestrator only sees a short envelope. |
| Fast path | Single-source goals skip the plan file and results bookkeeping. |
| Lean prompts | Short worker contract and cheat sheets; workers run with `effort: low`, and the orchestrator doesn't call the registry (it already sees agent descriptions). |
| Compact tool output | doctor, cleanup and runner print `key=value` text, not JSON envelopes. |

## Layout

| Path | Purpose |
|---|---|
| `.claude/skills/goal/SKILL.md` | Orchestration loop (`/goal <outcome>`), with fast path and cleanup step. |
| `.claude/agents/goal-orchestrator.md` | Same loop as a subagent, or `claude --agent goal-orchestrator`. |
| `.claude/skills/worker-contract/SKILL.md` | Script-writing loop, output rules, envelope. Preloaded into every worker. |
| `.claude/agents/workers/*.md` | Workers, each with a cheat sheet of its helper libs. |
| `tools/lib/olk.py` | Classic Outlook (COM) helpers: stores, folders, search, get, Msg. |
| `tools/lib/eml.py` | Barracuda EML/zip export helpers: scan, search, get, EMsg. |
| `tools/lib/out.py` | Compact printing and saving: rows, count, kv, say, dedupe, save. |
| `tools/adhoc.py` | Runner: location check, static checker, timeout, output cap. |
| `tools/cleanup.py` | Deletes scratch (per task, per goal, stale) or purges a goal. |
| `tools/doctor.py` | Environment check for Outlook and Barracuda. |
| `tools/hooks/guard_bash.py`, `guard_write.py` | Worker hooks: Bash limited to `tools/run adhoc/doctor/cleanup`; writes limited to `.py` in scratch. |

## Guardrails on generated code

Before any generated script runs, `tools/adhoc.py` rejects it if it:
- imports anything except the helper libs and a safe stdlib list (no `os`, `sys`,
  `subprocess`, `pathlib`, network modules);
- uses `open`, `eval`, `exec`, `getattr`/`setattr`, `__import__`, or dunder attributes;
- assigns to attributes (which would change mail properties);
- calls COM methods that change, send or display mail (`Send`, `Delete`, `Move`,
  `Save`, `SaveAs`, `Forward`, `Reply`...) or Path-style file mutators.

Scripts run only from `.goals/<id>/scratch/`, with a timeout. Rejections list line
numbers so the worker can fix and rerun. This is a strong guardrail against mistakes and
prompt-injected instructions, not a security sandbox.

## Setup (Windows)

1. Use **classic Outlook**, keep it running. New Outlook has no COM.
2. Install Python 3.8+ from python.org, then `py -m pip install pywin32`.
3. Copy this folder into your project. Run Claude Code **non-elevated** from it and accept
   the trust prompt so the hooks load.
4. Run `bash tools/run doctor`. It reports what's missing.
5. Barracuda: sync Archive Stores in the Outlook add-in (admin enables folder-sync jobs),
   or export results from the archiver web UI as EML and set `export_dir` in `tools/config.json`
   (copy from `config.example.json`) or `BARRACUDA_EXPORT_DIR`.
6. 32-bit Outlook and COM errors: install 32-bit Python and set `GOAL_PYTHON`.

## Adding a worker

```
bash tools/run new-worker jira-tickets --lib jira --purpose "Searches Jira tickets by project and status"
```
1. Implement `tools/lib/jira.py`: a small read-only API with a docstring cheat sheet.
   Raise `EnvError` for setup problems (worker reports `blocked`) and `QueryError` for bad input.
2. Copy the cheat sheet and capabilities into `.claude/agents/workers/jira-tickets.md`.
3. `bash tools/run registry` to check it. The orchestrator picks it up from the description.

The runner automatically allows importing any module in `tools/lib/` (except `_*` and `TEMPLATE`).

## Cleanup reference

```
bash tools/run cleanup <goal_id> --task T1   # one task's scripts (workers do this)
bash tools/run cleanup <goal_id>             # all scripts for a goal (orchestrator does this)
bash tools/run cleanup <goal_id> --purge     # everything incl. artifacts (on request only)
bash tools/run cleanup --stale --hours 12    # crash leftovers (runs at session start)
bash tools/run cleanup --list
```

## Known limits

- Search uses Outlook DASL `LIKE` (substring). Body search is slow, so always add dates.
- `limit` stops collecting once reached, folder by folder, so narrow the query for "newest N".
- Archived stubs may hold only a preview; the full copy lives on the archiver.
- Tested against a mocked Outlook object model and real EML files, not live Outlook.
  Run `bash tools/run doctor` first.
